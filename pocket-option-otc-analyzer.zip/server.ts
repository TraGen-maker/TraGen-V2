/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // GET /api/v1/history?asset={}&period={}&count=500
  // Returns historical candles for seeding
  app.get("/api/v1/history", (req, res) => {
    const asset = (req.query.asset as string) || "OTC_EURUSD";
    const period = parseInt(req.query.period as string) || 60;
    const count = parseInt(req.query.count as string) || 500;

    // Map period back to timeframe label
    let basePrice = 1.1000;
    if (asset.includes("JPY")) basePrice = 150.0;
    else if (asset.includes("BTC")) basePrice = 68000.0;
    else if (asset.includes("GOLD")) basePrice = 2300.0;
    else if (asset.includes("GBP")) basePrice = 1.2700;
    else if (asset.includes("CAD")) basePrice = 1.3600;
    else if (asset.includes("AUD")) basePrice = 0.6600;

    const list = [];
    let currentPrice = basePrice;
    let timestamp = Date.now() - count * period * 1000;

    for (let i = 0; i < count; i++) {
      const rand = Math.random();
      const drift = (rand - 0.495) * (basePrice * 0.0004);
      const open = currentPrice;
      const close = currentPrice + drift;
      const high = Math.max(open, close) + Math.random() * (basePrice * 0.0003);
      const low = Math.min(open, close) - Math.random() * (basePrice * 0.0003);
      const volume = 150 + Math.floor(Math.random() * 850);

      list.push({
        timestamp,
        open,
        high,
        low,
        close,
        volume,
        asset,
        periodSeconds: period
      });

      currentPrice = close;
      timestamp += period * 1000;
    }

    res.json({
      success: true,
      asset,
      period,
      count: list.length,
      candles: list
    });
  });

  // POST /api/analyze
  // AI Advisor on-demand prediction critiquing current market setups
  app.post("/api/analyze", async (req, res) => {
    try {
      const key = process.env.GEMINI_API_KEY;
      if (!key || key.includes("MY_GEMINI_API_KEY")) {
        return res.json({
          success: false,
          advice: "AI Advisor is currently offline. To activate, please add a valid standard GEMINI_API_KEY to your Secrets Settings panel on the AI Studio interface."
        });
      }

      const { symbol, timeframe, indicators, signals } = req.body;

      const ai = new GoogleGenAI({ apiKey: key });
      const prompt = `
You are an advanced Quantitative Trading Analyst specializing in Over-The-Counter (OTC) markets on Pocket Option.
Analyze the following active asset parameters and provide executive strategic trading decisions.

Asset: ${symbol}
Timeframe: ${timeframe}
Active Technical Indicators: ${JSON.stringify(indicators)}
Signal Context: ${JSON.stringify(signals)}

Based on this market snapshot, deliver a sharp, highly technical 2-paragraph critique of the setup:
1. Explain how Alligator channels, AMD phase structures, and Keltner boundaries align, detailing if the setup indicates stop hunts or institutional order block mitigation.
2. Formulate a explicit trade structure (Buy vs Sell vs Neutral), stating recommended premium expiry intervals, confidence weighting, and crucial invalidation levels.

Keep the critique direct, advanced, professional, and free of sales-talk or hype. Do not use markdown headers or lists, keep it as cohesive paragraphs.
`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [prompt],
      });

      res.json({
        success: true,
        advice: response.text || "No response received from Gemini engine."
      });

    } catch (error: any) {
      console.error("Gemini Advisor failure:", error);
      res.status(500).json({
        success: false,
        advice: `Failed to invoke Gemini Engine: ${error?.message || error}`
      });
    }
  });

  // Serve Vite assets in development, or compiled folder in production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`PO OTC Engine Server active on http://0.0.0.0:${PORT}`);
  });
}

startServer();
