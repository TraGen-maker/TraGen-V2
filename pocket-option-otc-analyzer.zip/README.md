# Pocket Option OTC Quantitative Analyzer & ML Engine

A production-grade algorithmic analysis suite designed to monitor and execute multi-layered machine learning predictions against Over-The-Counter (OTC) asset feeds on the Pocket Option broker platform.

This workspace consists of:
1. **Interactive Web Dashboard**: A functional real-time simulation/monitoring platform displaying live candles, customized indicator overlays, order blocks, FVG zones, AMD phases, and a signals logger.
2. **Android Repository (*kotlin-compose*)**: Complete clean architecture source code for active Android deployments including background monitor services and Room repositories.
3. **ML Training Core**: Feature extractor logic engineering 44 parameters and a training Python script generating LSTM layers converted into `.tflite` model files.

---

## Technical Specifications & Architecture

- **Runtime Target**: Android API level 26 to 34 (Jetpack Compose, Material 3, Clean Architecture MVVM).
- **Core Indicators Engine**: Alligator SMMA, ROC/Momentum(14) Slope, Keltner Channel bounce, equal high/low swept arrays, breakaway breakaway gap fading, and Accumulation-Manipulation-Distribution (AMD) timers.
- **Machine Learning**: TensorFlow Lite LSTM networks (20 lookback periods, 44 indicators parameters) predicting directional probabilities.
- **Persistent Cache**: Room database structures logging candles and historically resolved signals.

---

## Project Setup & Android Installation

1. Create a fresh Android project in **Android Studio v.Koala+** utilizing the *Empty Compose Activity* setup.
2. Structure your module directory matching the Clean Architecture structure detailed in the web dashboard repository explorer:
   ```
   app/
   ├── src/main/
   │   ├── kotlin/com/otcanalyzer/
   │   │   ├── indicators/     <-- Technical extensions
   │   │   ├── ml/             <-- Feature extraction & TFLite interpreters
   │   │   ├── domain/         <-- Business logic & UseCases
   │   │   ├── data/           <-- OkHttp WebSocket, Room database, seeding
   │   │   ├── service/        <-- Background Foreground Services & notifications
   │   │   └── ui/             <-- Jetpack Compose screens
   ```
3. Copy the compiled configuration build rules from `build.gradle.kts (Module)` and `build.gradle.kts (Project)`.
4. Register the foreground services and system permissions inside `/app/src/main/AndroidManifest.xml`:
   - `INTERNET`, `FOREGROUND_SERVICE`, `POST_NOTIFICATIONS`, `VIBRATE`, `RECEIVE_BOOT_COMPLETED`.
5. Place the exported `.tflite` model binaries under your Android project folder: `/app/src/main/assets/ml/`.
6. Compile the code and run the application on your target emulator or physical screen device.

---

## Extracting Pocket Option SSID Tokens

To connect live broker platform channels, you must authenticate WebSockets using session cook tokens:

1. Navigate to the Pocket Option trading web interface in Google Chrome: `https://pocketoption.com/` (or related regional mirror platform domains).
2. Log in securely with user credentials.
3. Open Developer Tools (`F12` or `Ctrl + Shift + I` / `Cmd + Option + I`).
4. Select the **Application** menu tab at the top of the inspector panels.
5. Expand the **Cookies** menu segment in the left panel and select current broker URL domains.
6. Search the token item key: `ssid`.
7. Double-click to focus the matching String value (e.g. `23a07...`), copy this value, and paste it into the **Settings** panel of the analyzer dashboard.

---

## Python TFLite Training & Exporting

The `train_model.py` script constructs deep LSTM structures matching structural parameters, trains over mock indicators grids, and optimizes layers prior to exporting.

### 1. Requirements setup:
```bash
pip install tensorflow numpy
```

### 2. Execution parameters:
Execute training to generate `.tflite` binaries for the 4 timeframes:
```bash
python train_model.py
```

### 3. Model Architecture pipeline:
- **Input**: `shape = [1, 20, 44]` (20 candle lookback history with 44 feature parameters)
- **L1/L2**: Multi-stacked LSTM cells containing 128 & 64 nodes alongside 0.20 dropout weights protecting against overfits.
- **Output**: Categorical Softmax density outputting [P(SELL), P(NEUTRAL), P(BUY)] classification arrays.

---

## Trade Signal Interpretation Guide

Every signal generated uses deep visual criteria matching confluences ≥ 72% before giving active recommendation alert logs.

- **Confluence Factors Score**:
  - `0.30` × TFLite LSTM forward prediction.
  - `0.20` × Indicator alignment agreement (Alligator direction must match Momentum).
  - `0.20` × AMD Distribution state activation (distribution triggers fade manip spikes).
  - `0.15` × Fluid liquidity proximity (closeness to swept EQL or EQH marks).
  - `0.10` × DTW sequence similarity (comparing current 8-lookback frames to winning histories).
  - `0.05` × Session high-probability hour marks.

- **Signal Strengths**:
  - **STRONG**: Technical triggers align across 30s trigger, 1m confirmation, and 2m trend filters. Action: Recommended trade expiry of 1m.
  - **NORMAL**: Trigger timeframe (30s) is supported by primary 1m indicators, while 2m is neutral. Action: Expiry of 1m or 2m.
  - **WEAK**: Detected on fast timeframe only without verification. Suppressed automatically.
