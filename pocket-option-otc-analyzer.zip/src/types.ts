/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum Timeframe {
  TF_30S = "TF_30S",
  TF_1M = "TF_1M",
  TF_2M = "TF_2M",
  TF_3M = "TF_3M"
}

export interface Tick {
  timestamp: number;
  price: number;
  asset: string;
}

export interface Candle {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  asset: string;
  timeframe: Timeframe;
}

export enum Direction {
  BUY = "BUY",
  SELL = "SELL",
  NEUTRAL = "NEUTRAL"
}

export enum Outcome {
  WIN = "WIN",
  LOSS = "LOSS",
  PENDING = "PENDING"
}

export interface Signal {
  id: string;          // UUID v4
  timestamp: number;
  asset: string;
  timeframe: Timeframe;       // which TF triggered the signal
  direction: Direction;
  confidence: number;           // 0.0 – 1.0
  expiry: Timeframe;       // recommended trade expiry TF
  strategy: string;
  reasons: string[];
  indicators: Record<string, number>;
  mlScore: number;
  neuralScore: number;
  outcome: Outcome;
}

export interface GridAlignmentState {
  alligator: Record<Timeframe, Direction>;
  momentum: Record<Timeframe, Direction>;
  keltner: Record<Timeframe, Direction>;
  amd: Record<Timeframe, Direction>;
}

export interface ProjectFile {
  path: string;
  content: string;
  language: string;
}
