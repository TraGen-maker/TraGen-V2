import { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { AuthProvider, useAuth } from "./store/authStore";
import { AdminProvider, useAdmin } from "./store/adminStore";
import { MarketProvider } from "./store/marketStore";
import { ChartConfigProvider } from "./store/chartStore";

import { LoginScreen } from "./components/auth/LoginScreen";
import { RegisterScreen } from "./components/auth/RegisterScreen";
import { DashboardScreen } from "./components/dashboard/DashboardScreen";
import { SignalsScreen } from "./components/signals/SignalsScreen";
import { AnalyticsScreen } from "./components/analytics/AnalyticsScreen";
import { SettingsScreen } from "./components/settings/SettingsScreen";
import { AdminScreen } from "./components/admin/AdminScreen";

import { BottomTabBar } from "./components/shared/BottomTabBar";
import { ParticleField } from "./components/shared/ParticleField";
import { FloatingOrbs } from "./components/shared/FloatingOrbs";
import { OpeningAnimation } from "./components/shared/OpeningAnimation";
import { ServerCrash, Cpu } from "lucide-react";

// Secure Auth Protection Wrapper
function RequireAuth({ children }: { children: React.ReactNode }) {
  const { currentUser, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-bg-deep flex flex-col justify-center items-center gap-3 select-none">
        <Cpu className="w-8 h-8 text-accent-cyan animate-spin" />
        <span className="text-xs font-orbitron text-accent-cyan tracking-widest text-glow-cyan">
          CONNECTING QUANTUM WORKSPACE...
        </span>
      </div>
    );
  }

  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}

// Secure Administrative Check Wrapper
function RequireAdmin({ children }: { children: React.ReactNode }) {
  const { currentUser } = useAuth();

  if (!currentUser || !currentUser.isAdmin) {
    return <Navigate to="/dashboard" replace />;
  }

  return <>{children}</>;
}

// Global System Wrapper handling Maintenance toggles and Layout Bottom Bars
function LayoutWrapper({ children }: { children: React.ReactNode }) {
  const { currentUser } = useAuth();
  const { maintenanceMode } = useAdmin();
  const location = useLocation();
  
  const [showSplash, setShowSplash] = useState(() => {
    return !sessionStorage.getItem("wsm_splash_dismissed");
  });

  const isAuthRoute = location.pathname === "/login" || location.pathname === "/register";

  if (showSplash) {
    return (
      <OpeningAnimation
        onComplete={() => {
          setShowSplash(false);
          sessionStorage.setItem("wsm_splash_dismissed", "true");
        }}
      />
    );
  }

  // If Maintenance locked on, and active user is NOT an admin, display lock screen
  if (maintenanceMode && currentUser && !currentUser.isAdmin && !isAuthRoute) {
    return (
      <div className="min-h-screen bg-bg-deep flex items-center justify-center p-6 relative select-none">
        <ParticleField />
        <FloatingOrbs />
        <div className="absolute -inset-[2px] w-full max-w-md bg-gradient-to-r from-accent-purple via-sell-red to-accent-purple rounded-3xl blur-[3px] opacity-35" />
        <div className="relative p-8 rounded-2xl bg-bg-surface/90 border border-sell-red/25 backdrop-blur-3xl text-center space-y-5 max-w-md shadow-2xl">
          <div className="w-16 h-16 bg-sell-red/10 text-sell-red rounded-full flex items-center justify-center mx-auto shadow-[0_0_15px_rgba(255,59,107,0.35)]">
            <ServerCrash className="w-8 h-8 animate-bounce" />
          </div>
          <h1 className="text-lg font-orbitron font-extrabold text-glow-cyan text-text-light uppercase tracking-wider">
            QUANTUM CALIBRATION SYSTEM INTERTIA
          </h1>
          <p className="text-xs text-muted-blue leading-relaxed font-sans">
            The neural predictive processors are undergoing rapid physical calibration. Overlays convergence alignments are locked down for scheduled backend maintenance. 
          </p>
          <div className="w-16 h-[2px] bg-gradient-to-r from-transparent via-accent-cyan to-transparent mx-auto shadow-[0_0_8px_rgba(0,229,255,0.8)]" />
          <p className="text-[10px] text-gold font-orbitron uppercase tracking-widest leading-none">
            Estimated standby: 15 minutes
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-bg-deep text-text-light relative flex flex-col font-sans">
      <ParticleField />
      <FloatingOrbs />

      {/* Primary views section */}
      <main className="flex-grow w-full z-10">{children}</main>

      {/* Floating Bottom Tab items: visible on all views EXCEPT authentication pages */}
      {!isAuthRoute && currentUser && <BottomTabBar />}
    </div>
  );
}

// Master Router Root
export default function App() {
  return (
    <AuthProvider>
      <AdminProvider>
        <MarketProvider>
          <ChartConfigProvider>
            <Router>
              <LayoutWrapper>
                <Routes>
                  {/* Auth Routers */}
                  <Route path="/login" element={<LoginScreen />} />
                  <Route path="/register" element={<RegisterScreen />} />

                  {/* Secure Trading Routers */}
                  <Route
                    path="/dashboard"
                    element={
                      <RequireAuth>
                        <DashboardScreen />
                      </RequireAuth>
                    }
                  />
                  <Route
                    path="/signals"
                    element={
                      <RequireAuth>
                        <SignalsScreen />
                      </RequireAuth>
                    }
                  />
                  <Route
                    path="/analytics"
                    element={
                      <RequireAuth>
                        <AnalyticsScreen />
                      </RequireAuth>
                    }
                  />
                  <Route
                    path="/settings"
                    element={
                      <RequireAuth>
                        <SettingsScreen />
                      </RequireAuth>
                    }
                  />

                  {/* Pure Admin Console Router */}
                  <Route
                    path="/admin"
                    element={
                      <RequireAuth>
                        <RequireAdmin>
                          <AdminScreen />
                        </RequireAdmin>
                      </RequireAuth>
                    }
                  />

                  {/* Redirect entry guards fallback */}
                  <Route path="/" element={<Navigate to="/dashboard" replace />} />
                  <Route path="*" element={<Navigate to="/dashboard" replace />} />
                </Routes>
              </LayoutWrapper>
            </Router>
          </ChartConfigProvider>
        </MarketProvider>
      </AdminProvider>
    </AuthProvider>
  );
}
