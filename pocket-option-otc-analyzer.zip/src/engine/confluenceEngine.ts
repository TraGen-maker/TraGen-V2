import { Candle, Direction, Timeframe } from "../types";

export interface Alligator {
  jaw: number;
  teeth: number;
  lips: number;
}

export interface MomentumResult {
  value: number;
  direction: "UP" | "DOWN" | "NEUTRAL";
  crossedZero: boolean;
}

export interface KeltnerResult {
  center: number;
  upper: number;
  lower: number;
  positionRatio: number; // (close - lower) / (upper - lower)
}

export interface BollingerResult {
  middle: number;
  upper: number;
  lower: number;
  squeezingReleasing: boolean;
}

export interface LiquidityResult {
  stopHuntDetected: boolean;
  reversalConfirmed: boolean;
  type: "bullish" | "bearish" | "none";
}

export interface AMDResult {
  phase: number; // 1 = Accumulation, 2 = Manipulation, 3 = Distribution
  reason: string;
}

export interface CandlePatternResult {
  detected: boolean;
  name: string;
}

// EMA calculator helper
export function computeEMA(prices: number[], period: number): number[] {
  if (prices.length === 0) return [];
  const emas: number[] = [];
  const k = 2 / (period + 1);
  let currentEma = prices[0];
  emas.push(currentEma);

  for (let i = 1; i < prices.length; i++) {
    currentEma = prices[i] * k + currentEma * (1 - k);
    emas.push(currentEma);
  }
  return emas;
}

// SMA calculator helper
export function computeSMA(prices: number[], period: number): number[] {
  if (prices.length < period) return Array(prices.length).fill(prices[0] || 0);
  const smas: number[] = [];
  for (let i = 0; i < prices.length; i++) {
    if (i < period - 1) {
      smas.push(prices[i]);
    } else {
      let sum = 0;
      for (let j = 0; j < period; j++) {
        sum += prices[i - j];
      }
      smas.push(sum / period);
    }
  }
  return smas;
}

// Average True Range (ATR) Calculator
export function computeATR(candles: Candle[], period: number = 14): number {
  if (candles.length < 2) return 0.001; // Prevent division of zero
  const trs: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const highLow = candles[i].high - candles[i].low;
    const highPrevClose = Math.abs(candles[i].high - candles[i - 1].close);
    const lowPrevClose = Math.abs(candles[i].low - candles[i - 1].close);
    const tr = Math.max(highLow, highPrevClose, lowPrevClose);
    trs.push(tr);
  }
  let atr = trs.slice(0, period).reduce((acc, val) => acc + val, 0) / Math.min(period, trs.length);
  for (let i = period; i < trs.length; i++) {
    atr = (atr * (period - 1) + trs[i]) / period;
  }
  return atr || 0.001;
}

// Standard Deviation Helper
export function computeStdDev(values: number[], period: number): number[] {
  const stddevs: number[] = [];
  const smas = computeSMA(values, period);

  for (let i = 0; i < values.length; i++) {
    if (i < period - 1) {
      stddevs.push(0);
    } else {
      let sumSqDiff = 0;
      const avg = smas[i];
      for (let j = 0; j < period; j++) {
        sumSqDiff += Math.pow(values[i - j] - avg, 2);
      }
      stddevs.push(Math.sqrt(sumSqDiff / period));
    }
  }
  return stddevs;
}

// Standard Williams Alligator calculation
// Jaw of Alligator = Blue Line - 13 period Smoothed Moving Average, offset by 8 bars
// Teeth of Alligator = Red Line - 8 period Smoothed Moving Average, offset by 5 bars
// Lips of Alligator = Green Line - 5 period Smoothed Moving Average, offset by 3 bars
export function computeAlligator(candles: Candle[]): Alligator {
  const fallbackPrice = candles[candles.length - 1]?.close || 1.1000;
  if (candles.length < 13) {
    return { jaw: fallbackPrice, teeth: fallbackPrice, lips: fallbackPrice };
  }
  const closes = candles.map(c => c.close);
  // Using EMAs as a stable and reactive approximation of smoothed averages
  const jawEmas = computeEMA(closes, 13);
  const teethEmas = computeEMA(closes, 8);
  const lipsEmas = computeEMA(closes, 5);

  // Approximate shifts by going back in index
  const jaw = jawEmas[Math.max(0, jawEmas.length - 1 - 8)] || fallbackPrice;
  const teeth = teethEmas[Math.max(0, teethEmas.length - 1 - 5)] || fallbackPrice;
  const lips = lipsEmas[Math.max(0, lipsEmas.length - 1 - 3)] || fallbackPrice;

  return { jaw, teeth, lips };
}

export function getTrendDirection(alligator: Alligator): number {
  if (alligator.lips > alligator.teeth && alligator.teeth > alligator.jaw) {
    return 1; // Bullish
  } else if (alligator.lips < alligator.teeth && alligator.teeth < alligator.jaw) {
    return -1; // Bearish
  }
  return 0; // Flat
}

// Accumulation, Manipulation, Distribution
export function detectAMDPhase(candles1m: Candle[], candles2m: Candle[]): AMDResult {
  const candles = candles1m.length >= candles2m.length ? candles1m : candles2m;
  if (candles.length < 40) {
    return { phase: 1, reason: "Insufficient candle feed length" };
  }

  // Slice historical chunks to evaluate phase:
  // Chunk 1 (older 20): Accumulation check (standard deviation / channel range is very tight)
  // Chunk 2 (mid 10): Manipulation check (stop hunt high/low break)
  // Chunk 3 (last 10): Distribution check (strong directional closing bars with expanded ADR/volume)
  const chunkAccumulation = candles.slice(-40, -20);
  const chunkManipulation = candles.slice(-20, -10);
  const chunkDistribution = candles.slice(-10);

  // 1. Check tight range in Accumulation chunk
  const accPrices = chunkAccumulation.map(c => c.close);
  const accMax = Math.max(...accPrices);
  const accMin = Math.min(...accPrices);
  const accSpread = (accMax - accMin) / accMin;

  // 2. Check sweeps in Manipulation
  const manipHigh = Math.max(...chunkManipulation.map(c => c.high));
  const manipLow = Math.min(...chunkManipulation.map(c => c.low));

  // 3. See if we have an expanded breakout in Distribution
  const distHigh = Math.max(...chunkDistribution.map(c => c.high));
  const distLow = Math.min(...chunkDistribution.map(c => c.low));

  let isDistribution = false;
  let reason = "Market is building core consolidation";

  // If standard deviation has increased and price is expanding out of chunk 1 range
  if (accSpread < 0.015) {
    // If we swept below/above accumulation highs/lows in Manipulation
    if (manipLow < accMin || manipHigh > accMax) {
      if (distHigh > manipHigh || distLow < manipLow) {
        isDistribution = true;
        reason = "Extended order volume breakout from previous phase 2 wick sweep";
      }
    }
  }

  if (isDistribution) {
    return { phase: 3, reason };
  } else if (manipLow < accMin || manipHigh > accMax) {
    return { phase: 2, reason: "Manipulation Phase: Instutitional stop hunt sweep active" };
  }

  return { phase: 1, reason: "Accumulation Phase: High-volume standard consolidation" };
}

export function analyzeLiquidity(candles: Candle[]): LiquidityResult {
  if (candles.length < 15) {
    return { stopHuntDetected: false, reversalConfirmed: false, type: "none" };
  }

  // Find recent extreme levels (swing points) in historical channel (first 10 from last 15)
  const baseCandles = candles.slice(0, candles.length - 5);
  const lastCandles = candles.slice(candles.length - 5);

  const localHeighs = baseCandles.map(c => c.high);
  const localLows = baseCandles.map(c => c.low);
  const swingHigh = Math.max(...localHeighs);
  const swingLow = Math.min(...localLows);

  let stopHuntDetected = false;
  let reversalConfirmed = false;
  let type: "bullish" | "bearish" | "none" = "none";

  // Check last 5 candles for a sudden dip below/above swing levels and then quick recovery
  for (const c of lastCandles) {
    const barBodySize = Math.abs(c.close - c.open);
    const wickLowerSize = Math.min(c.close, c.open) - c.low;
    const wickUpperSize = c.high - Math.max(c.close, c.open);

    // Bullish Stop Hunt: Low swept below swingLow but Closed above it (strong tail)
    if (c.low < swingLow && c.close > swingLow && wickLowerSize > barBodySize * 1.5) {
      stopHuntDetected = true;
      type = "bullish";
    }

    // Bearish Stop Hunt: High swept above swingHigh but Closed below it (strong nose)
    if (c.high > swingHigh && c.close < swingHigh && wickUpperSize > barBodySize * 1.5) {
      stopHuntDetected = true;
      type = "bearish";
    }
  }

  if (stopHuntDetected) {
    const lastCandle = candles[candles.length - 1];
    // Reversal is confirmed if last candle closes bullish for bullish stop hunt, or bearish for bearish
    if (type === "bullish" && lastCandle.close > lastCandle.open) {
      reversalConfirmed = true;
    } else if (type === "bearish" && lastCandle.close < lastCandle.open) {
      reversalConfirmed = true;
    }
  }

  return { stopHuntDetected, reversalConfirmed, type };
}

export function computeMomentum(candles: Candle[]): MomentumResult {
  if (candles.length < 12) {
    return { value: 0, direction: "NEUTRAL", crossedZero: false };
  }

  // Momentum of period 10 (Close vs Close[10])
  const currentClose = candles[candles.length - 1].close;
  const pastClose = candles[candles.length - 11].close;
  const value = currentClose - pastClose;

  const prevClose = candles[candles.length - 2].close;
  const prevPastClose = candles[candles.length - 12].close;
  const prevValue = prevClose - prevPastClose;

  const crossedZero = (prevValue < 0 && value > 0) || (prevValue > 0 && value < 0);
  const direction = value > 0 ? "UP" : value < 0 ? "DOWN" : "NEUTRAL";

  return { value, direction, crossedZero };
}

export function computeRSI(candles: Candle[], period: number = 14): number {
  if (candles.length <= period) return 50;

  let gains = 0;
  let losses = 0;

  for (let i = 1; i <= period; i++) {
    const diff = candles[candles.length - period - 1 + i].close - candles[candles.length - period - 2 + i].close;
    if (diff > 0) gains += diff;
    else losses -= diff;
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  for (let i = candles.length - period; i < candles.length; i++) {
    const diff = candles[i].close - candles[i - 1].close;
    avgGain = (avgGain * (period - 1) + (diff > 0 ? diff : 0)) / period;
    avgLoss = (avgLoss * (period - 1) + (diff < 0 ? -diff : 0)) / period;
  }

  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

export function computeKeltner(candles: Candle[]): KeltnerResult {
  const fallback = { center: 1.1, upper: 1.15, lower: 1.05, positionRatio: 0.5 };
  if (candles.length < 20) return fallback;

  const closes = candles.map(c => c.close);
  const centerLine = computeEMA(closes, 20);
  const center = centerLine[centerLine.length - 1] || closes[closes.length - 1];

  const atr = computeATR(candles, 20);
  const upper = center + 1.5 * atr;
  const lower = center - 1.5 * atr;

  const lastClose = closes[closes.length - 1];
  const positionRatio = (lastClose - lower) / (upper - lower || 0.0001);

  return { center, upper, lower, positionRatio };
}

export function computeBollingerBands(candles: Candle[]): BollingerResult {
  const fallback = { middle: 1.1, upper: 1.15, lower: 1.05, squeezingReleasing: false };
  if (candles.length < 20) return fallback;

  const closes = candles.map(c => c.close);
  const smas = computeSMA(closes, 20);
  const stddevs = computeStdDev(closes, 20);

  const middle = smas[smas.length - 1] || closes[closes.length - 1];
  const std = stddevs[stddevs.length - 1] || 0.001;

  const upper = middle + 2 * std;
  const lower = middle - 2 * std;

  // Let's identify squeezed states (bollinger bands narrow relative to ATR)
  const atr = computeATR(candles, 20);
  const bandWidth = upper - lower;
  const squeezingReleasing = bandWidth < 1.0 * atr; // Squeezing

  return { middle, upper, lower, squeezingReleasing };
}

export function detectCandlePattern(candles: Candle[]): CandlePatternResult {
  if (candles.length < 3) {
    return { detected: false, name: "Neutral Range" };
  }

  const c1 = candles[candles.length - 1];
  const c2 = candles[candles.length - 2];

  const c1Body = Math.abs(c1.close - c1.open);
  const c1Range = c1.high - c1.low || 0.001;
  const c1LowerWick = Math.min(c1.close, c1.open) - c1.low;
  const c1UpperWick = c1.high - Math.max(c1.close, c1.open);

  const c2Body = Math.abs(c2.close - c2.open);

  // Hammer Pattern (Bullish): Small body, very long lower wick
  if (c1LowerWick > c1Body * 2 && c1UpperWick < c1Body * 0.5 && c1Body / c1Range > 0.15) {
    return { detected: true, name: "Hammer" };
  }

  // Shooting Star Pattern (Bearish): Small body, very long upper wick
  if (c1UpperWick > c1Body * 2 && c1LowerWick < c1Body * 0.5 && c1Body / c1Range > 0.15) {
    return { detected: true, name: "Shooting Star" };
  }

  // Bullish Engulfing
  if (c1.close > c1.open && c2.close < c2.open && c1Body > c2Body * 1.3) {
    return { detected: true, name: "Bullish Engulfing" };
  }

  // Bearish Engulfing
  if (c1.close < c1.open && c2.close > c2.open && c1Body > c2Body * 1.3) {
    return { detected: true, name: "Bearish Engulfing" };
  }

  return { detected: false, name: "Normal Price Action" };
}

export function computeConfluenceScore(
  candles30s: Candle[],
  candles1m: Candle[],
  candles2m: Candle[],
  candles3m: Candle[]
) {
  let score = 0;
  const reasons: string[] = [];
  const conditions: Record<string, boolean | number> = {
    trendAlignment: 0,
    amdPhase3: 0,
    liquiditySweep: 0,
    momentumCross: 0,
    keltnerSqueeze: 0,
    candlePattern: 0,
  };

  // Ensure arrays are seeded
  if (!candles30s.length || !candles1m.length || !candles2m.length) {
    return {
      score: 55,
      direction: Direction.NEUTRAL,
      grade: "WAIT",
      reasons: ["Seeding technical data feed vectors..."],
      conditions,
    };
  }

  // CONDITION 1: Trend Alignment (20pts)
  const alligator30s = computeAlligator(candles30s);
  const alligator1m = computeAlligator(candles1m);
  const alligator2m = computeAlligator(candles2m);
  const trendDir = getTrendDirection(alligator1m);

  if (
    trendDir !== 0 &&
    getTrendDirection(alligator30s) === trendDir &&
    getTrendDirection(alligator2m) === trendDir
  ) {
    score += 20;
    conditions.trendAlignment = 20;
    reasons.push(
      trendDir > 0
        ? "Alligator bullish alignment on all timeframes"
        : "Alligator bearish alignment on all timeframes"
    );
  }

  // CONDITION 2: AMD Phase 3 (20pts)
  const amd = detectAMDPhase(candles1m, candles2m);
  if (amd.phase === 3) {
    score += 20;
    conditions.amdPhase3 = 20;
    reasons.push("AMD Phase 3 distribution expansion confirmed");
  } else {
    // Partial point support for phase 2 manipulation sweeps
    if (amd.phase === 2) {
      score += 10;
      conditions.amdPhase3 = 10;
      reasons.push("Phase 2 Manipulation wick sweep is forming liquidity peaks");
    }
  }

  // CONDITION 3: Liquidity Sweep (20pts)
  const liq = analyzeLiquidity(candles1m);
  if (liq.stopHuntDetected && liq.reversalConfirmed) {
    score += 20;
    conditions.liquiditySweep = 20;
    reasons.push(`Stop Hunt ${liq.type.toUpperCase()} sweep confirmed at swing border`);
  } else if (liq.stopHuntDetected) {
    score += 10;
    conditions.liquiditySweep = 10;
    reasons.push(`Stop hunt detected, awaiting confirmation bar`);
  }

  // CONDITION 4: Momentum Cross (15pts)
  const mom30s = computeMomentum(candles30s);
  const mom1m = computeMomentum(candles1m);
  const rsi1m = computeRSI(candles1m, 14);

  if (mom30s.direction === mom1m.direction) {
    if (mom30s.crossedZero && mom1m.crossedZero) {
      score += 15;
      conditions.momentumCross = 15;
      reasons.push("Dual momentum zero-cross triggered on 30s + 1m feeds");
    } else {
      score += 8;
      conditions.momentumCross = 8;
      reasons.push("Momentum indicators aligned in same direction");
    }
  }

  // CONDITION 5: Keltner + BB Squeeze (15pts)
  const kelt = computeKeltner(candles1m);
  const bb = computeBollingerBands(candles1m);
  if (
    (kelt.positionRatio < 0.12 || kelt.positionRatio > 0.88) &&
    bb.squeezingReleasing
  ) {
    score += 15;
    conditions.keltnerSqueeze = 15;
    reasons.push("Extreme channel push at Keltner margins during BB compression");
  } else if (kelt.positionRatio < 0.2 || kelt.positionRatio > 0.8) {
    score += 8;
    conditions.keltnerSqueeze = 8;
    reasons.push("Channel borders tested with moderate price expansion");
  }

  // CONDITION 6: Candle Pattern (10pts)
  const pattern = detectCandlePattern(candles1m);
  if (pattern.detected) {
    score += 10;
    conditions.candlePattern = 10;
    reasons.push(`High probability ${pattern.name} pattern detected at pivot`);
  }

  // Safety maximum capping
  if (score > 100) score = 100;

  // Determine direction
  let direction = Direction.NEUTRAL;
  if (score >= 96) {
    direction = trendDir > 0 ? Direction.BUY : Direction.SELL;
  } else if (score >= 80) {
    // Moderate triggers
    const lastClose1m = candles1m[candles1m.length - 1]?.close || 1;
    const openCloseDiff = lastClose1m - (candles1m[candles1m.length - 1]?.open || 0);
    direction = openCloseDiff >= 0 ? Direction.BUY : Direction.SELL;
  }

  // Grade placement
  const grade =
    score >= 96
      ? "PLATINUM"
      : score >= 88
      ? "GOLD"
      : score >= 80
      ? "SILVER"
      : "WAIT";

  return {
    score,
    direction,
    grade,
    reasons,
    conditions,
  };
}
