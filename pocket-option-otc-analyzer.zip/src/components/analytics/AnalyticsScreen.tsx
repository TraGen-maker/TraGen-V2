import { useMarket } from "../../store/marketStore";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  BarChart4,
  TrendingUp,
  CirclePercent,
  Timer,
  ChevronDown,
  Activity,
} from "lucide-react";
import { motion } from "motion/react";

export function AnalyticsScreen() {
  const { winRate, totalSignalsCount } = useMarket();

  // Mock backtest dataset representing clean, rising equity curve
  const equityCurveData = [
    { session: "Sess 1", equity: 1000, wins: 4, losses: 1 },
    { session: "Sess 2", equity: 1250, wins: 8, losses: 2 },
    { session: "Sess 3", equity: 1180, wins: 11, losses: 4 },
    { session: "Sess 4", equity: 1540, wins: 17, losses: 5 },
    { session: "Sess 5", equity: 1780, wins: 22, losses: 6 },
    { session: "Sess 6", equity: 2150, wins: 28, losses: 8 },
    { session: "Sess 7", equity: 2420, wins: 34, losses: 9 },
  ];

  // Success rate dataset per asset portfolio symbol
  const assetSuccessRates = [
    { symbol: "EURUSD", rate: 84 },
    { symbol: "GBPUSD", rate: 78 },
    { symbol: "USDJPY", rate: 81 },
    { symbol: "AUDUSD", rate: 74 },
    { symbol: "USDCAD", rate: 76 },
    { symbol: "EURJPY", rate: 79 },
    { symbol: "BTC", rate: 72 },
    { symbol: "GOLD", rate: 88 },
  ];

  // Custom tooltips matching theme colors
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-bg-surface border border-accent-cyan/20 p-3 rounded-xl shadow-[0_4px_20px_rgba(0,0,0,0.6)] backdrop-blur-md">
          <p className="text-[10px] font-orbitron font-semibold text-accent-cyan uppercase mb-1">
            {label}
          </p>
          <p className="text-xs font-mono font-bold text-text-light">
            Val: <span className="text-gold font-bold">{payload[0].value}</span>
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 pt-4 pb-32 space-y-6 select-none">
      {/* 1. ANALYTICAL PANEL COUNTERS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Net yields */}
        <div className="p-4 bg-bg-surface/75 border border-accent-cyan/15 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[10px] font-orbitron text-muted-blue block">SIMULATED BALANCE NET</span>
            <span className="text-2xl font-orbitron font-bold text-buy-green text-glow-cyan">+$2420.00</span>
            <span className="text-[10px] text-muted-blue block mt-1">+142% Over Baseline</span>
          </div>
          <div className="w-9 h-9 rounded-lg bg-buy-green/10 flex items-center justify-center text-buy-green border border-buy-green/15">
            <TrendingUp className="w-4 h-4 animate-bounce" />
          </div>
        </div>

        {/* Win percentage */}
        <div className="p-4 bg-bg-surface/75 border border-accent-cyan/15 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[10px] font-orbitron text-gold block">SYSTEM WIN AVERAGE</span>
            <span className="text-2xl font-orbitron font-extrabold text-gold text-glow-cyan">{winRate}%</span>
            <span className="text-[10px] text-muted-blue block mt-1">Calculated across logs</span>
          </div>
          <div className="w-9 h-9 rounded-lg bg-gold/10 flex items-center justify-center text-gold border border-gold/15">
            <CirclePercent className="w-4 h-4" />
          </div>
        </div>

        {/* Average Expiry Duration */}
        <div className="p-4 bg-bg-surface/75 border border-accent-purple/15 rounded-2xl flex items-center justify-between font-sans">
          <div>
            <span className="text-[10px] font-orbitron text-accent-purple block">AVG SYSTEM EXPIRY</span>
            <span className="text-xl font-orbitron font-bold text-accent-purple">60.0 SECONDS</span>
            <span className="text-[10px] text-muted-blue block mt-1">High-Volume boundary speed</span>
          </div>
          <div className="w-9 h-9 rounded-lg bg-accent-purple/10 flex items-center justify-center text-accent-purple border border-accent-purple/15">
            <Timer className="w-4 h-4" />
          </div>
        </div>

        {/* Risk limits Drawdowns */}
        <div className="p-4 bg-bg-surface/75 border border-accent-cyan/15 rounded-2xl flex items-center justify-between font-sans">
          <div>
            <span className="text-[10px] font-orbitron text-muted-blue block">MAX RISK DRAWDOWN</span>
            <span className="text-2xl font-orbitron font-bold text-glow-cyan text-accent-cyan">0.82%</span>
            <span className="text-[10px] text-muted-blue block mt-1">Strict Margin Management</span>
          </div>
          <div className="w-9 h-9 rounded-lg bg-accent-cyan/10 flex items-center justify-center text-accent-cyan border border-accent-cyan/15">
            <Activity className="w-4 h-4" />
          </div>
        </div>
      </div>

      {/* 2. AREA AND BAR CHARTS MATRIX ROW */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Equity area chart (Left block) */}
        <div className="p-6 bg-bg-surface/75 border border-accent-cyan/10 rounded-2xl space-y-4 shadow-xl">
          <div className="flex justify-between items-center border-b border-white/5 pb-2">
            <div className="flex items-center gap-2">
              <BarChart4 className="w-4.5 h-4.5 text-accent-cyan" />
              <h2 className="text-xs font-orbitron font-extrabold text-glow-cyan text-text-light uppercase tracking-wide">
                Cumulative Backtested Equity Curve ($)
              </h2>
            </div>
            <span className="text-[9px] font-mono text-muted-blue">UNIT: USD</span>
          </div>

          <div className="w-full h-64 font-sans text-[11px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={equityCurveData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorEquity" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00E5FF" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#7B2FFF" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.02)" />
                <XAxis dataKey="session" stroke="#4A6FA5" tickLine={false} />
                <YAxis stroke="#4A6FA5" tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="equity"
                  stroke="#00E5FF"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#colorEquity)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Success rate bar chart per asset (Right block) */}
        <div className="p-6 bg-bg-surface/75 border border-accent-cyan/10 rounded-2xl space-y-4 shadow-xl">
          <div className="flex justify-between items-center border-b border-white/5 pb-2">
            <div className="flex items-center gap-2">
              <Activity className="w-4.5 h-4.5 text-gold" />
              <h2 className="text-xs font-orbitron font-extrabold text-glow-gold text-text-light uppercase tracking-wide">
                Portfolios Confluence Target Win Rates
              </h2>
            </div>
            <span className="text-[9px] font-mono text-gold">LIMIT: 96%</span>
          </div>

          <div className="w-full h-64 font-sans text-[11px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={assetSuccessRates} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.02)" />
                <XAxis dataKey="symbol" stroke="#4A6FA5" tickLine={false} />
                <YAxis stroke="#4A6FA5" domain={[50, 100]} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="rate" radius={[4, 4, 0, 0]}>
                  {assetSuccessRates.map((entry, index) => (
                    <rect
                      key={`rect-${index}`}
                      fill={entry.rate >= 80 ? "rgba(0, 255, 136, 0.65)" : "rgba(123, 47, 255, 0.65)"}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

    </div>
  );
}
