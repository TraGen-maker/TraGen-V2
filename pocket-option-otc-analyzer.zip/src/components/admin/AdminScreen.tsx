import { useState, useEffect } from "react";
import { useAuth } from "../../store/authStore";
import { useAdmin } from "../../store/adminStore";
import {
  Users,
  Key,
  Wifi,
  Megaphone,
  AlertTriangle,
  RotateCcw,
  CheckCircle,
  Eye,
  EyeOff,
  UserCheck,
  ShieldCheck,
  UserX,
  Volume2,
  Trash2,
} from "lucide-react";
import { motion } from "motion/react";

export function AdminScreen() {
  const { currentUser } = useAuth();
  const {
    dailyCode,
    codeHistory,
    users,
    maintenanceMode,
    soundAlerts,
    ssidToken,
    ssidConnected,
    welcomeMessage,
    generateNewAccessCode,
    setCustomAccessCode,
    fetchUsers,
    toggleUserStatus,
    deleteUser,
    toggleUserAdmin,
    setMaintenanceMode,
    setSsidToken,
    setWelcomeMessage,
  } = useAdmin();

  const [customCode, setCustomCode] = useState("");
  const [broadcastInput, setBroadcastInput] = useState(welcomeMessage);
  const [ssidInput, setSsidInput] = useState(ssidToken);
  const [showSsid, setShowSsid] = useState(false);
  const [activeTab, setActiveTab] = useState<"users" | "codes" | "ssid" | "broadcast" | "controls">("users");

  useEffect(() => {
    fetchUsers();
  }, []);

  // Filter out the active user themselves so they don't lock themselves out or delete themselves
  const manageableUsers = users.filter(u => u.id !== currentUser?.id);

  const handleCustomCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customCode.trim()) return;
    setCustomAccessCode(customCode);
    setCustomCode("");
  };

  const handleBroadcastSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setWelcomeMessage(broadcastInput);
  };

  const handleSsidSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSsidToken(ssidInput);
  };

  const menuTabs = [
    { id: "users" as const, label: "Users Table", icon: Users },
    { id: "codes" as const, label: "Access Codes", icon: Key },
    { id: "ssid" as const, label: "SSID Tunnel", icon: Wifi },
    { id: "broadcast" as const, label: "Banner Broadcast", icon: Megaphone },
  ];

  return (
    <div className="w-full max-w-7xl mx-auto px-4 pt-4 pb-32 space-y-6">
      
      {/* 1. ADMIN PANEL CONTROL GAUGES */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 select-none">
        <div className="p-4 bg-bg-surface/75 border border-accent-cyan/15 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[10px] font-orbitron text-muted-blue block">TOTAL USERS REG</span>
            <span className="text-2xl font-orbitron font-bold text-text-light">{users.length}</span>
          </div>
          <div className="w-9 h-9 rounded-lg bg-accent-cyan/10 flex items-center justify-center text-accent-cyan border border-accent-cyan/15">
            <Users className="w-4 h-4" />
          </div>
        </div>

        <div className="p-4 bg-bg-surface/75 border border-accent-cyan/15 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[10px] font-orbitron text-muted-blue block">DAILY ACTIVE KEY</span>
            <span className="text-xl font-mono font-bold text-gold text-glow-cyan">
              {dailyCode?.code || "X7K-9P2"}
            </span>
          </div>
          <div className="w-9 h-9 rounded-lg bg-gold/10 flex items-center justify-center text-gold border border-gold/15">
            <Key className="w-4 h-4" />
          </div>
        </div>

        <div className="p-4 bg-bg-surface/75 border border-accent-cyan/15 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[10px] font-orbitron text-muted-blue block">SSID TUNNEL STATUS</span>
            <span
              className={`text-sm font-semibold tracking-wide uppercase ${
                ssidConnected ? "text-buy-green" : "text-sell-red"
              }`}
            >
              {ssidConnected ? "WEB-SOCKET CONNECTED" : "TUNNEL STANDBY"}
            </span>
          </div>
          <div
            className={`w-9 h-9 rounded-lg flex items-center justify-center border ${
              ssidConnected
                ? "bg-buy-green/10 text-buy-green border-buy-green/15"
                : "bg-sell-red/10 text-sell-red border-sell-red/15"
            }`}
          >
            <Wifi className={`w-4 h-4 ${ssidConnected ? "animate-pulse" : ""}`} />
          </div>
        </div>

        <div className="p-4 bg-bg-surface/75 border border-accent-purple/15 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[10px] font-orbitron text-muted-blue block">MAINTENANCE SYSTEM</span>
            <span
              className={`text-sm font-semibold tracking-wide uppercase ${
                maintenanceMode ? "text-gold" : "text-muted-blue"
              }`}
            >
              {maintenanceMode ? "ACTIVE LOCK ON" : "STANDARD FREEWAY"}
            </span>
          </div>
          <button
            id="toggle_maintenance"
            type="button"
            onClick={() => setMaintenanceMode(!maintenanceMode)}
            className={`w-12 h-6 px-1 rounded-full flex items-center transition-colors cursor-pointer outline-none focus:outline-none shrink-0 ${
              maintenanceMode ? "bg-gold" : "bg-gray-800"
            }`}
          >
            <motion.div
              layout
              className="w-4 h-4 bg-bg-deep rounded-full shadow"
              animate={{ x: maintenanceMode ? 24 : 0 }}
              transition={{ type: "spring", stiffness: 500, damping: 30 }}
            />
          </button>
        </div>
      </div>

      {/* 2. INNER LAYOUT ROUTING TABS */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Navigation row (Left sidebar) */}
        <div className="lg:col-span-1 flex flex-row lg:flex-col gap-1 overflow-x-auto select-none border-b lg:border-b-0 lg:border-r border-accent-cyan/10 pb-4 lg:pb-0 lg:pr-4">
          {menuTabs.map(tab => {
            const isSelected = activeTab === tab.id;
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                id={`admin_tab_${tab.id}`}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2.5 px-4 py-3 rounded-xl text-xs font-orbitron font-bold uppercase tracking-wider text-left transition-all w-full flex-shrink-0 cursor-pointer outline-none focus:outline-none ${
                  isSelected
                    ? "text-accent-cyan border border-accent-cyan bg-accent-cyan/5 shadow-[0_0_12px_rgba(0,229,255,0.15)]"
                    : "text-muted-blue border border-transparent hover:bg-white/5"
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Dynamic Display Panel (Right block) */}
        <div className="lg:col-span-3">
          {activeTab === "users" && (
            /* USER COMPONENT PANEL (Section 4.2) */
            <div className="p-6 bg-bg-surface/75 border border-accent-cyan/10 rounded-2xl space-y-4 shadow-xl">
              <h2 className="text-sm font-orbitron font-extrabold text-glow-cyan text-text-light uppercase tracking-wider border-b border-white/5 pb-2">
                Active Traders Profile Room
              </h2>

              <div className="space-y-3.5 max-h-[380px] overflow-y-auto pr-1">
                {manageableUsers.length === 0 ? (
                  <div className="p-8 text-center bg-bg-deep/40 rounded-xl select-none text-muted-blue text-xs italic font-sans">
                    No secondary traders are currently registered on server.
                  </div>
                ) : (
                  manageableUsers.map(user => {
                    const isSuspended = user.status === "suspended";
                    return (
                      <div
                        key={user.id}
                        className="p-4 bg-bg-deep/30 border border-white/5 rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 transition-all hover:border-accent-cyan/15"
                      >
                        <div className="space-y-1 select-none flex-1">
                          <h3 className="text-xs font-semibold uppercase tracking-wider text-text-light">
                            {user.fullName} / <span className="text-accent-cyan">@{user.username}</span>
                          </h3>
                          <p className="text-[10px] text-muted-blue font-sans">{user.email}</p>
                          <span
                            className={`text-[9px] font-orbitron font-bold px-1 rounded inline-block ${
                              isSuspended ? "bg-sell-red/10 text-sell-red" : "bg-buy-green/10 text-buy-green"
                            }`}
                          >
                            STATUS: {user.status.toUpperCase()}
                          </span>
                        </div>

                        {/* User configuration actions */}
                        <div className="flex gap-2">
                          <button
                            id={`btn_toggle_status_${user.id}`}
                            type="button"
                            onClick={() => toggleUserStatus(user.id)}
                            className={`px-3 py-1.5 rounded-lg font-orbitron text-[9px] font-bold uppercase tracking-wider cursor-pointer select-none border transition-all ${
                              isSuspended
                                ? "bg-buy-green/10 hover:bg-buy-green text-buy-green hover:text-bg-deep border-buy-green/20 hover:border-buy-green"
                                : "bg-sell-red/10 hover:bg-sell-red text-sell-red hover:text-white border-sell-red/20 hover:border-sell-red"
                            }`}
                          >
                            {isSuspended ? "REACTIVATE" : "SUSPEND"}
                          </button>

                          <button
                            id={`btn_toggle_admin_${user.id}`}
                            type="button"
                            onClick={() => toggleUserAdmin(user.id)}
                            className="px-3 py-1.5 bg-accent-purple/10 border border-accent-purple/20 hover:bg-accent-purple text-accent-purple hover:text-white rounded-lg font-orbitron text-[9px] font-bold uppercase tracking-wider cursor-pointer select-none transition-all"
                          >
                            {user.isAdmin ? "REVOKE ADMIN" : "GRANT ADMIN"}
                          </button>

                          <button
                            id={`btn_delete_user_${user.id}`}
                            type="button"
                            onClick={() => deleteUser(user.id)}
                            className="px-3 py-1.5 bg-transparent text-muted-blue hover:text-sell-red hover:bg-sell-red/10 rounded-lg cursor-pointer transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {activeTab === "codes" && (
            /* ACCESS CODES GENERATOR AND HISTORY TRACKER (Section 4.1) */
            <div className="p-6 bg-bg-surface/75 border border-accent-cyan/10 rounded-2xl space-y-4 shadow-xl">
              <h2 className="text-sm font-orbitron font-extrabold text-glow-cyan text-text-light uppercase tracking-wider border-b border-white/5 pb-2">
                Daily Access Keys Manager
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Codes actions */}
                <div className="space-y-4">
                  <div className="p-4 bg-bg-deep/40 rounded-xl border border-white/5 select-none text-center space-y-2">
                    <span className="text-[10px] uppercase font-bold text-muted-blue font-orbitron block">
                      Active Access Key
                    </span>
                    <span className="text-2xl font-mono font-bold tracking-widest text-gold text-glow-cyan animate-pulse">
                      {dailyCode?.code}
                    </span>
                    <p className="text-[10px] text-muted-blue font-sans leading-relaxed">
                      Generated at: {dailyCode ? new Date(dailyCode.createdAt).toLocaleTimeString() : "--"}
                    </p>
                  </div>

                  <div className="flex gap-2.5">
                    <button
                      id="btn_randomize_code"
                      type="button"
                      onClick={generateNewAccessCode}
                      className="flex-1 height-11 rounded-xl bg-accent-cyan hover:bg-accent-cyan/85 text-bg-deep font-orbitron font-bold text-xs uppercase tracking-wider h-11 transition-all cursor-pointer shadow-[0_0_15px_rgba(0,229,255,0.35)]"
                    >
                      RANDOMIZE ACTIVE KEY
                    </button>
                  </div>

                  {/* Custom Code setter */}
                  <form onSubmit={handleCustomCodeSubmit} className="space-y-2">
                    <label className="text-[10px] font-orbitron uppercase text-muted-blue tracking-wider font-semibold block">
                      Set Custom Access Code
                    </label>
                    <div className="flex gap-2">
                      <input
                        id="input_custom_code"
                        type="text"
                        value={customCode}
                        onChange={e => setCustomCode(e.target.value)}
                        placeholder="EX: EXP-78M"
                        maxLength={8}
                        className="flex-1 h-11 px-4 text-xs bg-bg-deep/40 rounded-xl border border-accent-cyan/15 focus:border-accent-cyan text-text-light placeholder-muted-blue outline-none transition-all uppercase font-semibold"
                      />
                      <button
                        id="btn_submit_custom_code"
                        type="submit"
                        className="px-4 bg-gradient-to-r from-accent-purple to-accent-cyan rounded-xl text-xs font-orbitron font-bold text-white uppercase tracking-wider shadow hover:scale-103 active:scale-97 cursor-pointer h-11"
                      >
                        SET CODE
                      </button>
                    </div>
                  </form>
                </div>

                {/* Code History tracker */}
                <div className="space-y-2">
                  <span className="text-[10px] uppercase font-bold text-muted-blue font-orbitron block border-b border-white/5 pb-1 select-none">
                    Keys Session History logs
                  </span>
                  
                  <div className="space-y-2 max-h-[220px] overflow-y-auto">
                    {codeHistory.map((entry, idx) => (
                      <div
                        key={idx}
                        className="p-3 bg-bg-deep/30 border border-white/5 rounded-xl flex justify-between items-center text-xs"
                      >
                        <div>
                          <span className="font-mono font-bold text-text-light tracking-wide block">
                            {entry.code}
                          </span>
                          <span className="text-[9px] text-muted-blue font-sans">
                            Assigned: {new Date(entry.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        <span className="text-[10px] font-mono text-accent-cyan font-bold">
                          {entry.usersUsed || 1} USER VERIFY
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            </div>
          )}

          {activeTab === "ssid" && (
            /* WEBSOCKET TOKENS CONFIGURATION MANAGER (Section 4.3) */
            <div className="p-6 bg-bg-surface/75 border border-accent-cyan/10 rounded-2xl space-y-4 shadow-xl">
              <h2 className="text-sm font-orbitron font-extrabold text-glow-cyan text-text-light uppercase tracking-wider border-b border-white/5 pb-2">
                SSID Websocket Token Interceptors
              </h2>

              <div className="p-4 bg-bg-deep/40 rounded-xl border border-white/5 flex items-start gap-3 select-none">
                <AlertTriangle className="w-5 h-5 text-gold shrink-0 mt-0.5" />
                <p className="text-[11px] text-muted-blue leading-relaxed font-sans">
                  The Pocket Option system parses real-time price tick feeds from standard client-side secure socket channels. Input your authentic session SSID identifier below to intercept and synchronize calculations.
                </p>
              </div>

              <form onSubmit={handleSsidSubmit} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-orbitron uppercase text-muted-blue tracking-wider font-semibold block">
                    Session SSID Socket Key Token
                  </label>
                  <div className="relative">
                    <input
                      id="input_ssid_token"
                      type={showSsid ? "text" : "password"}
                      value={ssidInput}
                      onChange={e => setSsidInput(e.target.value)}
                      placeholder="Input session identifier token string..."
                      className="w-full h-11 pl-4 pr-12 text-xs bg-bg-deep/40 rounded-xl border border-accent-cyan/15 focus:border-accent-cyan text-text-light placeholder-muted-blue outline-none transition-all font-sans"
                    />
                    <button
                      id="btn_toggle_ssid_show"
                      type="button"
                      onClick={() => setShowSsid(!showSsid)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-blue hover:text-accent-cyan cursor-pointer"
                    >
                      {showSsid ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
                    </button>
                  </div>
                </div>

                <div className="flex justify-between items-center pt-2">
                  <span className="text-[10px] text-muted-blue font-sans">
                    Identity Status:{" "}
                    <strong className={ssidConnected ? "text-buy-green" : "text-sell-red"}>
                      {ssidConnected ? "VALID IDENTIFIED CONNECTED" : "UNBOUND INTERCEPT OFF"}
                    </strong>
                  </span>
                  
                  <button
                    id="btn_ssid_commit"
                    type="submit"
                    className="height-11 rounded-xl px-5 h-11 bg-gradient-to-r from-accent-purple to-accent-cyan text-xs font-orbitron font-bold text-white uppercase tracking-wider hover:scale-103 active:scale-97 cursor-pointer"
                  >
                    COMMIT SOCKET INTERCEPT
                  </button>
                </div>
              </form>
            </div>
          )}

          {activeTab === "broadcast" && (
            /* WELCOME BANNER BROADCAST STRING PUSHER (Section 4.4) */
            <div className="p-6 bg-bg-surface/75 border border-accent-cyan/10 rounded-2xl space-y-4 shadow-xl">
              <h2 className="text-sm font-orbitron font-extrabold text-glow-cyan text-text-light uppercase tracking-wider border-b border-white/5 pb-2">
                System Broadcast Live Message Banner
              </h2>

              <p className="text-xs text-muted-blue font-sans leading-relaxed select-none">
                Submit custom text alerts to broadcast live onto active trader dashboards instantly. Keep notices under 140 characters.
              </p>

              <form onSubmit={handleBroadcastSubmit} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-orbitron uppercase text-muted-blue tracking-wider font-semibold block select-none">
                    Broadcast String Notice
                  </label>
                  <textarea
                    id="input_broadcast_string"
                    value={broadcastInput}
                    onChange={e => setBroadcastInput(e.target.value)}
                    rows={3}
                    maxLength={160}
                    placeholder="Broadcast text line..."
                    className="w-full p-4 text-xs bg-bg-deep/40 rounded-xl border border-accent-cyan/15 focus:border-accent-cyan text-text-light placeholder-muted-blue outline-none transition-all font-sans"
                  />
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    id="btn_commit_broadcast"
                    type="submit"
                    className="height-11 rounded-xl px-6 h-11 bg-gradient-to-r from-accent-purple to-accent-cyan text-xs font-orbitron font-bold text-white uppercase tracking-wider hover:scale-103 active:scale-97 cursor-pointer"
                  >
                    BROADCAST MSG
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
