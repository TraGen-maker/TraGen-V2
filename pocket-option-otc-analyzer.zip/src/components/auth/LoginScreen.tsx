import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../store/authStore";
import { useAdmin } from "../../store/adminStore";
import { ParticleField } from "../shared/ParticleField";
import { FloatingOrbs } from "../shared/FloatingOrbs";
import { User, Lock, Key, Eye, EyeOff, AlertTriangle, Phone, RefreshCw, ShieldAlert } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export function LoginScreen() {
  const { loginUser, error, setError } = useAuth();
  const { setCustomAccessCode } = useAdmin();
  const navigate = useNavigate();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [accessCode, setAccessCode] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [shake, setShake] = useState(false);
  const [loginSuccess, setLoginSuccess] = useState(false);

  // Seed default admin recovery phone number if empty
  useEffect(() => {
    if (!localStorage.getItem("po_admin_recovery_phone")) {
      localStorage.setItem("po_admin_recovery_phone", "0597670096");
    }
  }, []);

  // Admin Gateway Panel States
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [adminUsername, setAdminUsername] = useState("wsmforex");
  const [adminPassword, setAdminPassword] = useState("");
  const [adminNewCode, setAdminNewCode] = useState("");
  const [adminError, setAdminError] = useState<string | null>(null);
  const [adminSuccess, setAdminSuccess] = useState<string | null>(null);

  // Eye toggle for admin password
  const [showAdminPassword, setShowAdminPassword] = useState(false);

  // Recovery Password Panel (Forgot Password Setting)
  const [showRecoveryPanel, setShowRecoveryPanel] = useState(false);
  const [recoveryPhone, setRecoveryPhone] = useState("");
  const [recoveryNewPassword, setRecoveryNewPassword] = useState("");
  const [recoveryConfirmPassword, setRecoveryConfirmPassword] = useState("");
  const [showRecoveryNewPassword, setShowRecoveryNewPassword] = useState(false);

  const handleGenerateRandomCode = () => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let randomCode = "";
    for (let i = 0; i < 6; i++) {
      if (i === 3) randomCode += "-";
      randomCode += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setAdminNewCode(randomCode);
  };

  const handleUpdateCode = () => {
    setAdminError(null);
    setAdminSuccess(null);

    const activeAdminPass = localStorage.getItem("po_admin_gateway_password") || "wsmforex1";

    if (adminUsername.trim().toLowerCase() !== "wsmforex") {
      setAdminError("Verification failed. Invalid administrator username.");
      return;
    }

    if (adminPassword !== activeAdminPass) {
      setAdminError("Authentication failure: Incorrect security password.");
      return;
    }

    const upperNewCode = adminNewCode.trim().toUpperCase();
    if (!upperNewCode) {
      setAdminError("Daily Access Key cannot be blank.");
      return;
    }

    try {
      setCustomAccessCode(upperNewCode);
      setAdminSuccess(`Access Key set to: ${upperNewCode}`);
      setAccessCode(upperNewCode); // Autofill on central login state
      setAdminPassword(""); // Clear security input
    } catch (e: any) {
      setAdminError(e?.message || "Failed to update Access Code.");
    }
  };

  const handleResetPassword = () => {
    setAdminError(null);
    setAdminSuccess(null);

    const cleanedInput = recoveryPhone.replace(/[\s-+]/g, "");
    const allowedPhones = ["0597670096", "0535729491"];
    const isMatched = allowedPhones.some(phone => phone.replace(/[\s-+]/g, "") === cleanedInput);

    if (!cleanedInput || !isMatched) {
      setAdminError("Verification Failed: Recovery phone number does not match registered admin profile.");
      return;
    }

    if (!recoveryNewPassword || !recoveryConfirmPassword) {
      setAdminError("Please fill in both password fields.");
      return;
    }

    if (recoveryNewPassword !== recoveryConfirmPassword) {
      setAdminError("New passwords do not match.");
      return;
    }

    if (recoveryNewPassword.length < 6) {
      setAdminError("Security password must be at least 6 characters.");
      return;
    }

    try {
      localStorage.setItem("po_admin_gateway_password", recoveryNewPassword);
      
      // Update account row in user database so login credentials align
      const storedUsers = localStorage.getItem("po_users");
      if (storedUsers) {
        const usersList: any[] = JSON.parse(storedUsers);
        const adminAccount = usersList.find(u => u.username === "wsmforex");
        if (adminAccount) {
          adminAccount.passwordHash = btoa(recoveryNewPassword);
          localStorage.setItem("po_users", JSON.stringify(usersList));
        }
      }

      setAdminSuccess("Identity confirmed. Admin Security Password successfully updated!");
      setRecoveryPhone("");
      setRecoveryNewPassword("");
      setRecoveryConfirmPassword("");
      setShowRecoveryPanel(false);
    } catch (err) {
      setAdminError("Failed to persist security reset.");
    }
  };

  // Time calculation mapping today's midnight reset
  const [timeRemaining, setTimeRemaining] = useState("");

  useEffect(() => {
    setError(null);

    const updateTimer = () => {
      const now = new Date();
      const midnight = new Date();
      midnight.setHours(23, 59, 59, 999);

      const diff = midnight.getTime() - now.getTime();
      if (diff <= 0) {
        setTimeRemaining("00:00:00");
        return;
      }

      const hrs = Math.floor(diff / (1000 * 60 * 60));
      const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const secs = Math.floor((diff % (1000 * 60)) / 1000);

      const pad = (num: number) => num.toString().padStart(2, "0");
      setTimeRemaining(`${pad(hrs)}:${pad(mins)}:${pad(secs)}`);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [setError]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password || !accessCode) {
      setError("Please fill out all authorization fields.");
      setShake(true);
      setTimeout(() => setShake(false), 150);
      return;
    }

    setIsSubmitting(true);
    const success = await loginUser(username, password, accessCode);

    if (success) {
      setLoginSuccess(true);
      navigate("/dashboard"); // Route instantly without delay!
    } else {
      setIsSubmitting(false);
      setShake(true);
      setTimeout(() => setShake(false), 150);
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center p-6 bg-bg-deep select-none">
      <ParticleField />
      <FloatingOrbs />

      {/* Subtle Grid overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,0,0,0)_0%,rgba(5,11,24,0.9)_80%)] -z-30 pointer-events-none" />
      <div
        className="absolute inset-0 bg-transparent pointer-events-none -z-30 opacity-[0.04]"
        style={{
          backgroundImage: `
            linear-gradient(to right, #00E5FF 1px, transparent 1px),
            linear-gradient(to bottom, #00E5FF 1px, transparent 1px)
          `,
          backgroundSize: "24px 24px",
        }}
      />

      {/* Center card containing form */}
      <motion.div
        animate={shake ? { x: [-10, 10, -10, 10, -5, 5, 0] } : {}}
        transition={{ duration: 0.5 }}
        className="relative w-full max-w-md"
      >
        {/* Animated Gradient Edge */}
        <div className="absolute -inset-[2px] bg-gradient-to-r from-accent-cyan via-accent-purple to-accent-cyan rounded-3xl blur-[3px] opacity-40 animate-pulse" />

        {/* Real Form Box */}
        <div className="relative p-8 rounded-[22px] bg-bg-surface/90 border border-accent-cyan/15 backdrop-blur-2xl shadow-[0_0_80px_rgba(0,229,255,0.08)]">
          
          {/* Logo and Header text */}
          <div className="text-center mb-6">
            <motion.h1
              id="login_logo"
              className="text-4xl font-extrabold font-orbitron tracking-wider text-accent-cyan text-glow-cyan"
              animate={{ textShadow: ["0 0 10px rgba(0,229,255,0.4)", "0 0 25px rgba(0,229,255,0.7)", "0 0 10px rgba(0,229,255,0.4)"] }}
              transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
            >
              TraGen v2.0
            </motion.h1>
            <p className="text-xs font-semibold uppercase tracking-widest text-muted-blue mt-2">
              Professional Signal Intelligence
            </p>
            <div className="w-16 h-[2px] bg-gradient-to-r from-transparent via-accent-cyan to-transparent mx-auto mt-4 shadow-[0_0_8px_rgba(0,229,255,0.8)]" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Username Input */}
            <div className="space-y-1">
              <label className="text-[10px] font-orbitron uppercase text-muted-blue tracking-wider font-semibold block">
                Trader Username
              </label>
              <div className="relative">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-blue">
                  <User className="w-5 h-5" />
                </div>
                <input
                  id="login_username"
                  type="text"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  placeholder="Enter username"
                  className="w-full h-12 pl-12 pr-4 text-sm bg-bg-deep/40 rounded-xl border border-accent-cyan/15 focus:border-accent-cyan focus:shadow-[0_0_15px_rgba(0,229,255,0.15)] text-text-light placeholder-muted-blue outline-none transition-all font-sans"
                />
              </div>
            </div>

            {/* Password Input */}
            <div className="space-y-1">
              <label className="text-[10px] font-orbitron uppercase text-muted-blue tracking-wider font-semibold block">
                Security Password
              </label>
              <div className="relative">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-blue">
                  <Lock className="w-5 h-5" />
                </div>
                <input
                  id="login_password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="w-full h-12 pl-12 pr-12 text-sm bg-bg-deep/40 rounded-xl border border-accent-cyan/15 focus:border-accent-cyan focus:shadow-[0_0_15px_rgba(0,229,255,0.15)] text-text-light placeholder-muted-blue outline-none transition-all font-sans"
                />
                <button
                  id="login_toggle_password"
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-blue hover:text-accent-cyan cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Daily Access Code Input */}
            <div className="space-y-1">
              <label className="text-[10px] font-orbitron uppercase text-muted-blue tracking-wider font-semibold block">
                Daily Access Key
              </label>
              <div className="relative">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-blue">
                  <Key className="w-5 h-5" />
                </div>
                <input
                  id="login_access_code"
                  type="text"
                  value={accessCode}
                  onChange={e => setAccessCode(e.target.value)}
                  placeholder="Today's access code"
                  className="w-full h-12 pl-12 pr-4 text-sm bg-bg-deep/40 rounded-xl border border-accent-cyan/15 focus:border-accent-cyan focus:shadow-[0_0_15px_rgba(0,229,255,0.15)] text-text-light placeholder-muted-blue outline-none transition-all uppercase tracking-wider font-sans font-semibold"
                />
              </div>
              <div className="flex justify-between items-center px-1 mt-1">
                <span className="text-[9px] text-muted-blue font-sans">
                  Get keys from official support room
                </span>
                <span className="text-[9px] text-gold font-mono font-medium flex items-center gap-1">
                  Expires in: {timeRemaining}
                </span>
              </div>
            </div>

            {/* Feedback Error Banner */}
            <AnimatePresence>
              {error && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="flex items-start gap-2 p-3 rounded-xl bg-sell-red/10 border border-sell-red/30"
                >
                  <AlertTriangle className="w-4 h-4 text-sell-red shrink-0 mt-0.5" />
                  <span className="text-[11px] text-sell-red font-sans leading-relaxed">{error}</span>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Submit Button */}
            <motion.button
              id="login_submit"
              type="submit"
              disabled={isSubmitting || loginSuccess}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className={`w-full h-[52px] rounded-xl font-orbitron uppercase tracking-widest font-bold text-sm text-white select-none relative overflow-hidden transition-all duration-300 ${
                loginSuccess
                  ? "bg-buy-green shadow-[0_0_25px_rgba(0,255,136,0.5)] border border-buy-green"
                  : "bg-gradient-to-r from-accent-cyan to-accent-purple shadow-[0_0_30px_rgba(0,229,255,0.2)] hover:shadow-[0_0_40px_rgba(0,229,255,0.45)] cursor-pointer"
              }`}
            >
              <div className="absolute inset-0 bg-white/10 opacity-0 hover:opacity-100 transition-opacity" />
              {isSubmitting ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-4.5 h-4.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  AUTHENTICATING...
                </span>
              ) : loginSuccess ? (
                "ACCESS GRANTED"
              ) : (
                "LOGIN"
              )}
            </motion.button>
          </form>

          {/* Under footer register trigger link */}
          <div className="text-center mt-6">
            <Link
              id="link_to_register"
              to="/register"
              className="text-xs text-accent-cyan hover:underline hover:text-white transition-colors animate-pulse"
            >
              Don't have an account? Register →
            </Link>
          </div>

          {/* Secure Admin Control Gateway */}
          <div className="border-t border-white/5 my-5 pt-4 text-center">
            <button
              id="btn_admin_portal_toggle"
              type="button"
              onClick={() => {
                setShowAdminPanel(!showAdminPanel);
                setAdminError(null);
                setAdminSuccess(null);
              }}
              className="text-[10px] text-muted-blue hover:text-accent-cyan font-orbitron uppercase tracking-widest transition-colors flex items-center justify-center gap-1.5 mx-auto cursor-pointer py-1 px-3 rounded-md bg-white/[0.02] hover:bg-white/[0.05] border border-white/5"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              {showAdminPanel ? "Close Admin Gateway" : "Admin Gateway Override"}
            </button>
          </div>

          <AnimatePresence>
            {showAdminPanel && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden border border-accent-cyan/10 bg-bg-deep/70 rounded-xl p-4 mt-3 space-y-3.5"
              >
                <div className="flex justify-between items-center pb-2 border-b border-white/5">
                  <span className="text-[10px] font-orbitron font-extrabold uppercase tracking-widest text-accent-cyan text-glow-cyan">
                    {showRecoveryPanel ? "SECURITY RECOVERY MODULE" : "GATEWAY ROOT CONSOLE"}
                  </span>
                  <button
                    id="btn_admin__switch_panel"
                    type="button"
                    onClick={() => {
                      setShowRecoveryPanel(!showRecoveryPanel);
                      setAdminError(null);
                      setAdminSuccess(null);
                    }}
                    className="text-[9px] font-mono text-accent-purple hover:underline"
                  >
                    {showRecoveryPanel ? "← Back to Gateway Login" : "Forgot Password?"}
                  </button>
                </div>

                {!showRecoveryPanel ? (
                  /* Standard Admin Access Code Rotation */
                  <div className="space-y-3 font-sans">
                    <p className="text-[10px] text-muted-blue leading-relaxed text-left">
                      Sign in as <b className="text-text-light">wsmforex</b> to calibrate or override the system-wide active key.
                    </p>

                    <div className="space-y-2.5 text-left">
                      {/* Operator username */}
                      <div>
                        <label className="text-[9px] font-orbitron uppercase text-muted-blue tracking-wider block mb-1">
                          Admin Username
                        </label>
                        <input
                          id="admin_portal_username"
                          type="text"
                          value={adminUsername}
                          onChange={e => setAdminUsername(e.target.value)}
                          placeholder="wsmforex"
                          className="w-full h-9 px-3 text-xs bg-black/30 rounded-lg border border-white/10 text-text-light outline-none focus:border-accent-cyan font-sans"
                        />
                      </div>

                      {/* Operator password */}
                      <div>
                        <label className="text-[9px] font-orbitron uppercase text-muted-blue tracking-wider block mb-1">
                          Gateway Password
                        </label>
                        <div className="relative">
                          <input
                            id="admin_portal_password"
                            type={showAdminPassword ? "text" : "password"}
                            value={adminPassword}
                            onChange={e => setAdminPassword(e.target.value)}
                            placeholder="••••••••"
                            className="w-full h-9 pl-3 pr-10 text-xs bg-black/30 rounded-lg border border-white/10 text-text-light outline-none focus:border-accent-cyan font-sans"
                          />
                          <button
                            type="button"
                            onClick={() => setShowAdminPassword(!showAdminPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-blue hover:text-accent-cyan"
                          >
                            {showAdminPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>

                      {/* Entry space for daily code */}
                      <div>
                        <label className="text-[9px] font-orbitron uppercase text-muted-blue tracking-wider block mb-1">
                          Target Daily Access Code
                        </label>
                        <div className="flex gap-2">
                          <input
                            id="admin_portal_new_code"
                            type="text"
                            value={adminNewCode}
                            onChange={e => setAdminNewCode(e.target.value)}
                            placeholder="e.g. TR-998"
                            className="flex-grow h-9 px-3 text-xs bg-black/30 rounded-lg border border-white/10 text-text-light font-mono font-bold tracking-widest uppercase outline-none focus:border-accent-cyan"
                          />
                          <button
                            id="btn_admin_portal_random"
                            type="button"
                            onClick={handleGenerateRandomCode}
                            className="px-2.5 h-9 text-[9px] bg-accent-purple/15 border border-accent-purple/30 text-accent-purple hover:bg-accent-purple/20 rounded-lg font-orbitron transition-all uppercase cursor-pointer shrink-0"
                          >
                            Auto Gen
                          </button>
                        </div>
                      </div>
                    </div>

                    <button
                      id="btn_admin_portal_apply"
                      type="button"
                      onClick={handleUpdateCode}
                      className="w-full h-10 mt-2 bg-gradient-to-r from-accent-cyan to-accent-purple hover:shadow-[0_0_12px_rgba(0,229,255,0.2)] text-white text-[11px] font-orbitron font-bold uppercase tracking-wider rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      Apply Access Code
                    </button>
                  </div>
                ) : (
                  /* Forgot Password / Recovery Panel */
                  <div className="space-y-3 font-sans text-left">
                    <p className="text-[10px] text-muted-blue leading-relaxed">
                      Verify authorized admin recovery number to update Gateway Security Password. Authorized Numbers: <span className="text-accent-cyan font-mono font-semibold">0597670096 or 0535729491</span>
                    </p>

                    <div className="space-y-2.5">
                      {/* Phone Number Input */}
                      <div>
                        <label className="text-[9px] font-orbitron uppercase text-muted-blue tracking-wider block mb-1">
                          Recovery Phone Number
                        </label>
                        <div className="relative">
                          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-blue">
                            <Phone className="w-3.5 h-3.5" />
                          </div>
                          <input
                            id="admin_recovery_phone"
                            type="text"
                            value={recoveryPhone}
                            onChange={e => setRecoveryPhone(e.target.value)}
                            placeholder="Enter matching number"
                            className="w-full h-9 pl-9 pr-3 text-xs bg-black/30 rounded-lg border border-white/10 text-text-light focus:border-accent-cyan outline-none font-mono tracking-wider"
                          />
                        </div>
                      </div>

                      {/* New Password Input */}
                      <div>
                        <label className="text-[9px] font-orbitron uppercase text-muted-blue tracking-wider block mb-1">
                          New Security Password
                        </label>
                        <div className="relative">
                          <input
                            id="admin_recovery_new_pass"
                            type={showRecoveryNewPassword ? "text" : "password"}
                            value={recoveryNewPassword}
                            onChange={e => setRecoveryNewPassword(e.target.value)}
                            placeholder="At least 6 characters"
                            className="w-full h-9 pl-3 pr-10 text-xs bg-black/30 rounded-lg border border-white/10 text-text-light focus:border-accent-cyan outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => setShowRecoveryNewPassword(!showRecoveryNewPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-blue"
                          >
                            {showRecoveryNewPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>

                      {/* Confirmed Password */}
                      <div>
                        <label className="text-[9px] font-orbitron uppercase text-muted-blue tracking-wider block mb-1">
                          Confirm Password
                        </label>
                        <input
                          id="admin_recovery_conf_pass"
                          type="password"
                          value={recoveryConfirmPassword}
                          onChange={e => setRecoveryConfirmPassword(e.target.value)}
                          placeholder="Verify spelling"
                          className="w-full h-9 px-3 text-xs bg-black/30 rounded-lg border border-white/10 text-text-light focus:border-accent-cyan outline-none"
                        />
                      </div>
                    </div>

                    <button
                      id="btn_admin_recovery_apply"
                      type="button"
                      onClick={handleResetPassword}
                      className="w-full h-10 mt-2 bg-gradient-to-r from-accent-purple to-pink-600 hover:shadow-[0_0_12px_rgba(236,72,153,0.2)] text-white text-[11px] font-orbitron font-bold uppercase tracking-wider rounded-lg transition-all cursor-pointer"
                    >
                      Update Security Password
                    </button>
                  </div>
                )}

                {/* Status Alerts Block */}
                <AnimatePresence>
                  {adminError && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="p-2.5 rounded-lg bg-sell-red/10 border border-sell-red/20 text-[9px] text-sell-red leading-relaxed text-left flex items-start gap-1"
                    >
                      <AlertTriangle className="w-3.5 h-3.5 text-sell-red shrink-0" />
                      <span>{adminError}</span>
                    </motion.div>
                  )}

                  {adminSuccess && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="p-2.5 rounded-lg bg-buy-green/10 border border-buy-green/20 text-[9px] text-buy-green leading-relaxed text-left flex items-start gap-1"
                    >
                      <ShieldAlert className="w-3.5 h-3.5 text-buy-green shrink-0 animate-pulse" />
                      <span>{adminSuccess}</span>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            )}
          </AnimatePresence>



        </div>
      </motion.div>
    </div>
  );
}
