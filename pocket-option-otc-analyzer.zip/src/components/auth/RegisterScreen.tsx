import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../store/authStore";
import { ParticleField } from "../shared/ParticleField";
import { FloatingOrbs } from "../shared/FloatingOrbs";
import { User, Mail, Shield, Check, Lock, Key, AlertTriangle, Eye, EyeOff } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export function RegisterScreen() {
  const { registerUser, error, setError } = useAuth();
  const navigate = useNavigate();

  // Form Fields
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [accessCode, setAccessCode] = useState("");

  const [step, setStep] = useState(1);
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [regSuccess, setRegSuccess] = useState(false);
  const [redirectCount, setRedirectCount] = useState(2);

  // Clean error overlay on load
  useEffect(() => {
    setError(null);
  }, [setError]);

  // Handle auto-redirect countdown once registered successfully
  useEffect(() => {
    if (regSuccess) {
      const handle = setInterval(() => {
        setRedirectCount(prev => {
          if (prev <= 1) {
            clearInterval(handle);
            navigate("/dashboard");
            return 0;
          }
          return prev - 1;
        });
      }, 100);
      return () => clearInterval(handle);
    }
  }, [regSuccess, navigate]);

  // Password evaluation meter
  const getPasswordStrength = (pass: string) => {
    if (!pass) return { score: 0, label: "Empty", color: "bg-gray-700", width: "w-0" };
    let score = 0;
    if (pass.length >= 6) score += 1;
    if (/[A-Z]/.test(pass)) score += 1;
    if (/[0-9]/.test(pass)) score += 1;
    if (/[^A-Za-z0-9]/.test(pass)) score += 1;

    switch (score) {
      case 1:
        return { score, label: "Weak", color: "bg-sell-red shadow-[0_0_8px_#FF3B6B]", width: "w-1/4" };
      case 2:
        return { score, label: "Fair", color: "bg-orange-500 shadow-[0_0_8px_#FF8800]", width: "w-2/4" };
      case 3:
        return { score, label: "Strong", color: "bg-accent-purple shadow-[0_0_8px_#7B2FFF]", width: "w-3/4" };
      case 4:
        return { score, label: "Very Strong", color: "bg-buy-green shadow-[0_0_8px_#00FF88]", width: "w-full" };
      default:
        return { score: 0, label: "Weak", color: "bg-sell-red shadow-[0_0_8px_#FF3B6B]", width: "w-1/6" };
    }
  };

  const strength = getPasswordStrength(password);

  const handleNextStep = () => {
    setError(null);
    if (!fullName || !username || !email) {
      setError("Please complete all personal details before proceeding.");
      return;
    }
    if (!email.includes("@") || !email.includes(".")) {
      setError("Please input a valid email structure.");
      return;
    }
    setStep(2);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!password || !confirmPassword || !accessCode) {
      setError("Please complete all security questions.");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    if (password.length < 6) {
      setError("Password must have at least 6 characters.");
      return;
    }

    setIsSubmitting(true);
    const success = await registerUser(
      {
        fullName,
        username,
        email,
        passwordHash: password,
      },
      accessCode
    );

    setIsSubmitting(false);
    if (success) {
      setRegSuccess(true);
      navigate("/dashboard"); // Route instantly to keep response incredibly quick!
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center p-6 bg-bg-deep select-none">
      <ParticleField />
      <FloatingOrbs />

      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,0,0,0)_0%,rgba(5,11,24,0.9)_80%)] -z-30 pointer-events-none" />

      <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="relative w-full max-w-md">
        <div className="absolute -inset-[2px] bg-gradient-to-r from-accent-purple via-accent-cyan to-accent-purple rounded-3xl blur-[3px] opacity-40 animate-pulse" />

        <div className="relative p-8 rounded-[22px] bg-bg-surface/90 border border-accent-cyan/15 backdrop-blur-2xl shadow-[0_0_80px_rgba(0,229,255,0.08)]">
          
          <div className="text-center mb-6">
            <h1 className="text-3xl font-extrabold font-orbitron tracking-wider text-accent-cyan text-glow-cyan mb-1">
              JOIN TraGen v2.0
            </h1>
            <p className="text-[10px] uppercase font-semibold text-muted-blue tracking-widest">
              Account Registration Protocol
            </p>
          </div>

          <AnimatePresence mode="wait">
            {!regSuccess ? (
              <form onSubmit={handleRegister} className="space-y-4">
                
                {step === 1 ? (
                  /* STEP 1: Personal Info */
                  <motion.div
                    key="step1"
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    exit={{ x: 20, opacity: 0 }}
                    className="space-y-4"
                  >
                    {/* Full Name */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-orbitron uppercase text-muted-blue tracking-wider font-semibold">
                        Full Name
                      </label>
                      <div className="relative">
                        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-blue">
                          <User className="w-5 h-5" />
                        </div>
                        <input
                          id="reg_fullname"
                          type="text"
                          value={fullName}
                          onChange={e => setFullName(e.target.value)}
                          placeholder="Your display name"
                          className="w-full h-12 pl-12 pr-4 text-sm bg-bg-deep/40 rounded-xl border border-accent-cyan/15 focus:border-accent-cyan text-text-light placeholder-muted-blue outline-none transition-all font-sans"
                        />
                      </div>
                    </div>

                    {/* Username */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-orbitron uppercase text-muted-blue tracking-wider font-semibold">
                        Trader Username
                      </label>
                      <div className="relative">
                        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-blue">
                          <User className="w-5 h-5" />
                        </div>
                        <input
                          id="reg_username"
                          type="text"
                          value={username}
                          onChange={e => setUsername(e.target.value)}
                          placeholder="Create handle username"
                          className="w-full h-12 pl-12 pr-4 text-sm bg-bg-deep/40 rounded-xl border border-accent-cyan/15 focus:border-accent-cyan text-text-light placeholder-muted-blue outline-none transition-all font-sans"
                        />
                      </div>
                    </div>

                    {/* Email */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-orbitron uppercase text-muted-blue tracking-wider font-semibold">
                        Email Address
                      </label>
                      <div className="relative">
                        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-blue">
                          <Mail className="w-5 h-5" />
                        </div>
                        <input
                          id="reg_email"
                          type="email"
                          value={email}
                          onChange={e => setEmail(e.target.value)}
                          placeholder="name@gmail.com"
                          className="w-full h-12 pl-12 pr-4 text-sm bg-bg-deep/40 rounded-xl border border-accent-cyan/15 focus:border-accent-cyan text-text-light placeholder-muted-blue outline-none transition-all font-sans"
                        />
                      </div>
                    </div>

                    {/* Progress Indicator and Action */}
                    <div className="space-y-3 pt-2">
                      <div className="flex justify-between items-center text-[10px] text-muted-blue">
                        <span>STEP 1 OF 2: INFO</span>
                        <div className="flex gap-1.5 items-center">
                          <span className="w-2 h-2 rounded-full bg-accent-cyan" />
                          <span className="w-2 h-2 rounded-full bg-accent-cyan" />
                          <span className="w-2 h-2 rounded-full bg-gray-600" />
                        </div>
                      </div>
                      <div className="w-full h-1 bg-gray-800 rounded-full overflow-hidden">
                        <div className="w-2/3 h-full bg-accent-cyan rounded-full" />
                      </div>

                      <button
                        id="reg_next_step"
                        type="button"
                        onClick={handleNextStep}
                        className="w-full h-12 bg-gradient-to-r from-accent-cyan to-accent-purple rounded-xl font-orbitron uppercase font-bold text-sm text-white tracking-wider shadow-[0_0_20px_rgba(0,229,255,0.2)] hover:scale-[1.02] active:scale-[0.98] cursor-pointer transition-all duration-200"
                      >
                        CONTINUE SETUP →
                      </button>
                    </div>

                  </motion.div>
                ) : (
                  /* STEP 2: Security & Code check */
                  <motion.div
                    key="step2"
                    initial={{ x: 20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    exit={{ x: -20, opacity: 0 }}
                    className="space-y-4"
                  >
                    {/* Password */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-orbitron uppercase text-muted-blue tracking-wider font-semibold block">
                        Account Password
                      </label>
                      <div className="relative">
                        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-blue">
                          <Lock className="w-5 h-5" />
                        </div>
                        <input
                          id="reg_password"
                          type={showPassword ? "text" : "password"}
                          value={password}
                          onChange={e => setPassword(e.target.value)}
                          placeholder="Min 6 characters"
                          className="w-full h-12 pl-12 pr-12 text-sm bg-bg-deep/40 rounded-xl border border-accent-cyan/15 focus:border-accent-cyan text-text-light placeholder-muted-blue outline-none transition-all font-sans"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-blue"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>

                      {/* Password safety dynamic meter bar */}
                      <div className="space-y-1.5 pt-1">
                        <div className="flex justify-between items-center text-[9px] font-bold font-orbitron">
                          <span className="text-muted-blue">STRENGTH:</span>
                          <span
                            className={
                              strength.score === 1
                                ? "text-sell-red"
                                : strength.score === 2
                                ? "text-orange-400"
                                : strength.score === 3
                                ? "text-accent-purple"
                                : strength.score === 4
                                ? "text-buy-green"
                                : "text-gray-500"
                            }
                          >
                            {strength.label.toUpperCase()}
                          </span>
                        </div>
                        <div className="w-full h-[3px] bg-gray-800 rounded-full overflow-hidden">
                          <div className={`h-full rounded-full transition-all duration-300 ${strength.color} ${strength.width}`} />
                        </div>
                      </div>
                    </div>

                    {/* Confirm Password */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-orbitron uppercase text-muted-blue tracking-wider font-semibold block">
                        Confirm Password
                      </label>
                      <div className="relative">
                        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-blue">
                          <Lock className="w-5 h-5" />
                        </div>
                        <input
                          id="reg_confirm_password"
                          type={showPassword ? "text" : "password"}
                          value={confirmPassword}
                          onChange={e => setConfirmPassword(e.target.value)}
                          placeholder="Repeat password"
                          className="w-full h-12 pl-12 pr-4 text-sm bg-bg-deep/40 rounded-xl border border-accent-cyan/15 focus:border-accent-cyan text-text-light placeholder-muted-blue outline-none transition-all font-sans"
                        />
                      </div>
                    </div>

                    {/* Access code */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-orbitron uppercase text-muted-blue tracking-wider font-semibold block">
                        Daily Access Code Verification
                      </label>
                      <div className="relative">
                        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-blue">
                          <Key className="w-5 h-5" />
                        </div>
                        <input
                          id="reg_access_code"
                          type="text"
                          value={accessCode}
                          onChange={e => setAccessCode(e.target.value)}
                          placeholder="EX: X7K-9P2"
                          className="w-full h-12 pl-12 pr-4 text-sm bg-bg-deep/40 rounded-xl border border-accent-cyan/15 focus:border-accent-cyan text-text-light placeholder-muted-blue outline-none transition-all uppercase tracking-wider font-semibold"
                        />
                      </div>
                    </div>

                    {/* Step bar */}
                    <div className="space-y-3 pt-2">
                      <div className="flex justify-between items-center text-[10px] text-muted-blue">
                        <span>STEP 2 OF 2: SECURITY</span>
                        <div className="flex gap-1.5 items-center">
                          <span className="w-2 h-2 rounded-full bg-accent-cyan" />
                          <span className="w-2 h-2 rounded-full bg-accent-cyan" />
                          <span className="w-2 h-2 rounded-full bg-accent-cyan" />
                        </div>
                      </div>
                      <div className="w-full h-1 bg-gray-800 rounded-full overflow-hidden">
                        <div className="w-full h-full bg-accent-cyan rounded-full" />
                      </div>

                      <div className="flex gap-3 pt-1">
                        <button
                          type="button"
                          onClick={() => setStep(1)}
                          className="flex-1 h-12 rounded-xl bg-bg-deep border border-accent-cyan/15 hover:border-accent-cyan text-muted-blue hover:text-white font-orbitron text-xs select-none uppercase tracking-wider transition-all duration-200"
                        >
                          ← BACK
                        </button>
                        <button
                          id="reg_submit"
                          type="submit"
                          disabled={isSubmitting}
                          className="flex-[2] h-12 bg-gradient-to-r from-accent-purple to-accent-cyan font-orbitron font-bold text-sm rounded-xl text-white tracking-widest shadow-[0_0_20px_rgba(123,47,255,0.3)] hover:scale-[1.015] active:scale-[0.985] cursor-pointer"
                        >
                          {isSubmitting ? "REGISTERS..." : "COMPLETE JOIN"}
                        </button>
                      </div>
                    </div>

                  </motion.div>
                )}

                {/* Error Box */}
                <AnimatePresence>
                  {error && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="flex items-start gap-2 p-3 rounded-xl bg-sell-red/10 border border-sell-red/30 text-sell-red text-[11px] font-sans leading-relaxed"
                    >
                      <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                      <span>{error}</span>
                    </motion.div>
                  )}
                </AnimatePresence>

              </form>
            ) : (
              /* Success state welcome redirects countdown card */
              <motion.div
                key="success"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="text-center py-6 space-y-4"
              >
                <div className="w-16 h-16 bg-buy-green/10 text-buy-green border-2 border-buy-green shadow-[0_0_20px_rgba(0,255,136,0.3)] rounded-full flex items-center justify-center mx-auto mb-2 select-none animate-bounce">
                  <Check className="w-8 h-8" />
                </div>
                <h2 className="text-xl font-orbitron font-bold text-buy-green text-glow-green">
                  REGISTRATION COMPLETED!
                </h2>
                <div className="space-y-1">
                  <p className="text-sm text-text-light font-medium">
                    Welcome to TraGen v2.0, {fullName}!
                  </p>
                  <p className="text-[11px] text-muted-blue font-sans">
                    Secure broker terminal seed complete. Directing onto central servers in:{" "}
                    <span className="font-mono text-gold font-bold text-sm">{redirectCount}s</span>
                  </p>
                </div>
                <div className="w-24 h-1 bg-gray-800 rounded-full mx-auto overflow-hidden">
                  <motion.div
                    className="h-full bg-buy-green"
                    initial={{ width: "0%" }}
                    animate={{ width: "100%" }}
                    transition={{ duration: 2, ease: "linear" }}
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Under link footer */}
          <div className="text-center mt-6">
            <Link
              to="/login"
              className="text-xs text-accent-cyan hover:underline hover:text-white transition-colors"
            >
              Already registered? Login →
            </Link>
          </div>

        </div>
      </motion.div>
    </div>
  );
}
