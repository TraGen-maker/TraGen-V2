import { useState, useMemo, useEffect, useRef } from "react";
import { useMarket } from "../../store/marketStore";
import { ASSETS_DATA, AssetInfo } from "../../data/assetsData";
import { Search, X, TrendingUp, TrendingDown, ChevronDown, Check } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface AssetSelectorProps {
  onCloseMobileDrawer?: () => void;
  isMobileDrawerOpen?: boolean;
}

export function AssetSelector({ onCloseMobileDrawer, isMobileDrawerOpen }: AssetSelectorProps) {
  const { selectedAsset, setAsset, activePrice, priceChangePercent24h } = useMarket();
  const [searchQuery, setSearchQuery] = useState("");
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);

  // Filter list in real time
  const filteredAssets = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return ASSETS_DATA;
    return ASSETS_DATA.filter(
      (asset) =>
        asset.name.toLowerCase().includes(query) ||
        asset.ticker.toLowerCase().includes(query) ||
        asset.id.toLowerCase().includes(query)
    );
  }, [searchQuery]);

  // Group filtered results by category
  const categoriesMap = useMemo(() => {
    const map: Record<string, AssetInfo[]> = {
      FOREX: [],
      STOCKS: [],
      CRYPTO: [],
      COMMODITIES: [],
      INDICES: [],
    };
    filteredAssets.forEach((asset) => {
      if (map[asset.category]) {
        map[asset.category].push(asset);
      }
    });
    return map;
  }, [filteredAssets]);

  // Generate ticking live prices deterministic
  const getPriceForAsset = (assetId: string) => {
    if (assetId === selectedAsset) {
      return activePrice;
    }
    let base = 1.0500;
    if (assetId.includes("JPY")) base = 155.20;
    else if (assetId.includes("BTC")) base = 67250.0;
    else if (assetId.includes("ETH")) base = 3450.0;
    else if (assetId.includes("GOLD") || assetId.includes("XAU")) base = 2320.5;
    else if (assetId.includes("XAG") || assetId.includes("SILVER")) base = 28.40;
    else if (assetId.includes("OIL") || assetId.includes("WTI")) base = 78.50;
    else if (assetId.includes("AAPL")) base = 175.40;
    else if (assetId.includes("GOOGL")) base = 160.20;
    else if (assetId.includes("MSFT")) base = 415.80;
    else if (assetId.includes("TSLA")) base = 180.50;
    else if (assetId.includes("NVDA")) base = 850.30;
    else if (assetId.includes("AMZN")) base = 185.10;
    else if (assetId.includes("US500")) base = 5120.00;
    else if (assetId.includes("US100")) base = 18100.00;
    else if (assetId.includes("US30")) base = 38900.00;
    else if (assetId.includes("UK100")) base = 8200.00;
    else if (assetId.includes("DE30")) base = 18500.00;
    else if (assetId.includes("FR40")) base = 8000.00;
    else if (assetId.includes("JP225")) base = 38800.00;
    else if (assetId.includes("AU200")) base = 7700.00;
    else if (assetId.includes("GBP")) base = 1.2650;
    else if (assetId.includes("AUD")) base = 0.6650;
    else if (assetId.includes("CAD")) base = 1.3620;
    else if (assetId.includes("CHF")) base = 0.8950;
    else if (assetId.includes("NZD")) base = 0.6120;
    else if (assetId.includes("SGD")) base = 1.3450;
    else if (assetId.includes("MXN")) base = 16.850;
    else if (assetId.includes("ZAR")) base = 18.200;
    else if (assetId.includes("TRY")) base = 32.400;

    const noise = Math.sin(assetId.charCodeAt(2) + Date.now() / 4000) * (base * 0.00015);
    return base + noise;
  };

  const getAssetDecimals = (assetId: string) => {
    if (assetId.includes("JPY")) return 3;
    if (assetId.includes("BTC")) return 1;
    if (assetId.includes("ETH")) return 1;
    if (assetId.includes("GOLD") || assetId.includes("XAU") || assetId.includes("OIL") || assetId.includes("WTI")) return 2;
    if (assetId.includes("SILVER") || assetId.includes("XAG")) return 3;
    if (assetId.includes("STOCK") || assetId.includes("AAPL") || assetId.includes("GOOGL") || assetId.includes("MSFT") || assetId.includes("TSLA") || assetId.includes("AMZN") || assetId.includes("NVDA") || assetId.includes("META") || assetId.includes("NFLX")) return 2;
    if (assetId.includes("US500") || assetId.includes("US100") || assetId.includes("US30") || assetId.includes("DE30")) return 1;
    return 5;
  };

  const getAssetIcon = (asset: AssetInfo) => {
    const cat = asset.category;
    if (cat === "FOREX") {
      return (
        <div className="w-8 h-8 rounded-lg bg-accent-cyan/10 border border-accent-cyan/20 flex items-center justify-center text-[9px] font-bold text-accent-cyan font-orbitron shrink-0">
          {asset.ticker.slice(0, 2)}
        </div>
      );
    } else if (cat === "STOCKS") {
      return (
        <div className="w-8 h-8 rounded-lg bg-accent-purple/10 border border-accent-purple/20 flex items-center justify-center text-[9px] font-bold text-accent-purple font-orbitron shrink-0">
          {asset.ticker.slice(0, 2)}
        </div>
      );
    } else if (cat === "CRYPTO") {
      return (
        <div className="w-8 h-8 rounded-lg bg-gold/10 border border-gold/20 flex items-center justify-center text-[9px] font-bold text-gold font-orbitron shrink-0">
          {asset.ticker === "BTC" ? "₿" : asset.ticker === "ETH" ? "Ξ" : asset.ticker.slice(0, 2)}
        </div>
      );
    } else if (cat === "COMMODITIES") {
      return (
        <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-[9px] font-bold text-amber-500 font-orbitron shrink-0">
          {asset.ticker}
        </div>
      );
    } else {
      return (
        <div className="w-8 h-8 rounded-lg bg-sell-red/10 border border-sell-red/20 flex items-center justify-center text-[9px] font-bold text-sell-red font-orbitron shrink-0">
          {asset.ticker.slice(0, 3)}
        </div>
      );
    }
  };

  const handleSelectAsset = (assetId: string) => {
    setAsset(assetId);
    if (onCloseMobileDrawer) {
      onCloseMobileDrawer();
    }
  };

  // Scroll active item into view on mount or change
  useEffect(() => {
    if (!scrollContainerRef.current) return;
    const activeEl = scrollContainerRef.current.querySelector('[data-active="true"]');
    if (activeEl) {
      activeEl.scrollIntoView({ block: "nearest", behavior: "smooth" });
    }
  }, [selectedAsset]);

  const categoryHeaders: Record<string, string> = {
    FOREX: "── FOREX OTC ──",
    STOCKS: "── STOCKS OTC ──",
    CRYPTO: "── CRYPTO OTC ──",
    COMMODITIES: "── COMMODITIES OTC ──",
    INDICES: "── INDICES OTC ──",
  };

  return (
    <div className="flex flex-col h-full bg-bg-surface border border-accent-cyan/10 rounded-2xl overflow-hidden glass-panel">
      {/* Search Bar Block */}
      <div className="p-4 border-b border-accent-cyan/5 bg-bg-deep/40 space-y-2">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted" />
          <input
            id="asset_search_input"
            type="text"
            placeholder="Search pair or ticker..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-bg-surface2/60 border border-accent-cyan/15 rounded-xl py-2 pl-9 pr-8 text-xs text-text placeholder-muted focus:outline-none focus:border-accent-cyan transition-colors"
          />
          {searchQuery && (
            <button
              id="clear_search_btn"
              type="button"
              onClick={() => setSearchQuery("")}
              className="absolute right-3 top-2.5 hover:text-accent-cyan text-muted transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Asset Vertical List */}
      <div
        ref={scrollContainerRef}
        id="vertical_asset_scroller"
        className="flex-grow overflow-y-auto scrollbar-thin scrollbar-track-transparent scrollbar-thumb-accent-cyan/20 scroll-smooth pr-1"
        style={{ scrollBehavior: "smooth" }}
      >
        {filteredAssets.length === 0 ? (
          <div className="p-8 text-center space-y-2">
            <span className="block text-xs font-orbitron text-gold uppercase tracking-widest text-glow-cyan">
              NO CONFLUENCE ALIGNMENTS
            </span>
            <p className="text-[11px] text-muted leading-relaxed">
              No matching assets found for &ldquo;{searchQuery}&rdquo;. Try another term or scroll OTC listings.
            </p>
          </div>
        ) : (
          Object.keys(categoriesMap).map((catName) => {
            const list = categoriesMap[catName];
            if (list.length === 0) return null;

            return (
              <div key={catName} className="relative pb-2">
                {/* Categorical Dividers */}
                <div className="sticky top-0 bg-bg-surface/90 backdrop-blur-md px-4 py-2 z-15 select-none self-center text-center">
                  <span className="text-[10px] font-orbitron font-extrabold tracking-widest text-[#4A6FA5] uppercase">
                    {categoryHeaders[catName]}
                  </span>
                </div>

                <div className="divide-y divide-accent-cyan/5">
                  {list.map((asset) => {
                    const isActive = asset.id === selectedAsset;
                    const change = priceChangePercent24h[asset.id] || 0.35;
                    const isUp = change >= 0;
                    const currentPrice = getPriceForAsset(asset.id);
                    const decimals = getAssetDecimals(asset.id);

                    return (
                      <button
                        key={asset.id}
                        id={`asset_item_${asset.id}`}
                        data-active={isActive}
                        onClick={() => handleSelectAsset(asset.id)}
                        className={`w-full flex items-center justify-between p-3.5 transition-all text-left outline-none relative cursor-pointer border-l-[3px] select-none ${
                          isActive
                            ? "bg-accent-cyan/10 border-accent-cyan text-text"
                            : "bg-transparent border-transparent hover:bg-bg-surface2/30 text-text/80 hover:text-text"
                        }`}
                      >
                        {/* Glow indicator on left */}
                        {isActive && (
                          <div className="absolute left-0 top-0 bottom-0 w-[4px] bg-accent-cyan blur-[2px] opacity-80" />
                        )}

                        <div className="flex items-center gap-3">
                          {getAssetIcon(asset)}
                          <div>
                            <span className="block text-xs font-orbitron font-semibold tracking-wide text-text">
                              {asset.name.replace(" OTC", "")}
                            </span>
                            <span className="block text-[10px] text-muted font-sans uppercase">
                              {asset.category} <span className="text-[9px] px-1 rounded bg-bg-surface2 opacity-60">OTC</span>
                            </span>
                          </div>
                        </div>

                        <div className="text-right space-y-0.5">
                          <span className="block text-xs font-mono font-medium tracking-tight text-accent-cyan text-glow-cyan">
                            {currentPrice.toFixed(decimals)}
                          </span>
                          <span
                            className={`inline-flex items-center gap-0.5 text-[10px] font-mono font-bold px-1 rounded-sm ${
                              isUp ? "bg-buy-green/10 text-buy-green" : "bg-sell-red/10 text-sell-red"
                            }`}
                          >
                            {isUp ? <TrendingUp className="w-2.5 h-2.5" /> : <TrendingDown className="w-2.5 h-2.5" />}
                            {isUp ? "+" : ""}
                            {change.toFixed(2)}%
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Selected Metadata Footer for alignment */}
      <div className="p-3 border-t border-accent-cyan/5 bg-bg-deep/35 text-[10px] font-orbitron text-center uppercase tracking-wider text-muted select-none">
        Active Liquidity Hub • {filteredAssets.length} Pairs Online
      </div>
    </div>
  );
}
