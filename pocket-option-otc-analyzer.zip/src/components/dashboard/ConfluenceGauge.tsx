import { useMarket } from "../../store/marketStore";
import { computeConfluenceScore } from "../../engine/confluenceEngine";
import { CheckCircle2, Circle, HelpCircle } from "lucide-react";
import { motion } from "motion/react";
import { Timeframe } from "../../types";

export function ConfluenceGauge() {
  const { liveCandles, selectedAsset } = useMarket();

  // Draw indicators check based on current active liveCandles
  const fallbackScore = {
    score: 55,
    direction: "NEUTRAL",
    grade: "WAIT" as const,
    reasons: ["Awaiting market ticks verification..."],
    conditions: {
      trendAlignment: 0,
      amdPhase3: 0,
      liquiditySweep: 0,
      momentumCross: 0,
      keltnerSqueeze: 0,
      candlePattern: 0,
    },
  };

  const getConfluence = () => {
    if (!liveCandles || liveCandles.length < 40) return fallbackScore;
    try {
      // In a real framework, we gather all active timeframes;
      // for computing locally we can pass slices of our live feed representing TFs
      const c30s = liveCandles.slice(-15);
      const c1m = liveCandles;
      const c2m = liveCandles.slice(0, Math.floor(liveCandles.length * 0.8));
      const c3m = liveCandles.slice(0, Math.floor(liveCandles.length * 0.6));

      return computeConfluenceScore(c30s, c1m, c2m, c3m);
    } catch (e) {
      return fallbackScore;
    }
  };

  const confInfo = getConfluence();
  const score = confInfo.score;
  const grade = confInfo.grade;

  // Grade styled markers
  const getGradeStyles = () => {
    switch (grade) {
      case "PLATINUM":
        return { text: "text-accent-cyan", bg: "bg-accent-cyan/10", border: "border-accent-cyan/40", glow: "shadow-[0_0_20px_#00E5FF]" };
      case "GOLD":
        return { text: "text-gold", bg: "bg-gold/10", border: "border-gold/40", glow: "shadow-[0_0_20px_#FFD700]" };
      case "SILVER":
        return { text: "text-slate-300", bg: "bg-slate-300/10", border: "border-slate-300/30", glow: "shadow-[0_0_20px_#ffffff]" };
      default:
        return { text: "text-muted-blue", bg: "bg-muted-blue/5", border: "border-transparent", glow: "" };
    }
  };

  const colors = getGradeStyles();

  // Dial path properties
  const radius = 60;
  const circumference = 2 * Math.PI * radius;
  const fillOffset = circumference - (score / 100) * circumference;

  return (
    <div className="glass-panel p-6 rounded-2xl border border-accent-cyan/10 flex flex-col md:flex-row gap-6 items-center">
      
      {/* Visual Dial (Left side) */}
      <div className="relative flex-shrink-0 select-none">
        
        {/* Glow halo behind */}
        <div className={`absolute inset-0 rounded-full blur-xl opacity-20 filter ${colors.glow}`} />

        <svg className="w-40 h-40 transform -rotate-90">
          {/* Background circle */}
          <circle
            cx="80"
            cy="80"
            r={radius}
            className="stroke-bg-surface2"
            strokeWidth="8"
            fill="transparent"
          />
          {/* Active Dial fill */}
          <motion.circle
            cx="80"
            cy="80"
            r={radius}
            className={`stroke-current ${colors.text} filter drop-shadow-[0_0_6px_rgba(0,229,255,0.4)]`}
            strokeWidth="10"
            strokeDasharray={circumference}
            animate={{ strokeDashoffset: fillOffset }}
            transition={{ duration: 1, ease: "easeOut" }}
            fill="transparent"
            strokeLinecap="round"
          />
        </svg>

        {/* Center Text Labels */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="text-3xl font-orbitron font-extrabold text-glow-cyan text-text-light tracking-tight">
            {score}%
          </span>
          <span className="text-[10px] uppercase font-bold text-muted-blue font-orbitron tracking-wider">
            CONFLUENCE
          </span>
          <div className={`px-2.5 py-0.5 mt-2 rounded font-orbitron font-bold text-[10px] tracking-widest border border-accent-cyan/15 ${colors.text} ${colors.bg}`}>
            {grade}
          </div>
        </div>

      </div>

      {/* Conditions list (Right side) */}
      <div className="flex-1 w-full space-y-3">
        <h3 className="text-xs uppercase font-orbitron font-bold tracking-wider text-text-light text-glow-cyan border-b border-accent-cyan/10 pb-2">
          Confluence Matrix Solvers
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
          {/* Item 1 */}
          <div className="flex items-center justify-between p-2 rounded-lg bg-bg-surface2/40 border border-white/5">
            <span className="text-muted-blue font-sans">Multi-TF Alligator</span>
            <span className="font-mono font-bold text-accent-cyan flex items-center gap-1">
              +{confInfo.conditions.trendAlignment || 0} pts
              {confInfo.conditions.trendAlignment ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-buy-green" />
              ) : (
                <Circle className="w-3.5 h-3.5 text-muted-blue" />
              )}
            </span>
          </div>

          {/* Item 2 */}
          <div className="flex items-center justify-between p-2 rounded-lg bg-bg-surface2/40 border border-white/5">
            <span className="text-muted-blue font-sans">AMD Distribution</span>
            <span className="font-mono font-bold text-accent-cyan flex items-center gap-1">
              +{confInfo.conditions.amdPhase3 || 0} pts
              {confInfo.conditions.amdPhase3 ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-buy-green" />
              ) : (
                <Circle className="w-3.5 h-3.5 text-muted-blue" />
              )}
            </span>
          </div>

          {/* Item 3 */}
          <div className="flex items-center justify-between p-2 rounded-lg bg-bg-surface2/40 border border-white/5">
            <span className="text-muted-blue font-sans">Stop Hunt Sweeps</span>
            <span className="font-mono font-bold text-accent-cyan flex items-center gap-1">
              +{confInfo.conditions.liquiditySweep || 0} pts
              {confInfo.conditions.liquiditySweep ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-buy-green" />
              ) : (
                <Circle className="w-3.5 h-3.5 text-muted-blue" />
              )}
            </span>
          </div>

          {/* Item 4 */}
          <div className="flex items-center justify-between p-2 rounded-lg bg-bg-surface2/40 border border-white/5">
            <span className="text-muted-blue font-sans">Momentum Zero-Cross</span>
            <span className="font-mono font-bold text-accent-cyan flex items-center gap-1">
              +{confInfo.conditions.momentumCross || 0} pts
              {confInfo.conditions.momentumCross ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-buy-green" />
              ) : (
                <Circle className="w-3.5 h-3.5 text-muted-blue" />
              )}
            </span>
          </div>

          {/* Item 5 */}
          <div className="flex items-center justify-between p-2 rounded-lg bg-bg-surface2/40 border border-white/5">
            <span className="text-muted-blue font-sans">Keltner Squeezes</span>
            <span className="font-mono font-bold text-accent-cyan flex items-center gap-1">
              +{confInfo.conditions.keltnerSqueeze || 0} pts
              {confInfo.conditions.keltnerSqueeze ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-buy-green" />
              ) : (
                <Circle className="w-3.5 h-3.5 text-muted-blue" />
              )}
            </span>
          </div>

          {/* Item 6 */}
          <div className="flex items-center justify-between p-2 rounded-lg bg-bg-surface2/40 border border-white/5">
            <span className="text-muted-blue font-sans">Candlestick Form</span>
            <span className="font-mono font-bold text-accent-cyan flex items-center gap-1">
              +{confInfo.conditions.candlePattern || 0} pts
              {confInfo.conditions.candlePattern ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-buy-green" />
              ) : (
                <Circle className="w-3.5 h-3.5 text-muted-blue" />
              )}
            </span>
          </div>
        </div>

        {/* Current reasons summary ticker panel */}
        <div className="p-3 bg-bg-deep/40 rounded-xl border border-accent-cyan/10">
          <span className="text-[10px] uppercase font-bold text-muted-blue font-orbitron block mb-1">
            Core Solver Status
          </span>
          <p className="text-[11px] text-text-light font-sans italic">
            &ldquo;{confInfo.reasons[0] || "Confirming dual indicators convergence thresholds..."}&rdquo;
          </p>
        </div>

      </div>

    </div>
  );
}
