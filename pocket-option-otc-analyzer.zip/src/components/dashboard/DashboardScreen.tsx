import { useState, useEffect } from "react";
import { useAuth } from "../../store/authStore";
import { useAdmin } from "../../store/adminStore";
import { useMarket } from "../../store/marketStore";
import { AssetSelector } from "./AssetSelector";
import { CandlestickChart } from "./CandlestickChart";
import { ConfluenceGauge } from "./ConfluenceGauge";
import { SignalAlert } from "./SignalAlert";
import { ChartConfigurator } from "./ChartConfigurator";
import { ASSETS_DATA } from "../../data/assetsData";
import { Timeframe, Direction } from "../../types";
import {
  Clock,
  User,
  TrendingDown,
  TrendingUp,
  Cpu,
  Sparkles,
  RefreshCw,
  LogOut,
  AlertTriangle,
  ChevronDown,
  X,
  Plus,
  Bell,
  BellOff
} from "lucide-react";
import Markdown from "react-markdown";
import { motion, AnimatePresence } from "motion/react";

export function DashboardScreen() {
  const { currentUser, logoutUser } = useAuth();
  const { welcomeMessage } = useAdmin();
  const {
    selectedAsset,
    selectedTimeframe,
    setTimeframe,
    adviceStatus,
    requestAiAdvice,
    placeManualTrade,
    winRate,
    totalSignalsCount,
    streakCount,
    activePrice,
    loadingHistory,
  } = useMarket();

  // Mobile drawer state
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);

  // Live UTC Clock
  const [utcTime, setUtcTime] = useState("");

  // Audible alerts state for manual trades
  const [audibleAlertsEnabled, setAudibleAlertsEnabled] = useState(() => {
    const saved = localStorage.getItem("po_audible_alerts_manual");
    return saved !== "false";
  });

  const [soundPattern, setSoundPattern] = useState(() => {
    return localStorage.getItem("po_manual_alert_pattern") || "sonar";
  });

  const playAudioByPattern = (pattern: string) => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      if (pattern === "chime") {
        const osc1 = audioCtx.createOscillator();
        const osc2 = audioCtx.createOscillator();
        const gainNode1 = audioCtx.createGain();
        const gainNode2 = audioCtx.createGain();

        osc1.type = "sine";
        osc1.frequency.setValueAtTime(523.25, audioCtx.currentTime); // C5
        gainNode1.gain.setValueAtTime(0.08, audioCtx.currentTime);
        gainNode1.gain.exponentialRampToValueAtTime(0.005, audioCtx.currentTime + 0.35);

        osc2.type = "sine";
        osc2.frequency.setValueAtTime(659.25, audioCtx.currentTime); // E5
        gainNode2.gain.setValueAtTime(0.08, audioCtx.currentTime);
        gainNode2.gain.exponentialRampToValueAtTime(0.005, audioCtx.currentTime + 0.35);

        osc1.connect(gainNode1);
        osc2.connect(gainNode2);
        gainNode1.connect(audioCtx.destination);
        gainNode2.connect(audioCtx.destination);

        osc1.start();
        osc2.start();
        osc1.stop(audioCtx.currentTime + 0.4);
        osc2.stop(audioCtx.currentTime + 0.4);
      } else {
        const oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();

        if (pattern === "chirp") {
          oscillator.type = "sine";
          oscillator.frequency.setValueAtTime(1300, audioCtx.currentTime);
          oscillator.frequency.exponentialRampToValueAtTime(800, audioCtx.currentTime + 0.12);
          gainNode.gain.setValueAtTime(0.12, audioCtx.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.005, audioCtx.currentTime + 0.12);
          
          oscillator.connect(gainNode);
          gainNode.connect(audioCtx.destination);
          oscillator.start();
          oscillator.stop(audioCtx.currentTime + 0.12);
        } else if (pattern === "arcade") {
          oscillator.type = "triangle";
          oscillator.frequency.setValueAtTime(320, audioCtx.currentTime);
          oscillator.frequency.exponentialRampToValueAtTime(1500, audioCtx.currentTime + 0.18);
          gainNode.gain.setValueAtTime(0.08, audioCtx.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.005, audioCtx.currentTime + 0.18);
          
          oscillator.connect(gainNode);
          gainNode.connect(audioCtx.destination);
          oscillator.start();
          oscillator.stop(audioCtx.currentTime + 0.18);
        } else {
          // default/sonar
          oscillator.type = "sine";
          oscillator.frequency.setValueAtTime(587.33, audioCtx.currentTime);
          oscillator.frequency.setValueAtTime(880, audioCtx.currentTime + 0.08);
          gainNode.gain.setValueAtTime(0.12, audioCtx.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.005, audioCtx.currentTime + 0.25);
          
          oscillator.connect(gainNode);
          gainNode.connect(audioCtx.destination);
          oscillator.start();
          oscillator.stop(audioCtx.currentTime + 0.25);
        }
      }
    } catch (e) {
      console.warn("AudioContext playback blocked", e);
    }
  };

  const toggleAudibleAlerts = () => {
    const newVal = !audibleAlertsEnabled;
    setAudibleAlertsEnabled(newVal);
    localStorage.setItem("po_audible_alerts_manual", String(newVal));
    if (newVal) {
      playAudioByPattern(soundPattern);
    }
  };

  const changeSoundPattern = (pattern: string) => {
    setSoundPattern(pattern);
    localStorage.setItem("po_manual_alert_pattern", pattern);
    if (audibleAlertsEnabled) {
      playAudioByPattern(pattern);
    }
  };

  const handleManualTrade = (direction: Direction) => {
    placeManualTrade(direction);
    if (audibleAlertsEnabled) {
      playAudioByPattern(soundPattern);
    }
  };

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const yr = now.getUTCFullYear();
      const mo = String(now.getUTCMonth() + 1).padStart(2, "0");
      const dy = String(now.getUTCDate()).padStart(2, "0");
      const hrs = String(now.getUTCHours()).padStart(2, "0");
      const mins = String(now.getUTCMinutes()).padStart(2, "0");
      const secs = String(now.getUTCSeconds()).padStart(2, "0");
      setUtcTime(`${yr}-${mo}-${dy} ${hrs}:${mins}:${secs} UTC`);
    };

    updateTime();
    const handle = setInterval(updateTime, 1000);
    return () => clearInterval(handle);
  }, []);

  const tfsList = [
    { label: "30S FEED", value: Timeframe.TF_30S },
    { label: "1M FEED", value: Timeframe.TF_1M },
    { label: "2M FEED", value: Timeframe.TF_2M },
    { label: "3M FEED", value: Timeframe.TF_3M },
  ];

  // Lookup selected asset name
  const activeAssetObject = ASSETS_DATA.find(a => a.id === selectedAsset);
  const activeAssetName = activeAssetObject ? activeAssetObject.name : "EUR/USD OTC";

  return (
    <div className="w-full max-w-7xl mx-auto px-4 pt-4 pb-32 space-y-6">
      
      {/* 1. TOP SYSTEM CONTROL BAR */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center p-4 bg-bg-surface/75 border border-accent-cyan/10 rounded-2xl gap-4 select-none backdrop-blur-md">
        {/* Left branding */}
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-accent-cyan/10 border border-accent-cyan/25 flex items-center justify-center text-accent-cyan shadow-[0_0_15px_rgba(0,229,255,0.15)]">
            <Cpu className="w-5 h-5 animate-spin" style={{ animationDuration: "12s" }} />
          </div>
          <div>
            <h1 className="text-lg font-extrabold font-orbitron tracking-wider text-accent-cyan text-glow-cyan">
              POCKET OPTION CENTRAL
            </h1>
            <p className="flex items-center gap-1.5 text-[10px] text-muted font-mono">
              <Clock className="w-3.5 h-3.5 text-accent-cyan" /> {utcTime}
            </p>
          </div>
        </div>

        {/* Right dashboard meta stats */}
        <div className="flex flex-wrap items-center gap-4 w-full md:w-auto justify-between md:justify-end">
          <div className="flex items-center gap-2.5 px-3 py-1.5 bg-bg-deep/40 rounded-xl border border-white/5">
            <User className="w-3.5 h-3.5 text-accent-cyan" />
            <div className="text-left font-sans">
              <span className="text-[8px] font-orbitron text-muted leading-none block uppercase">
                OPERATOR KEY
              </span>
              <span className="text-xs font-semibold text-text-light">{currentUser?.fullName}</span>
            </div>
            <span className="text-[8px] bg-buy-green/10 border border-buy-green/30 text-buy-green px-1 rounded font-orbitron font-extrabold">
              SECURE
            </span>
          </div>

          <div className="flex items-center gap-3 px-3 py-1.5 bg-bg-deep/40 rounded-xl border border-white/5">
            <div>
              <span className="text-[8px] font-orbitron text-gold leading-none block uppercase">
                OVERLAY ACCURACY
              </span>
              <span className="text-xs font-mono font-bold text-gold">{winRate}% ACC</span>
            </div>
          </div>

          <button
            id="btn_logout"
            type="button"
            onClick={logoutUser}
            className="p-2 bg-sell-red/10 border border-sell-red/20 text-sell-red rounded-xl hover:bg-sell-red hover:text-white transition-all cursor-pointer font-orbitron text-[10px] uppercase font-bold tracking-wider"
          >
            <LogOut className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 2. CHAT BANNER ANNOUNCEMENT */}
      <div className="relative p-4 rounded-xl border border-accent-purple/20 bg-bg-surface/40 flex items-center justify-between overflow-hidden backdrop-blur-md">
        <div className="absolute right-0 top-0 -translate-y-4 translate-x-4 blur-2xl w-40 h-40 rounded-full bg-accent-purple/10 pointer-events-none" />
        <div className="flex items-center gap-2.5 select-none z-10 w-full">
          <Sparkles className="w-4.5 h-4.5 text-gold shrink-0 animate-bounce" />
          <p className="text-[11px] font-sans text-text/90 font-medium tracking-wide">
            {welcomeMessage || "96% Confluence Alignment protocol is active. Keep indicators calibrated to current volatility index ratios."}
          </p>
        </div>
      </div>

      {/* 3. PLATINUM 96% DETECTIONS MODULE */}
      <SignalAlert />

      {/* 4. ADAPTIVE PORTFOLIOS TRIGGERS (Mobile Only) */}
      <div className="md:hidden">
        <button
          type="button"
          onClick={() => setIsMobileDrawerOpen(true)}
          className="w-full flex justify-between items-center bg-bg-surface/80 border border-accent-cyan/15 p-4 rounded-2xl cursor-pointer hover:border-accent-cyan transition-colors backdrop-blur-md"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-accent-cyan/10 border border-accent-cyan/20 flex items-center justify-center font-orbitron text-[10px] font-bold text-accent-cyan shrink-0">
              {selectedAsset.replace("OTC_", "").slice(0, 2)}
            </div>
            <div className="text-left select-none">
              <span className="block text-[9px] text-muted uppercase font-orbitron font-semibold">ACTIVE BROKER PAIR</span>
              <span className="block text-xs font-bold text-text-light font-orbitron">{activeAssetName}</span>
            </div>
          </div>
          <div className="text-right flex items-center gap-2">
            <div>
              <span className="block text-xs font-mono font-bold text-accent-cyan text-glow-cyan">
                {activePrice.toFixed(selectedAsset.includes("JPY") ? 3 : 5)}
              </span>
              <span className="block text-[8px] text-muted font-sans uppercase">TAP TO NAVIGATE</span>
            </div>
            <ChevronDown className="w-4 h-4 text-accent-cyan" />
          </div>
        </button>
      </div>

      {/* 5. PRIMARY MASTER TERMINAL WORKSPACE GRID layout */}
      <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-12 gap-6">

        {/* Column A: Tablets/Desktops Left Sidebar (1/4 columns wide) */}
        <div className="hidden md:block md:col-span-1 lg:col-span-3 h-[680px] sticky top-4">
          <AssetSelector />
        </div>

        {/* Column B: Primary charting workspace (2/4 and 3/4 columns wide) */}
        <div className="md:col-span-2 lg:col-span-6 space-y-4">
          
          {/* Header row for active chart controls */}
          <div className="flex justify-between items-center bg-bg-surface/50 p-2.5 border border-accent-cyan/10 rounded-xl select-none">
            
            {/* Selected asset names displayed of chart header at all times */}
            <div className="flex items-center gap-2 px-2">
              <span className="text-[10px] font-orbitron uppercase text-muted font-extrabold">
                CHART FEED •
              </span>
              <span className="text-xs font-orbitron font-extrabold text-accent-cyan tracking-wide text-glow-cyan uppercase">
                {activeAssetName}
              </span>
            </div>

            {/* Timeframe Toggles */}
            <div className="flex gap-1.5">
              {tfsList.map(tf => {
                const isSelected = selectedTimeframe === tf.value;
                return (
                  <button
                    key={tf.value}
                    id={`tf_${tf.value.toLowerCase()}`}
                    type="button"
                    onClick={() => setTimeframe(tf.value)}
                    className={`px-2.5 py-1 text-[9px] font-orbitron font-bold tracking-wider rounded border transition-colors cursor-pointer outline-none focus:outline-none ${
                      isSelected
                        ? "text-accent-cyan border-accent-cyan bg-accent-cyan/5 shadow-[0_0_8px_rgba(0,229,255,0.15)]"
                        : "text-muted border-white/5 hover:border-accent-cyan/20"
                    }`}
                  >
                    {tf.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Canvas Rendering Zone */}
          {loadingHistory ? (
            <div className="w-full h-[470px] bg-bg-surface/30 border border-accent-cyan/5 rounded-2xl flex flex-col justify-center items-center gap-3 select-none">
              <RefreshCw className="w-8 h-8 text-accent-cyan animate-spin" />
              <span className="text-xs font-orbitron text-glow-cyan tracking-widest text-accent-cyan">
                LOADING MULTI-TF CANDLES MATRIX...
              </span>
            </div>
          ) : (
            <CandlestickChart />
          )}

          {/* Indicator Configuration tuning panel and Advisor in a 2-Column Responsive Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            
            {/* Co-Pilot predictor advice */}
            <div className="p-4 bg-bg-surface/60 border border-accent-cyan/15 rounded-2xl flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex justify-between items-center border-b border-white/5 pb-2">
                  <div className="flex items-center gap-1.5 select-none">
                    <Sparkles className="w-4 h-4 text-accent-cyan" />
                    <span className="text-[10px] font-orbitron font-extrabold text-text-light uppercase tracking-wide">
                      Co-Pilot Advisor
                    </span>
                  </div>
                  <button
                    id="btn_request_copilot"
                    type="button"
                    disabled={adviceStatus.loading}
                    onClick={requestAiAdvice}
                    className="flex items-center gap-1.5 px-3 py-1 bg-accent-purple/20 hover:bg-accent-purple/35 border border-accent-purple/45 text-white font-orbitron text-[8px] font-bold uppercase tracking-wider rounded-lg transition-all cursor-pointer"
                  >
                    {adviceStatus.loading ? (
                      <>
                        <RefreshCw className="w-2.5 h-2.5 animate-spin" />
                        AUDITING...
                      </>
                    ) : (
                      <>
                        <Cpu className="w-2.5 h-2.5" />
                        RUN AI AUDIT
                      </>
                    )}
                  </button>
                </div>

                <AnimatePresence mode="wait">
                  {adviceStatus.text ? (
                    <motion.div
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-3 bg-bg-deep/50 rounded-xl border border-accent-cyan/5 text-xs text-text-light font-sans max-h-[190px] overflow-y-auto pr-1"
                    >
                      <div className="markdown-body leading-relaxed space-y-2">
                        <Markdown>{adviceStatus.text}</Markdown>
                      </div>
                    </motion.div>
                  ) : (
                    <div className="text-[10px] text-muted font-sans leading-relaxed p-1 select-none">
                      AI Quantum Co-pilot is online. Request audit evaluation to execute advanced order block analyses on the selected {activeAssetName} {selectedTimeframe.replace("TF_", "")} candles chart feed.
                    </div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            {/* Custom Indicators tuning panel */}
            <ChartConfigurator />
          </div>

        </div>

        {/* Column C: Circular dial indicators + Actions placement terminal panels */}
        <div className="md:col-span-1 lg:col-span-3 space-y-4">
          
          <div className="space-y-1">
            <span className="text-[10px] font-orbitron uppercase text-muted tracking-widest font-extrabold">
              Confluence alignment gauge
            </span>
            <ConfluenceGauge />
          </div>

          {/* Quick placements panels */}
          <div className="p-6 bg-bg-surface/75 border border-accent-cyan/10 rounded-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-white/5 pb-2 select-none">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-orbitron text-text-light font-extrabold uppercase tracking-wide">
                  Terminal Speed Execution
                </span>
                <button
                  id="btn_toggle_audible_alerts"
                  type="button"
                  onClick={toggleAudibleAlerts}
                  className={`p-1 rounded bg-bg-deep border transition-all cursor-pointer ${
                    audibleAlertsEnabled
                      ? "border-accent-cyan/45 text-accent-cyan shadow-[0_0_8px_rgba(0,229,255,0.15)] bg-accent-cyan/5"
                      : "border-white/5 text-muted hover:text-text-light"
                  }`}
                  title={audibleAlertsEnabled ? "Mute Manual Trade Alerts" : "Unmute Manual Trade Alerts"}
                >
                  {audibleAlertsEnabled ? (
                    <Bell className="w-3.5 h-3.5" />
                  ) : (
                    <BellOff className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
              <span className="text-[10px] font-mono text-glow-cyan text-accent-cyan">
                BID PRICE: {activePrice.toFixed(selectedAsset.includes("JPY") ? 3 : 5)}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 pb-1">
              <div className="p-2.5 bg-bg-deep/40 rounded-xl border border-white/5 text-center">
                <span className="text-[8px] font-orbitron text-muted block uppercase">Positions logged</span>
                <span className="text-xs font-mono font-bold text-text-light">{totalSignalsCount} OVERAL</span>
              </div>
              <div className="p-2.5 bg-bg-deep/40 rounded-xl border border-white/5 text-center">
                <span className="text-[8px] font-orbitron text-muted block uppercase font-bold">Streaks active</span>
                <span className="text-xs font-mono font-bold text-gold">{streakCount} SUCCESS</span>
              </div>
            </div>

            {/* Audible alert pattern selector */}
            <AnimatePresence>
              {audibleAlertsEnabled && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="overflow-hidden space-y-1.5 p-2.5 bg-bg-deep/30 rounded-xl border border-white/5 select-none"
                >
                  <div className="flex justify-between items-center px-0.5">
                    <span className="text-[9px] font-orbitron text-muted uppercase tracking-wider font-semibold">
                      Manual Alert Cue
                    </span>
                    <span className="text-[8px] font-mono text-accent-cyan font-semibold">
                      ACTIVE CUE: {soundPattern.toUpperCase()}
                    </span>
                  </div>
                  <div className="grid grid-cols-4 gap-1.5" id="sound_pattern_selector">
                    {[
                      { id: "sonar", val: "Sonar" },
                      { id: "chirp", val: "Chirp" },
                      { id: "chime", val: "Chime" },
                      { id: "arcade", val: "Arcade" },
                    ].map(p => (
                      <button
                        key={p.id}
                        id={`sound_btn_${p.id}`}
                        type="button"
                        onClick={() => changeSoundPattern(p.id)}
                        className={`py-1.5 text-[9px] font-orbitron font-bold uppercase tracking-wider rounded border cursor-pointer text-center select-none transition-all ${
                          soundPattern === p.id
                            ? "bg-accent-cyan/10 border-accent-cyan/40 text-accent-cyan text-glow-cyan shadow-[0_0_6px_rgba(0,229,255,0.1)] font-extrabold"
                            : "bg-bg-deep/50 border-white/5 text-muted hover:text-text-light hover:border-white/10"
                        }`}
                        title={`Select ${p.val} sound for manual transitions`}
                      >
                        {p.val}
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="space-y-2 pt-1 font-sans">
              <button
                id="btn_manual_buy"
                type="button"
                onClick={() => handleManualTrade(Direction.BUY)}
                className="w-full h-12 bg-buy-green text-bg-deep font-orbitron uppercase tracking-widest font-extrabold text-xs rounded-xl hover:scale-[1.025] hover:shadow-[0_0_20px_rgba(0,255,136,0.4)] cursor-pointer select-none transition-all flex items-center justify-center gap-1.5"
              >
                <TrendingUp className="w-4.5 h-4.5" />
                PLACE BUY ORDER (MOCK)
              </button>

              <button
                id="btn_manual_sell"
                type="button"
                onClick={() => handleManualTrade(Direction.SELL)}
                className="w-full h-12 bg-sell-red text-white font-orbitron uppercase tracking-widest font-extrabold text-xs rounded-xl hover:scale-[1.025] hover:shadow-[0_0_20px_rgba(255,59,107,0.4)] cursor-pointer select-none transition-all flex items-center justify-center gap-1.5"
              >
                <TrendingDown className="w-4.5 h-4.5" />
                PLACE SELL ORDER (MOCK)
              </button>
            </div>

            <div className="p-3 bg-bg-deep/30 rounded-xl border border-dashed border-accent-cyan/10 select-none">
              <div className="flex gap-2 items-start text-xs text-muted leading-relaxed">
                <AlertTriangle className="w-4 h-4 text-gold shrink-0 mt-0.5" />
                <p className="text-[9px] leading-relaxed">
                  placements execute simulated accounts on the live ticker feed. Outcomes resolve precisely in {selectedTimeframe.replace("TF_", "")} on candle ex-dividend boundaries.
                </p>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* 6. OVERLAY BOTTOM DRAWER FOR MOBILE CLIENT LISTINGS */}
      <AnimatePresence>
        {isMobileDrawerOpen && (
          <div className="fixed inset-0 z-50 overflow-hidden md:hidden">
            
            {/* Backdrop slide-in and click-off blocker */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileDrawerOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />

            {/* Bottom Sheet sliding panel container */}
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className="absolute bottom-0 left-0 right-0 h-[80vh] bg-bg-surface rounded-t-[2.5rem] border-t border-accent-cyan/25 flex flex-col overflow-hidden shadow-2xl pointer-events-auto"
            >
              {/* Drawer drag handles & Header brand panel */}
              <div className="px-4 pt-3 pb-2 border-b border-accent-cyan/10 bg-bg-deep/40 flex items-center justify-between select-none shrink-0">
                <div className="w-20" />
                <div className="w-12 h-1 bg-white/20 rounded-full mx-auto" />
                <button
                  id="close_mobile_selector_btn"
                  type="button"
                  onClick={() => setIsMobileDrawerOpen(false)}
                  className="p-1 text-muted hover:text-accent-cyan bg-bg-surface rounded-lg border border-white/5 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Title brand panel in drawer header */}
              <div className="px-5 py-2.5 bg-bg-deep/20 border-b border-accent-cyan/5 shrink-0 flex items-center justify-between">
                <div>
                  <span className="block text-[8px] font-orbitron text-muted font-bold uppercase tracking-wider">
                    Pocket Option
                  </span>
                  <p className="text-xs font-orbitron font-extrabold text-accent-cyan tracking-wider">
                    BROKER LIQUIDITY HUB
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-gold font-orbitron border border-gold/20 px-2 py-0.5 rounded-full bg-gold/5 font-semibold">
                    89 ASSETS ONLINE
                  </span>
                </div>
              </div>

              {/* AssetSelector child component injecting vertical scrollable search listing */}
              <div className="flex-grow overflow-hidden pb-4">
                <AssetSelector onCloseMobileDrawer={() => setIsMobileDrawerOpen(false)} />
              </div>

            </motion.div>

          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
