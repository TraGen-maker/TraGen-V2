import { useMarket } from "../../store/marketStore";
import { AlertCircle, ArrowUpCircle, ArrowDownCircle, ExternalLink, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Direction } from "../../types";

export function SignalAlert() {
  const { activeSignalAlert } = useMarket();

  if (!activeSignalAlert) return null;

  const isBuy = activeSignalAlert.direction === Direction.BUY;
  const colorClass = isBuy ? "text-buy-green" : "text-sell-red";
  const bgClass = isBuy ? "bg-buy-green/10" : "bg-sell-red/10";
  const borderClass = isBuy ? "border-buy-green" : "border-sell-red";
  const glowShadow = isBuy ? "shadow-[0_0_30px_rgba(0,255,136,0.3)]" : "shadow-[0_0_30px_rgba(255,59,107,0.3)]";

  return (
    <AnimatePresence>
      <motion.div
        id="platinum_signal_banner"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: -50, opacity: 0 }}
        className={`w-full max-w-4xl mx-auto p-5 rounded-2xl border-2 backdrop-blur-3xl flex flex-col md:flex-row justify-between items-center gap-4 border-dashed relative overflow-hidden animate-pulse ${bgClass} ${borderClass} ${glowShadow}`}
      >
        {/* Core Icon & Header */}
        <div className="flex items-start gap-4 flex-1">
          <div className="mt-1 select-none">
            {isBuy ? (
              <ArrowUpCircle className="w-10 h-10 text-buy-green animate-bounce" />
            ) : (
              <ArrowDownCircle className="w-10 h-10 text-sell-red animate-bounce" />
            )}
          </div>

          <div className="space-y-1">
            <span className="inline-block text-[9px] font-bold font-orbitron bg-bg-deep text-gold border border-gold/40 px-2 py-0.5 rounded tracking-widest animate-pulse">
              CRITICAL CONFLUENCE INERTIA ACTIVATED
            </span>
            <h2 className="text-xl font-orbitron font-extrabold text-text-light flex items-center gap-2">
              <span className={colorClass}>{isBuy ? "BUY" : "SELL"} ACTION</span> FOR {activeSignalAlert.asset.replace("_", " ")}
            </h2>
            <p className="text-xs text-muted-blue font-sans">
              Strategy: <strong className="text-text-light font-medium">{activeSignalAlert.strategy}</strong>
            </p>
            <div className="text-[11px] text-text-light/95 font-semibold text-glow-cyan max-w-lg mt-1 italic">
              Confidence Index: {(activeSignalAlert.confidence * 100).toFixed(0)}% | Overlays: {activeSignalAlert.reasons[0] || "Alligator system breakout alignment"}
            </div>
          </div>
        </div>

        {/* Quick parameters columns */}
        <div className="flex gap-4 border-l border-white/10 pl-4 select-none">
          <div className="text-center">
            <span className="text-[9px] font-orbitron block text-muted-blue">TIMEFRAME</span>
            <span className="text-xs font-mono font-bold text-accent-cyan pr-4 border-r border-white/5">
              {activeSignalAlert.timeframe.replace("TF_", "")}
            </span>
          </div>
          <div className="text-center">
            <span className="text-[9px] font-orbitron block text-muted-blue">EXPIRY</span>
            <span className="text-xs font-mono font-bold text-accent-cyan pr-4 border-r border-white/5">
              {activeSignalAlert.expiry.replace("TF_", "")}
            </span>
          </div>
          <div className="text-center">
            <span className="text-[9px] font-orbitron block text-muted-blue">NEURAL SCORE</span>
            <span className="text-xs font-mono font-bold text-gold">
              {activeSignalAlert.neuralScore}%
            </span>
          </div>
        </div>

        {/* Action Triggers */}
        <div className="flex gap-2.5 items-center w-full md:w-auto mt-2 md:mt-0">
          <a
            id="btn_broker_link"
            href="https://pocketoption.com"
            target="_blank"
            rel="noreferrer"
            className="flex-1 md:flex-initial h-11 px-5 rounded-xl bg-gradient-to-r from-accent-cyan to-accent-purple text-xs font-orbitron font-bold text-white uppercase tracking-wider flex items-center gap-1.5 justify-center hover:scale-105 active:scale-95 cursor-pointer shadow-[0_0_15px_rgba(0,229,255,0.4)] transition-all duration-150"
          >
            EXECUTE ON POCKET OPTION
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
