import { useEffect, useRef, useState } from "react";
import { Candle, Direction, Timeframe } from "../../types";
import { useMarket } from "../../store/marketStore";
import { useChartConfig } from "../../store/chartStore";
import { computeAlligator, computeKeltner, detectAMDPhase } from "../../engine/confluenceEngine";
import { motion } from "motion/react";
import { ZoomIn, ZoomOut, RotateCcw } from "lucide-react";

// Direct indicator math helpers for MACD and Stochastic

function computeEMA(data: number[], period: number): number[] {
  const ema: number[] = [];
  if (data.length === 0) return [];
  const k = 2 / (period + 1);
  
  let sum = 0;
  const initialRange = Math.min(data.length, period);
  for (let i = 0; i < initialRange; i++) {
    sum += data[i];
  }
  let currentEma = sum / initialRange;
  ema.push(currentEma);

  for (let i = 1; i < data.length; i++) {
    currentEma = data[i] * k + currentEma * (1 - k);
    ema.push(currentEma);
  }
  return ema;
}

function getMACD(candles: Candle[], fast: number, slow: number, signal: number) {
  const closes = candles.map(c => c.close);
  if (closes.length === 0) {
    return { macdLine: [], signalLine: [], histogram: [] };
  }
  
  const emaFast = computeEMA(closes, fast);
  const emaSlow = computeEMA(closes, slow);
  
  const macdLine: number[] = [];
  for (let i = 0; i < closes.length; i++) {
    const slowVal = emaSlow[i] || emaFast[i]; // safeguard
    macdLine.push(emaFast[i] - slowVal);
  }
  
  const signalLine = computeEMA(macdLine, signal);
  const histogram: number[] = [];
  for (let i = 0; i < closes.length; i++) {
    histogram.push(macdLine[i] - (signalLine[i] || 0));
  }
  
  return { macdLine, signalLine, histogram };
}

function getStochastic(candles: Candle[], kPeriod: number, dPeriod: number, slowing: number) {
  const kValues: number[] = [];
  
  for (let i = 0; i < candles.length; i++) {
    const startIdx = Math.max(0, i - kPeriod + 1);
    const subCandles = candles.slice(startIdx, i + 1);
    if (subCandles.length === 0) {
      kValues.push(50);
      continue;
    }
    const lowest = Math.min(...subCandles.map(c => c.low));
    const highest = Math.max(...subCandles.map(c => c.high));
    const currentClose = candles[i].close;
    
    const range = highest - lowest;
    const value = range === 0 ? 50 : ((currentClose - lowest) / range) * 100;
    kValues.push(value);
  }

  // Slow %K
  const smoothedK: number[] = [];
  for (let i = 0; i < kValues.length; i++) {
    const startIdx = Math.max(0, i - slowing + 1);
    const subVal = kValues.slice(startIdx, i + 1);
    const sum = subVal.reduce((acc, curr) => acc + curr, 0);
    smoothedK.push(sum / subVal.length);
  }

  // %D rolling SMA
  const dValues: number[] = [];
  for (let i = 0; i < smoothedK.length; i++) {
    const startIdx = Math.max(0, i - dPeriod + 1);
    const subVal = smoothedK.slice(startIdx, i + 1);
    const sum = subVal.reduce((acc, curr) => acc + curr, 0);
    dValues.push(sum / subVal.length);
  }

  return { percentK: smoothedK, percentD: dValues };
}

export function CandlestickChart() {
  const { liveCandles, selectedAsset, historicSignals } = useMarket();
  const { config } = useChartConfig();
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Zoom parameters
  const [candleWidth, setCandleWidth] = useState(7);
  const [scrollOffset, setScrollOffset] = useState(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || liveCandles.length === 0) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    ctx.clearRect(0, 0, width, height);

    // Padding and divided layout offsets
    const paddingRight = 65;
    const paddingTop = 30;
    const paddingBottom = 25;
    const chartWidth = width - paddingRight;

    // Sub-oscillators segments allocation
    const macdHeight = config.showMACD ? 65 : 0;
    const stochHeight = config.showStochastic ? 65 : 0;
    const spacing = (macdHeight > 0 ? 12 : 0) + (stochHeight > 0 ? 12 : 0);
    
    const chartHeight = height - paddingTop - paddingBottom - macdHeight - stochHeight - spacing;

    // Viewable range calculations
    const maxVisibleCandles = Math.floor(chartWidth / (candleWidth + 2));
    const startIndex = Math.max(0, liveCandles.length - maxVisibleCandles - scrollOffset);
    const endIndex = Math.min(liveCandles.length, startIndex + maxVisibleCandles);
    const visibleCandles = liveCandles.slice(startIndex, endIndex);

    if (visibleCandles.length === 0) return;

    // Price scale boundaries
    const highPrices = visibleCandles.map(c => c.high);
    const lowPrices = visibleCandles.map(c => c.low);
    const maxPrice = Math.max(...highPrices) * 1.0008;
    const minPrice = Math.min(...lowPrices) * 0.9992;
    const priceRange = maxPrice - minPrice || 0.0001;

    const getY = (price: number) => {
      return paddingTop + chartHeight - ((price - minPrice) / priceRange) * chartHeight;
    };

    // 1. Grid lines background
    ctx.strokeStyle = "rgba(0, 229, 255, 0.03)";
    ctx.lineWidth = 1;
    const stepX = 40;
    const stepY = 30;
    for (let x = 0; x < chartWidth; x += stepX) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y < height; y += stepY) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(chartWidth, y);
      ctx.stroke();
    }

    // 2. Keltner Channel Rendering (If Enabled)
    if (config.showKeltner) {
      try {
        const keltnerPathUpper: number[] = [];
        const keltnerPathLower: number[] = [];
        const keltnerXs: number[] = [];

        visibleCandles.forEach((c, idx) => {
          const historicalSnapshot = liveCandles.slice(0, startIndex + idx + 1);
          const kelt = computeKeltner(historicalSnapshot);
          const candleX = (idx * (candleWidth + 2)) + (candleWidth / 2);

          keltnerPathUpper.push(getY(kelt.upper));
          keltnerPathLower.push(getY(kelt.lower));
          keltnerXs.push(candleX);
        });

        ctx.fillStyle = "rgba(0, 229, 255, 0.04)";
        ctx.beginPath();
        ctx.moveTo(keltnerXs[0], keltnerPathUpper[0]);
        for (let i = 1; i < keltnerXs.length; i++) {
          ctx.lineTo(keltnerXs[i], keltnerPathUpper[i]);
        }
        for (let i = keltnerXs.length - 1; i >= 0; i--) {
          ctx.lineTo(keltnerXs[i], keltnerPathLower[i]);
        }
        ctx.closePath();
        ctx.fill();

        ctx.strokeStyle = "rgba(0, 229, 255, 0.12)";
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        ctx.moveTo(keltnerXs[0], keltnerPathUpper[0]);
        for (let i = 1; i < keltnerXs.length; i++) {
          ctx.lineTo(keltnerXs[i], keltnerPathUpper[i]);
        }
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(keltnerXs[0], keltnerPathLower[0]);
        for (let i = 1; i < keltnerXs.length; i++) {
          ctx.lineTo(keltnerXs[i], keltnerPathLower[i]);
        }
        ctx.stroke();
        ctx.setLineDash([]);
      } catch (err) {}
    }

    // 3. Fair Value Gaps (FVG) Zone Shader
    if (config.showFVG) {
      visibleCandles.forEach((c, idx) => {
        const actualIdx = startIndex + idx;
        if (actualIdx < 2) return;
        const prev2 = liveCandles[actualIdx - 2];

        if (c.low > prev2.high) {
          const top = getY(c.low);
          const bottom = getY(prev2.high);
          const x1 = ((idx - 2) * (candleWidth + 2));
          const x2 = (idx * (candleWidth + 2)) + candleWidth;

          ctx.fillStyle = "rgba(0, 255, 136, 0.04)";
          ctx.fillRect(x1, top, x2 - x1, bottom - top);
          ctx.strokeStyle = "rgba(0, 255, 136, 0.10)";
          ctx.strokeRect(x1, top, x2 - x1, bottom - top);
        }

        if (c.high < prev2.low) {
          const top = getY(prev2.low);
          const bottom = getY(c.high);
          const x1 = ((idx - 2) * (candleWidth + 2));
          const x2 = (idx * (candleWidth + 2)) + candleWidth;

          ctx.fillStyle = "rgba(255, 59, 107, 0.04)";
          ctx.fillRect(x1, top, x2 - x1, bottom - top);
          ctx.strokeStyle = "rgba(255, 59, 107, 0.10)";
          ctx.strokeRect(x1, top, x2 - x1, bottom - top);
        }
      });
    }

    // 4. Order Blocks (OB) Wick extreme frames
    if (config.showOB) {
      const swingRanges: { y: number; height: number; type: "bullish" | "bearish" }[] = [];
      visibleCandles.forEach((c, idx) => {
        const isRed = c.close < c.open;
        const bodyRatio = Math.abs(c.close - c.open) / (c.high - c.low || 0.001);
        if (idx > 0 && bodyRatio > 0.6) {
          const prev = visibleCandles[idx - 1];
          const prevRed = prev.close < prev.open;
          if (isRed !== prevRed) {
            swingRanges.push({
              y: getY(Math.max(prev.open, prev.close)),
              height: Math.abs(getY(prev.low) - getY(prev.high)) || 10,
              type: isRed ? "bearish" : "bullish",
            });
          }
        }
      });

      swingRanges.slice(-3).forEach(ob => {
        ctx.fillStyle = ob.type === "bullish" ? "rgba(0, 255, 136, 0.03)" : "rgba(255, 59, 107, 0.03)";
        ctx.strokeStyle = ob.type === "bullish" ? "rgba(0, 255, 136, 0.11)" : "rgba(255, 59, 107, 0.11)";
        ctx.lineWidth = 1;
        ctx.fillRect(0, ob.y, chartWidth, ob.height);
        ctx.strokeRect(0, ob.y, chartWidth, ob.height);
      });
    }

    // 5. Golden Liquidity sweeps lines high/low limits
    if (config.showLiquiditySweep) {
      const maxVal = Math.max(...highPrices);
      const minVal = Math.min(...lowPrices);

      ctx.strokeStyle = "rgba(255, 215, 0, 0.30)";
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      
      ctx.beginPath();
      ctx.moveTo(0, getY(maxVal));
      ctx.lineTo(chartWidth, getY(maxVal));
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, getY(minVal));
      ctx.lineTo(chartWidth, getY(minVal));
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = "#FFD700";
      ctx.font = "8px 'Orbitron'";
      ctx.fillText("LIQUIDITY SWEEP RESISTANCE", 10, getY(maxVal) - 4);
      ctx.fillText("LIQUIDITY SWEEP SUPPORT", 10, getY(minVal) + 10);
    }

    // 6. Candlestick Drawing
    visibleCandles.forEach((c, idx) => {
      const isUp = c.close >= c.open;
      const x = (idx * (candleWidth + 2));
      const wickX = x + (candleWidth / 2);

      const yOpen = getY(c.open);
      const yClose = getY(c.close);
      const yHigh = getY(c.high);
      const yLow = getY(c.low);

      const bodyTop = Math.min(yOpen, yClose);
      const bodyBottom = Math.max(yOpen, yClose);
      const bodyHeight = Math.max(1, bodyBottom - bodyTop);

      const barColor = isUp ? "rgb(0, 255, 136)" : "rgb(255, 59, 107)";
      const glowIntensity = isUp ? "rgba(0, 255, 136, 0.15)" : "rgba(255, 59, 107, 0.15)";

      ctx.shadowColor = glowIntensity;
      ctx.shadowBlur = 4;

      ctx.strokeStyle = barColor;
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(wickX, yHigh);
      ctx.lineTo(wickX, yLow);
      ctx.stroke();

      ctx.fillStyle = barColor;
      ctx.fillRect(x, bodyTop, candleWidth, bodyHeight);
      ctx.shadowColor = "transparent";
      ctx.shadowBlur = 0;
    });

    // 7. Alligator Indicator lines
    if (config.showAlligator) {
      try {
        const jawPath: { x: number; y: number }[] = [];
        const teethPath: { x: number; y: number }[] = [];
        const lipsPath: { x: number; y: number }[] = [];

        visibleCandles.forEach((c, idx) => {
          const historicalSnapshot = liveCandles.slice(0, startIndex + idx + 1);
          const alligator = computeAlligator(historicalSnapshot); // uses customized periods eventually
          const candleX = (idx * (candleWidth + 2)) + (candleWidth / 2);

          // Customize Alligator plotting mathematically or using standard shifts
          jawPath.push({ x: candleX, y: getY(alligator.jaw) });
          teethPath.push({ x: candleX, y: getY(alligator.teeth) });
          lipsPath.push({ x: candleX, y: getY(alligator.lips) });
        });

        // Jaw (Cyan/Blue)
        ctx.lineWidth = 1.6;
        ctx.strokeStyle = "#00E5FF";
        ctx.beginPath();
        ctx.moveTo(jawPath[0].x, jawPath[0].y);
        for (let i = 1; i < jawPath.length; i++) {
          ctx.lineTo(jawPath[i].x, jawPath[i].y);
        }
        ctx.stroke();

        // Teeth (Purple/Red)
        ctx.strokeStyle = "#FF3B6B";
        ctx.beginPath();
        ctx.moveTo(teethPath[0].x, teethPath[0].y);
        for (let i = 1; i < teethPath.length; i++) {
          ctx.lineTo(teethPath[i].x, teethPath[i].y);
        }
        ctx.stroke();

        // Lips (Green)
        ctx.strokeStyle = "#00FF88";
        ctx.beginPath();
        ctx.moveTo(lipsPath[0].x, lipsPath[0].y);
        for (let i = 1; i < lipsPath.length; i++) {
          ctx.lineTo(lipsPath[i].x, lipsPath[i].y);
        }
        ctx.stroke();
      } catch (err) {}
    }

    // 8. Draw Signal arrows
    visibleCandles.forEach((c, idx) => {
      const sigMatch = historicSignals.find(
        s => s.asset === selectedAsset && Math.abs(s.timestamp - c.timestamp) < 30000
      );

      if (sigMatch) {
        const x = (idx * (candleWidth + 2)) + (candleWidth / 2);
        const isBuy = sigMatch.direction === Direction.BUY;
        const arrowY = isBuy ? getY(c.low) + 14 : getY(c.high) - 14;

        ctx.shadowColor = isBuy ? "rgba(0, 255, 136, 0.8)" : "rgba(255, 59, 107, 0.8)";
        ctx.shadowBlur = 10;
        ctx.fillStyle = isBuy ? "rgb(0, 255, 136)" : "rgb(255, 59, 107)";

        ctx.beginPath();
        if (isBuy) {
          ctx.moveTo(x - 5, arrowY);
          ctx.lineTo(x + 5, arrowY);
          ctx.lineTo(x, arrowY - 9);
        } else {
          ctx.moveTo(x - 5, arrowY);
          ctx.lineTo(x + 5, arrowY);
          ctx.lineTo(x, arrowY + 9);
        }
        ctx.closePath();
        ctx.fill();
        ctx.shadowBlur = 0;
      }
    });

    // 9. AMD Phase Markers
    if (config.showAMD) {
      try {
        const { phase } = detectAMDPhase(liveCandles, liveCandles);
        const count = visibleCandles.length;
        const markerText = ["A", "M", "D"];
        const markerLabel = ["ACCUMULATION", "MANIPULATION", "DISTRIBUTION"];

        markerText.forEach((letter, i) => {
          const step = Math.floor(count / 4);
          const xPos = ((i * step + step) * (candleWidth + 2));
          const yPos = chartHeight + paddingTop + 10;

          ctx.fillStyle = "rgba(0, 229, 255, 0.12)";
          ctx.beginPath();
          ctx.arc(xPos, yPos, 8, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = i === phase - 1 ? "#00E5FF" : "#4A6FA5";
          ctx.font = "bold 9px 'Orbitron'";
          ctx.textAlign = "center";
          ctx.fillText(letter, xPos, yPos + 3);

          ctx.font = "6px 'Orbitron'";
          ctx.fillText(markerLabel[i], xPos, yPos + 12);
        });
        ctx.textAlign = "left";
      } catch (e) {}
    }

    // ─── 10. ADVANCED ELEMENT: MACD SUB-PANEL DRAWING ───
    if (config.showMACD) {
      const macdYTop = paddingTop + chartHeight + (config.showAMD ? 30 : 15);
      const macdYCenter = macdYTop + (macdHeight / 2);

      // Draw panel horizontal frame lines
      ctx.strokeStyle = "rgba(0, 229, 255, 0.08)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, macdYTop);
      ctx.lineTo(chartWidth, macdYTop);
      ctx.moveTo(0, macdYTop + macdHeight);
      ctx.lineTo(chartWidth, macdYTop + macdHeight);
      ctx.stroke();

      // Computes MACD line values
      try {
        const { macdLine, signalLine, histogram } = getMACD(
          liveCandles,
          config.macdFast,
          config.macdSlow,
          config.macdSignal
        );

        // Find scale range for MACD plots in focus
        const visibleMACD = macdLine.slice(startIndex, endIndex);
        const visibleSignal = signalLine.slice(startIndex, endIndex);
        const visibleHist = histogram.slice(startIndex, endIndex);
        const allVals = [...visibleMACD, ...visibleSignal, ...visibleHist];
        const maxMacdVal = Math.max(...allVals.map(Math.abs)) || 0.0001;

        const getMACDY = (val: number) => {
          return macdYCenter - (val / maxMacdVal) * (macdHeight / 2.2);
        };

        // Draw histogram bars
        visibleCandles.forEach((c, idx) => {
          const actIdx = startIndex + idx;
          const histVal = histogram[actIdx] || 0;
          const barX = idx * (candleWidth + 2);
          const barY = getMACDY(histVal);

          ctx.fillStyle = histVal >= 0 ? "rgba(0, 255, 136, 0.35)" : "rgba(255, 59, 107, 0.35)";
          ctx.fillRect(barX, Math.min(macdYCenter, barY), candleWidth, Math.abs(macdYCenter - barY) || 1);
        });

        // Plot MACD line (Bright Cyan)
        ctx.strokeStyle = "#00E5FF";
        ctx.lineWidth = 1.3;
        ctx.beginPath();
        visibleCandles.forEach((c, idx) => {
          const actIdx = startIndex + idx;
          const val = macdLine[actIdx] || 0;
          const barX = (idx * (candleWidth + 2)) + (candleWidth / 2);
          const barY = getMACDY(val);
          if (idx === 0) ctx.moveTo(barX, barY);
          else ctx.lineTo(barX, barY);
        });
        ctx.stroke();

        // Plot Signal Line (Amber Gold)
        ctx.strokeStyle = "#FFD700";
        ctx.lineWidth = 1.3;
        ctx.beginPath();
        visibleCandles.forEach((c, idx) => {
          const actIdx = startIndex + idx;
          const val = signalLine[actIdx] || 0;
          const barX = (idx * (candleWidth + 2)) + (candleWidth / 2);
          const barY = getMACDY(val);
          if (idx === 0) ctx.moveTo(barX, barY);
          else ctx.lineTo(barX, barY);
        });
        ctx.stroke();
      } catch (err) {}

      // Text label and indicator values
      ctx.fillStyle = "#E8F4FD";
      ctx.font = "8px 'Orbitron'";
      ctx.fillText(`MACD (${config.macdFast}, ${config.macdSlow}, ${config.macdSignal})`, 10, macdYTop + 10);
    }

    // ─── 11. ADVANCED ELEMENT: STOCHASTIC SUB-PANEL DRAWING ───
    if (config.showStochastic) {
      const stochYTop = paddingTop + chartHeight + (config.showMACD ? macdHeight : 0) + (config.showAMD ? 40 : 25);
      const stochYBottom = stochYTop + stochHeight;

      // Draw boundaries
      ctx.strokeStyle = "rgba(0, 229, 255, 0.08)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, stochYTop);
      ctx.lineTo(chartWidth, stochYTop);
      ctx.moveTo(0, stochYBottom);
      ctx.lineTo(chartWidth, stochYBottom);
      ctx.stroke();

      // Transform 0-100 stochastic range into Y Canvas coords
      const getStochY = (val: number) => {
        return stochYBottom - (val / 100) * stochHeight;
      };

      // Draw Overbought (80) & Oversold (20) levels
      ctx.strokeStyle = "rgba(255, 255, 255, 0.15)";
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(0, getStochY(80));
      ctx.lineTo(chartWidth, getStochY(80));
      ctx.moveTo(0, getStochY(20));
      ctx.lineTo(chartWidth, getStochY(20));
      ctx.stroke();
      ctx.setLineDash([]); // Reset

      ctx.fillStyle = "rgba(74, 111, 165, 0.5)";
      ctx.font = "6px 'JetBrains Mono'";
      ctx.fillText("80", chartWidth - 15, getStochY(80) - 2);
      ctx.fillText("20", chartWidth - 15, getStochY(20) + 7);

      try {
        const { percentK, percentD } = getStochastic(
          liveCandles,
          config.stochK,
          config.stochD,
          config.stochSlowing
        );

        // Plot %K line (Cyan)
        ctx.strokeStyle = "#00FF88";
        ctx.lineWidth = 1.3;
        ctx.beginPath();
        visibleCandles.forEach((c, idx) => {
          const actIdx = startIndex + idx;
          const val = percentK[actIdx] || 50;
          const barX = (idx * (candleWidth + 2)) + (candleWidth / 2);
          const barY = getStochY(val);
          if (idx === 0) ctx.moveTo(barX, barY);
          else ctx.lineTo(barX, barY);
        });
        ctx.stroke();

        // Plot %D line (Orange)
        ctx.strokeStyle = "#FF3B6B";
        ctx.lineWidth = 1.3;
        ctx.beginPath();
        visibleCandles.forEach((c, idx) => {
          const actIdx = startIndex + idx;
          const val = percentD[actIdx] || 50;
          const barX = (idx * (candleWidth + 2)) + (candleWidth / 2);
          const barY = getStochY(val);
          if (idx === 0) ctx.moveTo(barX, barY);
          else ctx.lineTo(barX, barY);
        });
        ctx.stroke();
      } catch (err) {}

      ctx.fillStyle = "#E8F4FD";
      ctx.font = "8px 'Orbitron'";
      ctx.fillText(`STOCH (${config.stochK}, ${config.stochD}, ${config.stochSlowing})`, 10, stochYTop + 10);
    }

    // ─── 12. PRICE AXIS LINES AND NUMERICS scale indicators ───
    ctx.strokeStyle = "rgba(0, 229, 255, 0.15)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(chartWidth, 0);
    ctx.lineTo(chartWidth, height - paddingBottom);
    ctx.moveTo(0, height - paddingBottom);
    ctx.lineTo(chartWidth, height - paddingBottom);
    ctx.stroke();

    ctx.fillStyle = "rgba(74, 111, 165, 0.8)";
    ctx.font = "9px 'JetBrains Mono'";
    ctx.textAlign = "left";

    const pricesList = [
      minPrice + priceRange * 0.2,
      minPrice + priceRange * 0.4,
      minPrice + priceRange * 0.6,
      minPrice + priceRange * 0.8,
    ];

    pricesList.forEach(p => {
      ctx.beginPath();
      ctx.moveTo(chartWidth, getY(p));
      ctx.lineTo(chartWidth + 4, getY(p));
      ctx.stroke();
      ctx.fillText(p.toFixed(selectedAsset.includes("JPY") ? 3 : 5), chartWidth + 6, getY(p) + 3);
    });

    ctx.fillStyle = "#E8F4FD";
    ctx.font = "10px 'Orbitron'";
    ctx.fillText(`${selectedAsset.replace("_", " ")}`, 15, height - 10);

  }, [liveCandles, selectedAsset, candleWidth, scrollOffset, historicSignals, config]);

  const handleZoomIn = () => {
    setCandleWidth(prev => Math.min(18, prev + 1.5));
  };

  const handleZoomOut = () => {
    setCandleWidth(prev => Math.max(3.5, prev - 1.5));
  };

  const handleReset = () => {
    setCandleWidth(7);
    setScrollOffset(0);
  };

  return (
    <div className="relative w-full h-[470px] bg-bg-surface/50 border border-accent-cyan/10 rounded-2xl overflow-hidden glass-panel">
      {/* Zoom / Pan triggers */}
      <div className="absolute right-4 top-4 flex gap-1 z-20">
        <button
          type="button"
          onClick={handleZoomIn}
          className="p-1 px-1.5 bg-bg-surface border border-accent-cyan/15 rounded-lg text-accent-cyan hover:bg-accent-cyan/10 transition-colors cursor-pointer text-xs flex items-center gap-1"
        >
          <ZoomIn className="w-3.5 h-3.5" />
        </button>
        <button
          type="button"
          onClick={handleZoomOut}
          className="p-1 px-1.5 bg-bg-surface border border-accent-cyan/15 rounded-lg text-accent-cyan hover:bg-accent-cyan/10 transition-colors cursor-pointer text-xs flex items-center gap-1"
        >
          <ZoomOut className="w-3.5 h-3.5" />
        </button>
        <button
          type="button"
          onClick={handleReset}
          className="p-1 px-1.5 bg-bg-surface border border-accent-cyan/15 rounded-lg text-accent-cyan hover:bg-accent-cyan/10 transition-colors cursor-pointer text-xs flex items-center gap-1"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
      </div>

      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
}
