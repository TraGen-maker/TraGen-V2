import { useState } from "react";
import { useChartConfig, ChartTemplate } from "../../store/chartStore";
import { Sliders, Save, Trash2, FolderHeart, LayoutGrid, Check, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export function ChartConfigurator() {
  const {
    config,
    savedTemplates,
    activeTemplate,
    updateConfig,
    saveTemplate,
    applyTemplate,
    deleteTemplate,
  } = useChartConfig();

  const [newTemplateName, setNewTemplateName] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const [activeTab, setActiveTab] = useState<"indicators" | "templates">("indicators");

  const handleSaveTemplate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTemplateName.trim()) return;
    saveTemplate(newTemplateName.trim());
    setNewTemplateName("");
    setSuccessMsg("Template saved successfully!");
    setTimeout(() => setSuccessMsg(""), 3000);
  };

  return (
    <div className="bg-bg-surface border border-accent-cyan/10 rounded-2xl overflow-hidden glass-panel flex flex-col p-5 space-y-4">
      {/* Header Tabs */}
      <div className="flex justify-between items-center border-b border-white/5 pb-3">
        <div className="flex gap-1.5 p-0.5 bg-bg-deep/50 rounded-xl border border-white/5">
          <button
            type="button"
            onClick={() => setActiveTab("indicators")}
            className={`px-3 py-1.5 rounded-lg text-xs font-orbitron font-bold transition-all cursor-pointer flex items-center gap-1.5 select-none ${
              activeTab === "indicators"
                ? "bg-accent-cyan/15 text-accent-cyan shadow-[0_0_12px_rgba(0,229,255,0.1)]"
                : "text-muted-blue hover:text-text"
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            Indicators Setup
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("templates")}
            className={`px-3 py-1.5 rounded-lg text-xs font-orbitron font-bold transition-all cursor-pointer flex items-center gap-1.5 select-none ${
              activeTab === "templates"
                ? "bg-accent-cyan/15 text-accent-cyan shadow-[0_0_12px_rgba(0,229,255,0.1)]"
                : "text-muted-blue hover:text-text"
            }`}
          >
            <FolderHeart className="w-3.5 h-3.5" />
            Chart Templates
          </button>
        </div>
        <div>
          {activeTemplate && (
            <span className="text-[9px] font-orbitron font-semibold text-gold bg-gold/10 border border-gold/20 px-2 py-0.5 rounded-full tracking-wide">
              TEMPLATE: {activeTemplate.toUpperCase()}
            </span>
          )}
        </div>
      </div>

      {/* BODY SECTIONS */}
      {activeTab === "indicators" ? (
        <div className="space-y-4 max-h-[380px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-accent-cyan/10">
          {/* 1. Williams Alligator Tuning */}
          <div className="p-3 bg-bg-deep/40 rounded-xl border border-white/5 space-y-3">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                id="toggle_alligator"
                type="checkbox"
                checked={config.showAlligator}
                onChange={() => updateConfig({ showAlligator: !config.showAlligator })}
                className="w-4 h-4 rounded Accent-cyan border-white/10"
              />
              <span className="text-xs font-orbitron font-bold text-text">Williams Alligator Lines</span>
            </label>
            
            {config.showAlligator && (
              <div className="grid grid-cols-3 gap-2 pt-1">
                <div>
                  <span className="text-[9px] text-muted font-sans uppercase">Jaw (Blue)</span>
                  <input
                    type="number"
                    min={3}
                    max={50}
                    value={config.alligatorJaw}
                    onChange={(e) => updateConfig({ alligatorJaw: parseInt(e.target.value) || 13 })}
                    className="w-full bg-bg-surface border border-accent-cyan/15 rounded px-2 py-1 text-xs text-text text-center focus:outline-none focus:border-accent-cyan"
                  />
                </div>
                <div>
                  <span className="text-[9px] text-muted font-sans uppercase">Teeth (Red)</span>
                  <input
                    type="number"
                    min={3}
                    max={50}
                    value={config.alligatorTeeth}
                    onChange={(e) => updateConfig({ alligatorTeeth: parseInt(e.target.value) || 8 })}
                    className="w-full bg-bg-surface border border-accent-cyan/15 rounded px-2 py-1 text-xs text-text text-center focus:outline-none focus:border-accent-cyan"
                  />
                </div>
                <div>
                  <span className="text-[9px] text-muted font-sans uppercase">Lips (Green)</span>
                  <input
                    type="number"
                    min={3}
                    max={50}
                    value={config.alligatorLips}
                    onChange={(e) => updateConfig({ alligatorLips: parseInt(e.target.value) || 5 })}
                    className="w-full bg-bg-surface border border-accent-cyan/15 rounded px-2 py-1 text-xs text-text text-center focus:outline-none focus:border-accent-cyan"
                  />
                </div>
              </div>
            )}
          </div>

          {/* 2. Keltner Channels Tuning */}
          <div className="p-3 bg-bg-deep/40 rounded-xl border border-white/5 space-y-3">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                id="toggle_keltner"
                type="checkbox"
                checked={config.showKeltner}
                onChange={() => updateConfig({ showKeltner: !config.showKeltner })}
                className="w-4 h-4 rounded Accent-cyan border-white/10"
              />
              <span className="text-xs font-orbitron font-bold text-text">Keltner Channels Band</span>
            </label>
            
            {config.showKeltner && (
              <div className="grid grid-cols-3 gap-2 pt-1">
                <div>
                  <span className="text-[9px] text-muted font-sans uppercase">EMA Length</span>
                  <input
                    type="number"
                    min={5}
                    max={100}
                    value={config.keltnerEma}
                    onChange={(e) => updateConfig({ keltnerEma: parseInt(e.target.value) || 20 })}
                    className="w-full bg-bg-surface border border-accent-cyan/15 rounded px-2 py-1 text-xs text-text text-center focus:outline-none focus:border-accent-cyan"
                  />
                </div>
                <div>
                  <span className="text-[9px] text-muted font-sans uppercase">ATR Length</span>
                  <input
                    type="number"
                    min={3}
                    max={50}
                    value={config.keltnerAtr}
                    onChange={(e) => updateConfig({ keltnerAtr: parseInt(e.target.value) || 10 })}
                    className="w-full bg-bg-surface border border-accent-cyan/15 rounded px-2 py-1 text-xs text-text text-center focus:outline-none focus:border-accent-cyan"
                  />
                </div>
                <div>
                  <span className="text-[9px] text-muted font-sans uppercase">Multiplier</span>
                  <input
                    type="number"
                    step="0.1"
                    min="0.5"
                    max="5"
                    value={config.keltnerMultiplier}
                    onChange={(e) => updateConfig({ keltnerMultiplier: parseFloat(e.target.value) || 1.5 })}
                    className="w-full bg-bg-surface border border-accent-cyan/15 rounded px-2 py-1 text-xs text-text text-center focus:outline-none focus:border-accent-cyan"
                  />
                </div>
              </div>
            )}
          </div>

          {/* 3. MACD Oscillator Tuning */}
          <div className="p-3 bg-bg-deep/40 rounded-xl border border-white/5 space-y-3">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                id="toggle_macd"
                type="checkbox"
                checked={config.showMACD}
                onChange={() => updateConfig({ showMACD: !config.showMACD })}
                className="w-4 h-4 rounded Accent-cyan border-white/10"
              />
              <span className="text-xs font-orbitron font-bold text-text">MACD (Moving Average Convergence)</span>
            </label>
            
            {config.showMACD && (
              <div className="grid grid-cols-3 gap-2 pt-1">
                <div>
                  <span className="text-[9px] text-muted font-sans uppercase">Fast EMA</span>
                  <input
                    type="number"
                    min={5}
                    max={50}
                    value={config.macdFast}
                    onChange={(e) => updateConfig({ macdFast: parseInt(e.target.value) || 12 })}
                    className="w-full bg-bg-surface border border-accent-cyan/15 rounded px-2 py-1 text-xs text-text text-center focus:outline-none focus:border-accent-cyan"
                  />
                </div>
                <div>
                  <span className="text-[9px] text-muted font-sans uppercase">Slow EMA</span>
                  <input
                    type="number"
                    min={10}
                    max={100}
                    value={config.macdSlow}
                    onChange={(e) => updateConfig({ macdSlow: parseInt(e.target.value) || 26 })}
                    className="w-full bg-bg-surface border border-accent-cyan/15 rounded px-2 py-1 text-xs text-text text-center focus:outline-none focus:border-accent-cyan"
                  />
                </div>
                <div>
                  <span className="text-[9px] text-muted font-sans uppercase">Signal Line</span>
                  <input
                    type="number"
                    min={3}
                    max={30}
                    value={config.macdSignal}
                    onChange={(e) => updateConfig({ macdSignal: parseInt(e.target.value) || 9 })}
                    className="w-full bg-bg-surface border border-accent-cyan/15 rounded px-2 py-1 text-xs text-text text-center focus:outline-none focus:border-accent-cyan"
                  />
                </div>
              </div>
            )}
          </div>

          {/* 4. Stochastic Tuning */}
          <div className="p-3 bg-bg-deep/40 rounded-xl border border-white/5 space-y-3">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                id="toggle_stochastic"
                type="checkbox"
                checked={config.showStochastic}
                onChange={() => updateConfig({ showStochastic: !config.showStochastic })}
                className="w-4 h-4 rounded Accent-cyan border-white/10"
              />
              <span className="text-xs font-orbitron font-bold text-text">Stochastic Oscillator</span>
            </label>
            
            {config.showStochastic && (
              <div className="grid grid-cols-3 gap-2 pt-1">
                <div>
                  <span className="text-[9px] text-muted font-sans uppercase">%K period</span>
                  <input
                    type="number"
                    min={5}
                    max={50}
                    value={config.stochK}
                    onChange={(e) => updateConfig({ stochK: parseInt(e.target.value) || 14 })}
                    className="w-full bg-bg-surface border border-accent-cyan/15 rounded px-2 py-1 text-xs text-text text-center focus:outline-none focus:border-accent-cyan"
                  />
                </div>
                <div>
                  <span className="text-[9px] text-muted font-sans uppercase">%D period</span>
                  <input
                    type="number"
                    min={2}
                    max={20}
                    value={config.stochD}
                    onChange={(e) => updateConfig({ stochD: parseInt(e.target.value) || 3 })}
                    className="w-full bg-bg-surface border border-accent-cyan/15 rounded px-2 py-1 text-xs text-text text-center focus:outline-none focus:border-accent-cyan"
                  />
                </div>
                <div>
                  <span className="text-[9px] text-muted font-sans uppercase">Slowing</span>
                  <input
                    type="number"
                    min={1}
                    max={10}
                    value={config.stochSlowing}
                    onChange={(e) => updateConfig({ stochSlowing: parseInt(e.target.value) || 3 })}
                    className="w-full bg-bg-surface border border-accent-cyan/15 rounded px-2 py-1 text-xs text-text text-center focus:outline-none focus:border-accent-cyan"
                  />
                </div>
              </div>
            )}
          </div>

          {/* 5. Pure Price Action Toggles */}
          <div className="p-3 bg-bg-deep/40 rounded-xl border border-white/5 space-y-2.5">
            <span className="block text-[10px] font-orbitron font-bold text-muted uppercase tracking-wider">
              Price Action Overlay Blocks
            </span>
            <div className="grid grid-cols-2 gap-2">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={config.showFVG}
                  onChange={() => updateConfig({ showFVG: !config.showFVG })}
                  className="w-3.5 h-3.5 rounded Accent-cyan border-white/5"
                />
                <span className="text-[10px] text-text font-serif">FVG Zones</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={config.showOB}
                  onChange={() => updateConfig({ showOB: !config.showOB })}
                  className="w-3.5 h-3.5 rounded Accent-cyan border-white/5"
                />
                <span className="text-[10px] text-text font-serif">Order Blocks</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={config.showLiquiditySweep}
                  onChange={() => updateConfig({ showLiquiditySweep: !config.showLiquiditySweep })}
                  className="w-3.5 h-3.5 rounded Accent-cyan border-white/5"
                />
                <span className="text-[10px] text-text font-serif">Liquidity Sweep</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={config.showAMD}
                  onChange={() => updateConfig({ showAMD: !config.showAMD })}
                  className="w-3.5 h-3.5 rounded Accent-cyan border-white/5"
                />
                <span className="text-[10px] text-text font-serif">AMD Phases</span>
              </label>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Saved templates portfolio */}
          <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1 scrollbar-thin">
            <span className="block text-[10px] font-orbitron text-muted font-bold uppercase tracking-wider">
              Template Catalogs
            </span>
            <div className="space-y-1.5">
              {savedTemplates.map((tpl) => {
                const isCurrent = activeTemplate?.toLowerCase() === tpl.name.toLowerCase();
                return (
                  <div
                    key={tpl.name}
                    className={`flex items-center justify-between p-2 rounded-xl transition-all border ${
                      isCurrent
                        ? "bg-accent-cyan/10 border-accent-cyan/40"
                        : "bg-bg-deep/30 border-white/5 hover:bg-bg-surface2/50"
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => applyTemplate(tpl.name)}
                      className="flex-grow text-left outline-none cursor-pointer select-none"
                    >
                      <span className="block text-xs font-orbitron font-bold text-text-light">
                        {tpl.name}
                      </span>
                      <span className="block text-[9px] text-muted-blue font-sans">
                        {tpl.isPreset ? "Global System Configuration" : "Tuned Custom Alignment"}
                      </span>
                    </button>
                    
                    <div className="flex items-center gap-1.5">
                      {isCurrent && (
                        <div className="w-5 h-5 rounded-full bg-accent-cyan/20 border border-accent-cyan/40 flex items-center justify-center text-accent-cyan">
                          <Check className="w-3 h-3" />
                        </div>
                      )}
                      {!tpl.isPreset && (
                        <button
                          type="button"
                          onClick={() => deleteTemplate(tpl.name)}
                          className="p-1 text-muted hover:text-sell-red bg-bg-surface rounded-md border border-white/5 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Form to save current configurations */}
          <form onSubmit={handleSaveTemplate} className="space-y-2 border-t border-white/5 pt-3">
            <span className="block text-[10px] font-orbitron text-gold font-bold uppercase tracking-wider flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-gold shrink-0" />
              Capture Active Template
            </span>
            <div className="flex gap-2">
              <input
                id="template_name_input"
                type="text"
                placeholder="Template name (e.g. Scalp setup)..."
                value={newTemplateName}
                onChange={(e) => setNewTemplateName(e.target.value)}
                className="flex-grow bg-bg-surface2 border border-accent-cyan/15 rounded-xl px-3 py-2 text-xs text-text placeholder-muted focus:outline-none focus:border-accent-cyan"
              />
              <button
                id="btn_submit_template"
                type="submit"
                disabled={!newTemplateName.trim()}
                className="px-3 bg-accent-cyan hover:bg-accent-cyan/90 text-bg-deep font-orbitron font-bold text-xs rounded-xl transition-all cursor-pointer disabled:opacity-50 flex items-center gap-1.5 shrink-0"
              >
                <Save className="w-3.5 h-3.5" />
                Store
              </button>
            </div>
            {successMsg && (
              <p className="text-[10px] text-buy-green font-orbitron uppercase text-center tracking-wide">
                {successMsg}
              </p>
            )}
          </form>
        </div>
      )}

      {/* Action Footer for alignment feedback */}
      <div className="pt-2 text-center text-[9px] font-orbitron text-muted uppercase select-none tracking-widest leading-none border-t border-white/5">
        Custom overlays auto-aligned locally • Save slots limitless
      </div>
    </div>
  );
}
