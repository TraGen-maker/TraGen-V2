import { useState, useEffect } from "react";
import { useMarket } from "../../store/marketStore";
import { Direction, Outcome, Timeframe, Signal } from "../../types";
import {
  Bookmark,
  Bell,
  CheckCircle,
  XCircle,
  Timer,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  ShieldAlert,
  SlidersHorizontal,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export function SignalsScreen() {
  const { historicSignals, winRate, totalSignalsCount, streakCount } = useMarket();

  // Filters state
  const [outcomeFilter, setOutcomeFilter] = useState<string>("ALL");
  const [assetFilter, setAssetFilter] = useState<string>("ALL");
  const [localSignals, setLocalSignals] = useState<Signal[]>([]);

  // Alignment matrix indicators state (live ticks simulations)
  const [matrixState, setMatrixState] = useState({
    alligator: { [Timeframe.TF_30S]: Direction.BUY, [Timeframe.TF_1M]: Direction.BUY, [Timeframe.TF_2M]: Direction.NEUTRAL, [Timeframe.TF_3M]: Direction.SELL },
    momentum: { [Timeframe.TF_30S]: Direction.BUY, [Timeframe.TF_1M]: Direction.BUY, [Timeframe.TF_2M]: Direction.BUY, [Timeframe.TF_3M]: Direction.NEUTRAL },
    keltner: { [Timeframe.TF_30S]: Direction.SELL, [Timeframe.TF_1M]: Direction.SELL, [Timeframe.TF_2M]: Direction.NEUTRAL, [Timeframe.TF_3M]: Direction.BUY },
    amd: { [Timeframe.TF_30S]: Direction.BUY, [Timeframe.TF_1M]: Direction.BUY, [Timeframe.TF_2M]: Direction.BUY, [Timeframe.TF_3M]: Direction.BUY },
  });

  // Tick matrix state every 4s to simulate live telemetry checks
  useEffect(() => {
    const handle = setInterval(() => {
      const dirs = [Direction.BUY, Direction.SELL, Direction.NEUTRAL];
      setMatrixState({
        alligator: {
          [Timeframe.TF_30S]: dirs[Math.floor(Math.random() * dirs.length)],
          [Timeframe.TF_1M]: dirs[Math.floor(Math.random() * dirs.length)],
          [Timeframe.TF_2M]: dirs[Math.floor(Math.random() * dirs.length)],
          [Timeframe.TF_3M]: dirs[Math.floor(Math.random() * dirs.length)],
        },
        momentum: {
          [Timeframe.TF_30S]: dirs[Math.floor(Math.random() * dirs.length)],
          [Timeframe.TF_1M]: dirs[Math.floor(Math.random() * dirs.length)],
          [Timeframe.TF_2M]: dirs[Math.floor(Math.random() * dirs.length)],
          [Timeframe.TF_3M]: dirs[Math.floor(Math.random() * dirs.length)],
        },
        keltner: {
          [Timeframe.TF_30S]: dirs[Math.floor(Math.random() * dirs.length)],
          [Timeframe.TF_1M]: dirs[Math.floor(Math.random() * dirs.length)],
          [Timeframe.TF_2M]: dirs[Math.floor(Math.random() * dirs.length)],
          [Timeframe.TF_3M]: dirs[Math.floor(Math.random() * dirs.length)],
        },
        amd: {
          [Timeframe.TF_30S]: dirs[Math.floor(Math.random() * dirs.length)],
          [Timeframe.TF_1M]: dirs[Math.floor(Math.random() * dirs.length)],
          [Timeframe.TF_2M]: dirs[Math.floor(Math.random() * dirs.length)],
          [Timeframe.TF_3M]: dirs[Math.floor(Math.random() * dirs.length)],
        },
      });
    }, 4500);

    return () => clearInterval(handle);
  }, []);

  // Filter signals list
  useEffect(() => {
    let filtered = [...historicSignals];

    if (outcomeFilter !== "ALL") {
      filtered = filtered.filter(sig => sig.outcome === outcomeFilter);
    }

    if (assetFilter !== "ALL") {
      filtered = filtered.filter(sig => sig.asset === assetFilter);
    }

    setLocalSignals(filtered);
  }, [historicSignals, outcomeFilter, assetFilter]);

  const uniqueAssets = [
    "ALL",
    "OTC_EURUSD",
    "OTC_GBPUSD",
    "OTC_USDJPY",
    "OTC_AUDUSD",
    "OTC_USDCAD",
    "OTC_EURJPY",
    "BTC_OTC",
    "GOLD_OTC",
  ];

  const outcomes = ["ALL", Outcome.WIN, Outcome.LOSS, Outcome.PENDING];

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}:${String(d.getSeconds()).padStart(2, "0")}`;
  };

  const getDirectionBadge = (dir: Direction) => {
    return dir === Direction.BUY ? (
      <span className="text-buy-green bg-buy-green/10 border border-buy-green/30 text-[10px] font-orbitron font-extrabold px-2.5 py-0.5 rounded flex items-center gap-1 shadow-[0_0_8px_rgba(0,255,136,0.15)] uppercase">
        <TrendingUp className="w-3.5 h-3.5" /> BUY
      </span>
    ) : dir === Direction.SELL ? (
      <span className="text-sell-red bg-sell-red/10 border border-sell-red/30 text-[10px] font-orbitron font-extrabold px-2.5 py-0.5 rounded flex items-center gap-1 shadow-[0_0_8px_rgba(255,59,107,0.15)] uppercase">
        <TrendingDown className="w-3.5 h-3.5" /> SELL
      </span>
    ) : (
      <span className="text-slate-400 bg-slate-500/10 border border-slate-500/20 text-[10px] font-orbitron font-extrabold px-2.5 py-0.5 rounded uppercase">
        FLAT
      </span>
    );
  };

  const getMatrixDirStyle = (dir: Direction) => {
    switch (dir) {
      case Direction.BUY:
        return "text-buy-green bg-buy-green/5 border-buy-green/20";
      case Direction.SELL:
        return "text-sell-red bg-sell-red/5 border-sell-red/20";
      default:
        return "text-muted-blue bg-bg-deep/20 border-white/5";
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 pt-4 pb-32 space-y-6 select-none">
      
      {/* 1. TOP EFFICIENCY COUNTERS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-bg-surface/75 border border-accent-cyan/15 rounded-2xl flex items-center justify-between shadow-lg">
          <div>
            <span className="text-[10px] font-orbitron text-muted-blue block">SESSIONS CAPTURED</span>
            <span className="text-2xl font-orbitron font-bold text-text-light">{totalSignalsCount}</span>
          </div>
          <div className="w-9 h-9 rounded-lg bg-accent-cyan/10 flex items-center justify-center text-accent-cyan border border-accent-cyan/15">
            <Bell className="w-4 h-4" />
          </div>
        </div>

        <div className="p-4 bg-bg-surface/75 border border-accent-cyan/15 rounded-2xl flex items-center justify-between shadow-lg">
          <div>
            <span className="text-[10px] font-orbitron text-gold block">SYSTEM WIN-RATE</span>
            <span className="text-2xl font-orbitron font-extrabold text-gold text-glow-cyan">{winRate}%</span>
          </div>
          <div className="w-9 h-9 rounded-lg bg-gold/10 flex items-center justify-center text-gold border border-gold/15">
            <CheckCircle className="w-4 h-4" />
          </div>
        </div>

        <div className="p-4 bg-bg-surface/75 border border-accent-purple/15 rounded-2xl flex items-center justify-between shadow-lg">
          <div>
            <span className="text-[10px] font-orbitron text-accent-purple block">ACTIVE SUCCESS STREAK</span>
            <span className="text-xl font-orbitron font-bold text-accent-purple">{streakCount} SUCCESSES</span>
          </div>
          <div className="w-9 h-9 rounded-lg bg-accent-purple/10 flex items-center justify-center text-accent-purple border border-accent-purple/15">
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>

        <div className="p-4 bg-bg-surface/75 border border-accent-cyan/15 rounded-2xl flex items-center justify-between shadow-lg">
          <div>
            <span className="text-[10px] font-orbitron text-muted-blue block">ALIGNED CHANNELS EFFICIENCY</span>
            <span className="text-2xl font-orbitron font-bold text-accent-cyan text-glow-cyan">96.8%</span>
          </div>
          <div className="w-9 h-9 rounded-lg bg-accent-cyan/10 flex items-center justify-center text-accent-cyan border border-accent-cyan/15">
            <Bookmark className="w-4 h-4 animate-bounce" />
          </div>
        </div>
      </div>

      {/* 2. GRID ALIGNMENT STATE BOARD (Section 6) */}
      <div className="p-6 bg-bg-surface/70 border border-accent-cyan/10 rounded-2xl space-y-4 shadow-xl">
        <div className="flex justify-between items-center border-b border-accent-cyan/10 pb-2">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4.5 h-4.5 text-accent-cyan animate-pulse" />
            <h2 className="text-xs font-orbitron font-extrabold text-glow-cyan tracking-wider text-text-light uppercase">
              Unified Grid Convergence Alignment (Live Telemetry)
            </h2>
          </div>
          <span className="text-[9px] font-mono text-muted-blue tracking-widest uppercase">
            STATUS: ACTIVE CONSOLIDATION
          </span>
        </div>

        {/* Dynamic Board Matrix Grid table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-white/5">
                <th className="py-2.5 font-orbitron text-muted-blue">INDICATOR CONVERGE</th>
                <th className="py-2.5 font-orbitron text-muted-blue text-center">30S TIME</th>
                <th className="py-2.5 font-orbitron text-muted-blue text-center">1M TIME</th>
                <th className="py-2.5 font-orbitron text-muted-blue text-center">2M TIME</th>
                <th className="py-2.5 font-orbitron text-muted-blue text-center">3M TIME</th>
              </tr>
            </thead>
            <tbody>
              {/* Row Alligator */}
              <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                <td className="py-2 px-1 font-semibold text-text-light">Williams Alligator</td>
                <td className="py-2 text-center text-[10px]">
                  <span className={`px-2.5 py-0.5 rounded border font-bold font-orbitron ${getMatrixDirStyle(matrixState.alligator[Timeframe.TF_30S])}`}>
                    {matrixState.alligator[Timeframe.TF_30S]}
                  </span>
                </td>
                <td className="py-2 text-center text-[10px]">
                  <span className={`px-2.5 py-0.5 rounded border font-bold font-orbitron ${getMatrixDirStyle(matrixState.alligator[Timeframe.TF_1M])}`}>
                    {matrixState.alligator[Timeframe.TF_1M]}
                  </span>
                </td>
                <td className="py-2 text-center text-[10px]">
                  <span className={`px-2.5 py-0.5 rounded border font-bold font-orbitron ${getMatrixDirStyle(matrixState.alligator[Timeframe.TF_2M])}`}>
                    {matrixState.alligator[Timeframe.TF_2M]}
                  </span>
                </td>
                <td className="py-2 text-center text-[10px]">
                  <span className={`px-2.5 py-0.5 rounded border font-bold font-orbitron ${getMatrixDirStyle(matrixState.alligator[Timeframe.TF_3M])}`}>
                    {matrixState.alligator[Timeframe.TF_3M]}
                  </span>
                </td>
              </tr>

              {/* Row Momentum */}
              <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                <td className="py-2 px-1 font-semibold text-text-light">Momentum Vectors</td>
                <td className="py-2 text-center text-[10px]">
                  <span className={`px-2.5 py-0.5 rounded border font-bold font-orbitron ${getMatrixDirStyle(matrixState.momentum[Timeframe.TF_30S])}`}>
                    {matrixState.momentum[Timeframe.TF_30S]}
                  </span>
                </td>
                <td className="py-2 text-center text-[10px]">
                  <span className={`px-2.5 py-0.5 rounded border font-bold font-orbitron ${getMatrixDirStyle(matrixState.momentum[Timeframe.TF_1M])}`}>
                    {matrixState.momentum[Timeframe.TF_1M]}
                  </span>
                </td>
                <td className="py-2 text-center text-[10px]">
                  <span className={`px-2.5 py-0.5 rounded border font-bold font-orbitron ${getMatrixDirStyle(matrixState.momentum[Timeframe.TF_2M])}`}>
                    {matrixState.momentum[Timeframe.TF_2M]}
                  </span>
                </td>
                <td className="py-2 text-center text-[10px]">
                  <span className={`px-2.5 py-0.5 rounded border font-bold font-orbitron ${getMatrixDirStyle(matrixState.momentum[Timeframe.TF_3M])}`}>
                    {matrixState.momentum[Timeframe.TF_3M]}
                  </span>
                </td>
              </tr>

              {/* Row Keltner */}
              <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                <td className="py-2 px-1 font-semibold text-text-light">Keltner Channels</td>
                <td className="py-2 text-center text-[10px]">
                  <span className={`px-2.5 py-0.5 rounded border font-bold font-orbitron ${getMatrixDirStyle(matrixState.keltner[Timeframe.TF_30S])}`}>
                    {matrixState.keltner[Timeframe.TF_30S]}
                  </span>
                </td>
                <td className="py-2 text-center text-[10px]">
                  <span className={`px-2.5 py-0.5 rounded border font-bold font-orbitron ${getMatrixDirStyle(matrixState.keltner[Timeframe.TF_1M])}`}>
                    {matrixState.keltner[Timeframe.TF_1M]}
                  </span>
                </td>
                <td className="py-2 text-center text-[10px]">
                  <span className={`px-2.5 py-0.5 rounded border font-bold font-orbitron ${getMatrixDirStyle(matrixState.keltner[Timeframe.TF_2M])}`}>
                    {matrixState.keltner[Timeframe.TF_2M]}
                  </span>
                </td>
                <td className="py-2 text-center text-[10px]">
                  <span className={`px-2.5 py-0.5 rounded border font-bold font-orbitron ${getMatrixDirStyle(matrixState.keltner[Timeframe.TF_3M])}`}>
                    {matrixState.keltner[Timeframe.TF_3M]}
                  </span>
                </td>
              </tr>

              {/* Row AMD */}
              <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                <td className="py-2 px-1 font-semibold text-text-light">AMD Volatility Bands</td>
                <td className="py-2 text-center text-[10px]">
                  <span className={`px-2.5 py-0.5 rounded border font-bold font-orbitron ${getMatrixDirStyle(matrixState.amd[Timeframe.TF_30S])}`}>
                    {matrixState.amd[Timeframe.TF_30S]}
                  </span>
                </td>
                <td className="py-2 text-center text-[10px]">
                  <span className={`px-2.5 py-0.5 rounded border font-bold font-orbitron ${getMatrixDirStyle(matrixState.amd[Timeframe.TF_1M])}`}>
                    {matrixState.amd[Timeframe.TF_1M]}
                  </span>
                </td>
                <td className="py-2 text-center text-[10px]">
                  <span className={`px-2.5 py-0.5 rounded border font-bold font-orbitron ${getMatrixDirStyle(matrixState.amd[Timeframe.TF_2M])}`}>
                    {matrixState.amd[Timeframe.TF_2M]}
                  </span>
                </td>
                <td className="py-2 text-center text-[10px]">
                  <span className={`px-2.5 py-0.5 rounded border font-bold font-orbitron ${getMatrixDirStyle(matrixState.amd[Timeframe.TF_3M])}`}>
                    {matrixState.amd[Timeframe.TF_3M]}
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* 3. INTERACTIVE CONTROL FILTERS */}
      <div className="p-4 bg-bg-surface/50 border border-accent-cyan/10 rounded-2xl space-y-4">
        
        <div className="flex items-center gap-2 border-b border-white/5 pb-2">
          <SlidersHorizontal className="w-4 h-4 text-accent-cyan" />
          <span className="text-xs font-orbitron font-bold text-glow-cyan text-text-light tracking-wide uppercase">
            Convergence Filters Room
          </span>
        </div>

        <div className="flex flex-col md:flex-row justify-between gap-4">
          {/* Outcome Filter */}
          <div className="space-y-1">
            <span className="text-[10px] font-orbitron uppercase text-muted-blue block">Outcome Segment</span>
            <div className="flex flex-wrap gap-1">
              {outcomes.map(out => (
                <button
                  key={out}
                  type="button"
                  onClick={() => setOutcomeFilter(out)}
                  className={`px-3 py-1 bg-transparent hover:bg-white/5 text-[9px] hover:text-white font-orbitron font-semibold rounded border transition-colors cursor-pointer outline-none focus:outline-none ${
                    outcomeFilter === out ? "text-accent-cyan border-accent-cyan bg-accent-cyan/5" : "text-muted-blue border-white/5"
                  }`}
                >
                  {out}
                </button>
              ))}
            </div>
          </div>

          {/* Asset Selection */}
          <div className="space-y-1">
            <span className="text-[10px] font-orbitron uppercase text-muted-blue block">Filter Portfolios</span>
            <div className="flex flex-wrap gap-1">
              {uniqueAssets.map(asset => (
                <button
                  key={asset}
                  type="button"
                  onClick={() => setAssetFilter(asset)}
                  className={`px-3 py-1 bg-transparent hover:bg-white/5 text-[9px] hover:text-white font-orbitron font-semibold rounded border transition-colors cursor-pointer outline-none focus:outline-none ${
                    assetFilter === asset ? "text-accent-cyan border-accent-cyan bg-accent-cyan/5" : "text-muted-blue border-white/5"
                  }`}
                >
                  {asset.replace("OTC_", "").replace("_OTC", "")}
                </button>
              ))}
            </div>
          </div>
        </div>

      </div>

      {/* 4. REAL SIGNALS LIST VIEW */}
      <div className="space-y-3">
        <span className="text-[10px] font-orbitron uppercase text-muted-blue tracking-widest font-bold">
          Historic Alignment Decryptions
        </span>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <AnimatePresence mode="popLayout">
            {localSignals.length === 0 ? (
              <div className="col-span-1 md:col-span-2 p-12 text-center bg-bg-surface/30 border border-white/5 rounded-2xl select-none text-muted-blue text-xs font-sans italic">
                Awaiting convergence triggers below set parameters... Active calculations continuing.
              </div>
            ) : (
              localSignals.map(sig => {
                const isPlatinum = sig.confidence >= 0.96;
                const isWin = sig.outcome === Outcome.WIN;
                const isLoss = sig.outcome === Outcome.LOSS;
                const isPending = sig.outcome === Outcome.PENDING;

                return (
                  <motion.div
                    key={sig.id}
                    layout
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.98 }}
                    transition={{ type: "spring", stiffness: 450, damping: 25 }}
                    className={`p-5 rounded-2xl border backdrop-blur-md flex flex-col justify-between gap-4 transition-all ${
                      isPlatinum
                        ? "border-accent-purple/40 bg-gradient-to-br from-bg-surface to-accent-purple/5 shadow-[0_4px_30px_rgba(123,47,100,0.06)]"
                        : "border-accent-cyan/10 bg-bg-surface/60"
                    }`}
                  >
                    {/* Card Head */}
                    <div className="flex justify-between items-start gap-4">
                      <div>
                        <div className="flex items-center gap-1.5 select-none">
                          <span className="text-xs font-orbitron font-extrabold text-text-light tracking-wide">
                            {sig.asset.replace("_", " ")}
                          </span>
                          {isPlatinum && (
                            <span className="text-[8px] bg-accent-purple/15 text-accent-purple px-1.5 py-0.2 rounded border border-accent-purple/30 font-orbitron font-bold">
                              PLATINUM
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] font-mono text-muted-blue leading-none mt-1 block">
                          Captured At: {formatTime(sig.timestamp)}
                        </span>
                      </div>

                      {/* Direction and Outcomes */}
                      <div className="flex flex-col items-end gap-1.5 align-right">
                        {getDirectionBadge(sig.direction)}
                        
                        {isWin && (
                          <span className="text-buy-green bg-buy-green/10 text-[9px] font-sans font-bold px-2 py-0.2 rounded shadow-[0_0_8px_rgba(0,255,136,0.15)] select-none">
                            RESOLVED: WIN
                          </span>
                        )}
                        {isLoss && (
                          <span className="text-sell-red bg-sell-red/10 text-[9px] font-sans font-bold px-2 py-0.2 rounded shadow-[0_0_8px_rgba(255,59,107,0.15)] select-none">
                            RESOLVED: LOSS
                          </span>
                        )}
                        {isPending && (
                          <span className="text-gold bg-gold/10 text-[9px] font-sans font-bold px-2 py-0.2 rounded flex items-center gap-1 shadow-[0_0_8px_rgba(255,215,0,0.15)] select-none animate-pulse">
                            <Timer className="w-3 h-3" /> PENDING...
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Accurate Technical parameters */}
                    <div className="grid grid-cols-2 gap-2 text-[10px] font-mono bg-bg-deep/40 p-2.5 rounded-lg border border-white/5 select-none">
                      <div>
                        <span className="text-muted-blue leading-none block uppercase">
                          ML CONFIDENCE
                        </span>
                        <span className="text-glow-cyan text-accent-cyan font-bold">{sig.mlScore || 91.2}% Accuracy</span>
                      </div>
                      <div>
                        <span className="text-muted-blue leading-none block uppercase">
                          NEURAL BIAS
                        </span>
                        <span className="text-gold font-bold">{sig.neuralScore || 92.4}% Bias</span>
                      </div>
                    </div>

                    {/* Bullet elements */}
                    <div className="text-[10px] text-text-light/80 space-y-1">
                      <span className="text-[9px] font-orbitron uppercase text-muted-blue font-bold block select-none">
                        CONVERGENT DETERMINISTIC ELEMENTS
                      </span>
                      {sig.reasons.slice(0, 2).map((r, i) => (
                        <p key={i} className="flex items-center gap-1 font-sans">
                          <ChevronRight className="w-3 h-3 text-accent-cyan shrink-0" />
                          {r}
                        </p>
                      ))}
                    </div>

                  </motion.div>
                );
              })
            )}
          </AnimatePresence>
        </div>
      </div>

    </div>
  );
}
