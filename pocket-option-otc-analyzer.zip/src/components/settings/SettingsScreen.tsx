import { useState } from "react";
import { useAuth, User } from "../../store/authStore";
import { useAdmin } from "../../store/adminStore";
import {
  User as UserIcon,
  Mail,
  Shield,
  Volume2,
  VolumeX,
  Lock,
  Calendar,
  CheckCircle,
  AlertTriangle,
  Sparkles,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export function SettingsScreen() {
  const { currentUser } = useAuth();
  const { soundAlerts, signalNotifications, setSoundAlerts, setSignalNotifications } = useAdmin();

  // Reset password states
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [err, setLocalErr] = useState<string | null>(null);
  const [success, setLocalSuccess] = useState<string | null>(null);

  const handlePasswordReset = (e: React.FormEvent) => {
    e.preventDefault();
    setLocalErr(null);
    setLocalSuccess(null);

    if (!currentUser) return;

    if (!currentPassword || !newPassword || !confirmNewPassword) {
      setLocalErr("Please complete all password fields.");
      return;
    }

    // Verify current password hash match
    const hashedCurrent = btoa(currentPassword);
    if (currentUser.passwordHash !== hashedCurrent) {
      setLocalErr("The current security password entered is incorrect.");
      return;
    }

    if (newPassword.length < 6) {
      setLocalErr("The new password must be at least 6 characters.");
      return;
    }

    if (newPassword !== confirmNewPassword) {
      setLocalErr("New passwords do not match.");
      return;
    }

    try {
      const usersList: User[] = JSON.parse(localStorage.getItem("po_users") || "[]");
      const updatedList = usersList.map(u => {
        if (u.id === currentUser.id) {
          return {
            ...u,
            passwordHash: btoa(newPassword),
          };
        }
        return u;
      });

      localStorage.setItem("po_users", JSON.stringify(updatedList));

      // Update current user cached copy inside auth instance
      currentUser.passwordHash = btoa(newPassword);

      setLocalSuccess("Your account credentials have been successfully updated.");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmNewPassword("");
    } catch (e) {
      setLocalErr("Encountered filesystem storage error while writing passwords updates.");
    }
  };

  const formatDate = (ts: number | undefined) => {
    if (!ts) return "2026-05-24";
    const d = new Date(ts);
    return d.toISOString().split("T")[0];
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 pt-4 pb-32 space-y-6">
      
      {/* 1. PROFILE DETAILS HEADER (Section 9) */}
      <div className="p-6 bg-bg-surface/75 border border-accent-cyan/10 rounded-2xl flex flex-col sm:flex-row items-center gap-6 shadow-xl relative overflow-hidden select-none">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-r from-accent-cyan to-accent-purple p-[2px] flex-shrink-0">
          <div className="w-full h-full bg-bg-surface rounded-2xl flex items-center justify-center text-accent-cyan shadow-[0_0_15px_rgba(0,229,255,0.25)]">
            <UserIcon className="w-7 h-7" />
          </div>
        </div>

        <div className="space-y-1 flex-1 text-center sm:text-left">
          <h2 className="text-xl font-orbitron font-extrabold text-glow-cyan text-text-light tracking-wide uppercase">
            {currentUser?.fullName}
          </h2>
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4 text-xs text-muted-blue font-sans">
            <span className="flex items-center gap-1">
              <Mail className="w-3.5 h-3.5" /> {currentUser?.email}
            </span>
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" /> Enrolled: {formatDate(currentUser?.joinedAt)}
            </span>
          </div>
        </div>

        <div className="px-4 py-2 bg-gradient-to-r from-accent-purple/10 to-accent-cyan/10 border border-accent-cyan/20 rounded-xl text-center select-none shrink-0 font-orbitron">
          <span className="text-[9px] text-muted-blue leading-none block uppercase">SECURITY LEVEL</span>
          <span className="text-xs font-bold text-accent-cyan tracking-wider">
            {currentUser?.isAdmin ? "OWNER PRO ADMIN" : "INTELLIGENCE OPERATIVE"}
          </span>
        </div>
      </div>

      {/* 2. APP NOTIFICATIONS AND SOUND OPTIONS (Section 9) */}
      <div className="p-6 bg-bg-surface/75 border border-accent-cyan/10 rounded-2xl space-y-4 shadow-xl select-none">
        
        <h3 className="text-xs font-orbitron font-extrabold text-glow-cyan text-text-light uppercase tracking-wider border-b border-white/5 pb-2 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-accent-cyan" /> Displays and Audio Configurations
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Sound Alerts Option toggler */}
          <div className="flex justify-between items-center p-3.5 bg-bg-deep/30 border border-white/5 rounded-xl">
            <div className="space-y-0.5">
              <span className="text-xs font-orbitron font-bold text-text-light uppercase tracking-wide block">
                Signal Beep Alert
              </span>
              <span className="text-[10px] text-muted-blue font-sans">
                Triggers beep on PLATINUM 96% confluences
              </span>
            </div>
            <button
              id="toggle_sound"
              type="button"
              onClick={() => setSoundAlerts(!soundAlerts)}
              className={`w-12 h-6 px-1 rounded-full flex items-center transition-colors cursor-pointer outline-none focus:outline-none ${
                soundAlerts ? "bg-buy-green" : "bg-gray-800"
              }`}
            >
              <motion.div
                layout
                className="w-4 h-4 bg-bg-deep rounded-full shadow"
                animate={{ x: soundAlerts ? 24 : 0 }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              />
            </button>
          </div>

          {/* Browser Notification option */}
          <div className="flex justify-between items-center p-3.5 bg-bg-deep/30 border border-white/5 rounded-xl">
            <div className="space-y-0.5">
              <span className="text-xs font-orbitron font-bold text-text-light uppercase tracking-wide block">
                Visual Alerts Popup
              </span>
              <span className="text-[10px] text-muted-blue font-sans">
                Flashes high-confluence banners inside dashboard
              </span>
            </div>
            <button
              id="toggle_notifications"
              type="button"
              onClick={() => setSignalNotifications(!signalNotifications)}
              className={`w-12 h-6 px-1 rounded-full flex items-center transition-colors cursor-pointer outline-none focus:outline-none ${
                signalNotifications ? "bg-buy-green" : "bg-gray-800"
              }`}
            >
              <motion.div
                layout
                className="w-4 h-4 bg-bg-deep rounded-full shadow"
                animate={{ x: signalNotifications ? 24 : 0 }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              />
            </button>
          </div>
        </div>

      </div>

      {/* 3. SECURITY PROFILE PASSWORD RESET FORM (Section 9) */}
      <div className="p-6 bg-bg-surface/75 border border-accent-cyan/10 rounded-2xl space-y-4 shadow-xl">
        
        <h3 className="text-xs font-orbitron font-extrabold text-glow-cyan text-text-light uppercase tracking-wider border-b border-white/5 pb-2 flex items-center gap-2 select-none">
          <Lock className="w-4 h-4 text-accent-cyan" /> Secure Credentials Modifiers
        </h3>

        <form onSubmit={handlePasswordReset} className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-1">
            <label className="text-[10px] font-orbitron uppercase text-muted-blue tracking-wider font-semibold select-none">
              Current password
            </label>
            <input
              id="settings_current_pass"
              type="password"
              value={currentPassword}
              onChange={e => setCurrentPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full h-11 px-4 text-xs bg-bg-deep/40 rounded-xl border border-accent-cyan/15 focus:border-accent-cyan text-text-light placeholder-muted-blue outline-none transition-all font-sans"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-orbitron uppercase text-muted-blue tracking-wider font-semibold select-none">
              New password
            </label>
            <input
              id="settings_new_pass"
              type="password"
              value={newPassword}
              onChange={e => setNewPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full h-11 px-4 text-xs bg-bg-deep/40 rounded-xl border border-accent-cyan/15 focus:border-accent-cyan text-text-light placeholder-muted-blue outline-none transition-all font-sans"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-orbitron uppercase text-muted-blue tracking-wider font-semibold select-none">
              Confirm new password
            </label>
            <input
              id="settings_confirm_pass"
              type="password"
              value={confirmNewPassword}
              onChange={e => setConfirmNewPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full h-11 px-4 text-xs bg-bg-deep/40 rounded-xl border border-accent-cyan/15 focus:border-accent-cyan text-text-light placeholder-muted-blue outline-none transition-all font-sans"
            />
          </div>

          {/* Messages Overlay */}
          <div className="md:col-span-3 pt-2">
            <AnimatePresence mode="wait">
              {err && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="flex items-start gap-2 p-3 bg-sell-red/10 border border-sell-red/30 rounded-xl text-sell-red text-[11px] leading-relaxed select-none"
                >
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{err}</span>
                </motion.div>
              )}

              {success && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="flex items-start gap-2 p-3 bg-buy-green/10 border border-buy-green/30 rounded-xl text-buy-green text-[11px] leading-relaxed select-none"
                >
                  <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{success}</span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Action button reset */}
          <div className="md:col-span-3 pt-2">
            <button
              id="btn_update_password"
              type="submit"
              className="px-5 h-11 rounded-xl bg-gradient-to-r from-accent-purple to-accent-cyan font-orbitron font-bold text-xs text-glow-cyan text-white tracking-widest hover:scale-103 active:scale-97 cursor-pointer"
            >
              COMMIT CREDENTIALS UPDATE
            </button>
          </div>

        </form>

      </div>

    </div>
  );
}
