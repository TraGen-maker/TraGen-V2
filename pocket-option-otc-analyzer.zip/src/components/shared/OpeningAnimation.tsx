import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ShieldCheck, Cpu, Terminal, Sparkles, ChevronRight } from "lucide-react";

export function OpeningAnimation({ onComplete }: { onComplete: () => void }) {
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState("INITIALIZING WARP LINK...");
  const [showApp, setShowApp] = useState(true);

  useEffect(() => {
    // Quickly run through authorization/connection simulations
    const texts = [
      "ESTABLISHING SECURE TUNNEL...",
      "SYNCING COLD WALLETS & LIQUIDITY...",
      "DECRYPTING ALGORITHMIC SIGNALS...",
      "CALIBRATING NEURAL CORE...",
      "WARREN CAPITAL CONVERGENCE ACTIVE!"
    ];

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(() => {
            setShowApp(false);
            setTimeout(onComplete, 300);
          }, 200);
          return 100;
        }
        
        // Update helper status messages proportionally
        const idx = Math.floor((prev / 100) * texts.length);
        if (texts[idx] && texts[idx] !== statusText) {
          setStatusText(texts[idx]);
        }
        
        return prev + (Math.random() * 12 + 6);
      });
    }, 70);

    return () => clearInterval(timer);
  }, [onComplete, statusText]);

  return (
    <AnimatePresence>
      {showApp && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.05 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
          className="fixed inset-0 z-[9999] bg-[#050B18] flex flex-col items-center justify-center p-6 select-none overflow-hidden"
        >
          {/* Neon Grid Ambient Background */}
          <div className="absolute inset-0 opacity-[0.04] pointer-events-none" 
               style={{
                 backgroundImage: "radial-gradient(#06E230 1px, transparent 1px)",
                 backgroundSize: "24px 24px"
               }} 
          />

          {/* Smooth Soft Glow Spots */}
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-72 h-72 bg-[#06E230]/10 rounded-full blur-[80px]" />
          <div className="absolute bottom-1/4 left-1/3 w-96 h-96 bg-accent-purple/5 rounded-full blur-[100px]" />

          <div className="w-full max-w-sm flex flex-col items-center text-center space-y-8 z-10">
            {/* Pulsative Main Logo/Icon Hexagon Ring */}
            <motion.div
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              className="relative flex items-center justify-center w-24 h-24"
            >
              {/* Spinning/pulsative outer circle in #06E230 */}
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 6, ease: "linear" }}
                className="absolute inset-0 rounded-full border border-dashed border-[#06E230] opacity-80"
              />

              {/* Glowing pulsating secondary ring */}
              <motion.div
                animate={{ scale: [1, 1.15, 1] }}
                transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                className="absolute inset-2 rounded-full border border-[#06E230]/30 shadow-[0_0_15px_rgba(6,226,48,0.2)]"
              />

              {/* Core Terminal Processor Emblem */}
              <div className="absolute inset-4 rounded-full bg-[#0D1B2E]/90 border border-[#06E230] flex items-center justify-center shadow-[0_0_20px_rgba(6,226,48,0.3)]">
                <Cpu className="w-8 h-8 text-[#06E230] animate-pulse" />
              </div>
            </motion.div>

            {/* Brand Title with Custom Font and the Glow color #06E230 */}
            <div className="space-y-1.5">
              <motion.h1
                initial={{ y: 15, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2, duration: 0.5 }}
                className="text-2xl font-orbitron font-black tracking-widest text-text-light flex items-center justify-center gap-1"
              >
                WSM<span className="text-[#06E230] text-glow-neon-green">FOREX</span>
              </motion.h1>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.6 }}
                transition={{ delay: 0.4 }}
                className="text-[10px] font-mono tracking-[0.2em] uppercase text-muted-blue"
              >
                AUTOMATED QUANTUM MATRIX
              </motion.p>
            </div>

            {/* Neon Bar Progress Gauge in #06E230 */}
            <div className="w-full space-y-2">
              <div className="flex justify-between items-center text-[9px] font-mono text-muted-blue px-1">
                <span className="flex items-center gap-1 uppercase">
                  <Terminal className="w-3 h-3 text-[#06E230]" />
                  {statusText}
                </span>
                <span className="text-[#06E230] font-bold text-glow-neon-green">{Math.min(Math.floor(progress), 100)}%</span>
              </div>
              
              <div className="h-1.5 w-full bg-black/60 rounded-full overflow-hidden p-[2px] border border-white/5">
                <motion.div
                  className="h-full bg-gradient-to-r from-[#06E230]/40 to-[#06E230] rounded-full shadow-[0_0_8px_rgba(6,226,48,0.7)]"
                  style={{ width: `${Math.min(progress, 100)}%` }}
                  layoutId="loadingProgressBar"
                />
              </div>
            </div>

            {/* Quick Skip for ultra rapid development / access bypass */}
            <motion.button
              id="btn_splash_skip"
              onClick={() => {
                setShowApp(false);
                setTimeout(onComplete, 100);
              }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-4 py-1.5 rounded-full bg-white/[0.04] hover:bg-[#06E230]/10 border border-white/5 hover:border-[#06E230]/20 text-[9px] font-mono text-muted-blue hover:text-[#06E230] tracking-widest flex items-center gap-1 transition-all pointer-events-auto cursor-pointer"
            >
              SKIP CALIBRATION
              <ChevronRight className="w-3 h-3" />
            </motion.button>
          </div>

          {/* Bottom Footnote watermark */}
          <div className="absolute bottom-6 flex items-center gap-1.5 text-[9px] font-mono text-muted-blue/60 uppercase tracking-widest">
            <Sparkles className="w-3 h-3 text-[#06E230]" />
            ACTIVE LAYER: SECURE SHIELD
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
