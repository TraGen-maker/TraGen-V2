import { memo } from "react";
import { motion } from "motion/react";

export const FloatingOrbs = memo(function FloatingOrbs() {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none -z-50 select-none">
      {/* Orb 1: Cyan Glow */}
      <motion.div
        id="orb_cyan"
        className="absolute rounded-full filter blur-[130px] mix-blend-screen bg-accent-cyan/10"
        style={{ width: "400px", height: "400px", left: "10%", top: "15%" }}
        animate={{
          x: [0, 80, -40, 0],
          y: [0, -60, 40, 0],
        }}
        transition={{
          duration: 25,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Orb 2: Purple Glow */}
      <motion.div
        id="orb_purple"
        className="absolute rounded-full filter blur-[150px] mix-blend-screen bg-accent-purple/10"
        style={{ width: "500px", height: "500px", right: "15%", bottom: "20%" }}
        animate={{
          x: [0, -90, 50, 0],
          y: [0, 80, -90, 0],
        }}
        transition={{
          duration: 30,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Orb 3: Indigo/Blue Glow */}
      <motion.div
        id="orb_indigo"
        className="absolute rounded-full filter blur-[140px] mix-blend-screen bg-muted-blue/10"
        style={{ width: "350px", height: "350px", left: "40%", top: "60%" }}
        animate={{
          x: [0, 40, -60, 0],
          y: [0, 70, -40, 0],
        }}
        transition={{
          duration: 22,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
    </div>
  );
});
