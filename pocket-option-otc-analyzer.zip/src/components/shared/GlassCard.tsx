import React from "react";
import { motion } from "motion/react";

interface GlassCardProps {
  id?: string;
  className?: string;
  children: React.ReactNode;
  borderAccent?: boolean;
  onClick?: () => void;
}

export function GlassCard({ id, className = "", children, borderAccent = false, onClick }: GlassCardProps) {
  const cardContent = (
    <div
      id={id}
      className={`glass-panel p-6 rounded-2xl ${
        borderAccent ? "border-accent-purple/30 shadow-[0_0_50px_rgba(123,47,255,0.08)] bg-bg-surface/90" : ""
      } ${className}`}
      onClick={onClick}
    >
      {children}
    </div>
  );

  if (onClick) {
    return (
      <motion.button
        type="button"
        whileHover={{ scale: 1.012, translateY: -2 }}
        whileTap={{ scale: 0.988 }}
        transition={{ type: "spring", stiffness: 400, damping: 15 }}
         className="w-full text-left bg-transparent border-0 cursor-pointer p-0 focus:outline-none"
      >
        {cardContent}
      </motion.button>
    );
  }

  return cardContent;
}
