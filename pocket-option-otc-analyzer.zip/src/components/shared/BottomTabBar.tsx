import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../../store/authStore";
import { LayoutDashboard, Bell, BarChart3, Settings, ShieldAlert } from "lucide-react";
import { motion } from "motion/react";

export function BottomTabBar() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const currentPath = location.pathname;

  const navItems = [
    { label: "Dashboard", path: "/dashboard", icon: LayoutDashboard },
    { label: "Signals", path: "/signals", icon: Bell },
    { label: "Analytics", path: "/analytics", icon: BarChart3 },
    { label: "Settings", path: "/settings", icon: Settings },
  ];

  // Admin tab is only visible to users whose account has isAdmin = true
  if (currentUser?.isAdmin) {
    navItems.push({ label: "Admin", path: "/admin", icon: ShieldAlert });
  }

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 w-full max-w-lg px-4 select-none">
      <div className="relative flex items-center justify-between gap-1 p-2 bg-bg-surface/85 backdrop-blur-2xl rounded-full border border-accent-cyan/15 shadow-[0_10px_40px_rgba(0,0,0,0.6)]">
        {navItems.map(item => {
          const isActive = currentPath === item.path;
          const Icon = item.icon;

          return (
            <button
              key={item.path}
              id={`tab_${item.label.toLowerCase()}`}
              type="button"
              onClick={() => navigate(item.path)}
              className="relative flex flex-col items-center justify-center flex-1 py-2 px-1 text-center transition-colors cursor-pointer outline-none focus:outline-none focus-visible:ring-2 focus-visible:ring-accent-cyan/50 rounded-full"
            >
              {/* Highlight background pill under the active item */}
              {isActive && (
                <motion.div
                  layoutId="active-tab-background"
                  className="absolute inset-0 bg-accent-cyan/10 rounded-full"
                  transition={{ type: "spring", stiffness: 380, damping: 25 }}
                />
              )}

              {/* Icon and label */}
              <motion.div
                animate={{
                  scale: isActive ? 1.15 : 1,
                  filter: isActive ? "drop-shadow(0 0 8px rgba(0,229,255,0.7))" : "none",
                }}
                transition={{ type: "spring", stiffness: 400, damping: 15 }}
                className={`relative z-10 ${isActive ? "text-accent-cyan" : "text-muted-blue hover:text-text-light/80"}`}
              >
                <Icon className="w-5 h-5 mx-auto" />
                <span className="text-[10px] font-orbitron font-medium mt-1 block uppercase tracking-wider">
                  {item.label}
                </span>
              </motion.div>

              {/* Active Slide Underline */}
              {isActive && (
                <motion.div
                  className="absolute bottom-1 w-8 h-[2px] bg-accent-cyan rounded-full z-10"
                  layoutId="active-tab-indicator"
                  transition={{ type: "spring", stiffness: 350, damping: 25 }}
                />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
