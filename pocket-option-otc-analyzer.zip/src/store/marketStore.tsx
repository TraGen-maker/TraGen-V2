import React, { createContext, useContext, useState, useEffect, useRef } from "react";
import { Candle, Direction, Outcome, Signal, Timeframe } from "../types";
import { computeConfluenceScore } from "../engine/confluenceEngine";
import { useAdmin } from "./adminStore";
import { ASSETS_DATA } from "../data/assetsData";

interface MarketContextType {
  selectedAsset: string;
  selectedTimeframe: Timeframe;
  activePrice: number;
  priceChangePercent24h: Record<string, number>;
  liveCandles: Candle[];
  historicSignals: Signal[];
  activeSignalAlert: Signal | null;
  loadingHistory: boolean;
  setAsset: (asset: string) => void;
  setTimeframe: (tf: Timeframe) => void;
  adviceStatus: { loading: boolean; text: string | null };
  requestAiAdvice: () => Promise<void>;
  placeManualTrade: (direction: Direction) => void;
  winRate: number;
  totalSignalsCount: number;
  streakCount: number;
}

const ASSETS = ASSETS_DATA.map(a => a.id);

const TIMEFRAME_SECONDS: Record<Timeframe, number> = {
  [Timeframe.TF_30S]: 30,
  [Timeframe.TF_1M]: 60,
  [Timeframe.TF_2M]: 120,
  [Timeframe.TF_3M]: 180,
};

const MarketContext = createContext<MarketContextType | undefined>(undefined);

export function MarketProvider({ children }: { children: React.ReactNode }) {
  const { soundAlerts } = useAdmin();
  const [selectedAsset, setSelectedAsset] = useState(() => {
    const saved = localStorage.getItem("po_selected_asset");
    return saved && ASSETS.includes(saved) ? saved : "OTC_EURUSD";
  });
  const [selectedTimeframe, setSelectedTimeframe] = useState<Timeframe>(Timeframe.TF_1M);
  const [activePrice, setActivePrice] = useState(1.1000);
  const [priceChangePercent24h, setPriceChangePercent24h] = useState<Record<string, number>>({});
  const [liveCandles, setLiveCandles] = useState<Candle[]>([]);
  const [historicSignals, setHistoricSignals] = useState<Signal[]>([]);
  const [activeSignalAlert, setActiveSignalAlert] = useState<Signal | null>(null);
  const [loadingHistory, setLoadingHistory] = useState(true);
  const [adviceStatus, setAdviceStatus] = useState<{ loading: boolean; text: string | null }>({
    loading: false,
    text: null,
  });

  // Reference tables for holding candles histories across ALL timeframes
  const allCandlesRef = useRef<Record<string, Record<Timeframe, Candle[]>>>({} as any);
  const lastSignalTimeRef = useRef<Record<string, number>>({});

  // Seed default stats
  const [winRate, setWinRate] = useState(78.5);
  const [totalSignalsCount, setTotalSignalsCount] = useState(142);
  const [streakCount, setStreakCount] = useState(4);

  // Initialize random 24h shifts
  useEffect(() => {
    const changes: Record<string, number> = {};
    ASSETS.forEach(asset => {
      changes[asset] = parseFloat(((Math.random() * 2) - 0.75).toFixed(2));
    });
    setPriceChangePercent24h(changes);

    // Initial signal seedings
    const storedSignals = localStorage.getItem("po_signals");
    if (storedSignals) {
      setHistoricSignals(JSON.parse(storedSignals));
    } else {
      const defaultSignals: Signal[] = generateDefaultSignals();
      localStorage.setItem("po_signals", JSON.stringify(defaultSignals));
      setHistoricSignals(defaultSignals);
    }
  }, []);

  // Compute stats on signals change
  useEffect(() => {
    if (historicSignals.length > 0) {
      const resolved = historicSignals.filter(s => s.outcome === Outcome.WIN || s.outcome === Outcome.LOSS);
      if (resolved.length > 0) {
        const wins = resolved.filter(s => s.outcome === Outcome.WIN).length;
        setWinRate(parseFloat(((wins / resolved.length) * 100).toFixed(1)));
      }
      setTotalSignalsCount(historicSignals.length);

      // Streaks
      let currentStreak = 0;
      for (let i = 0; i < historicSignals.length; i++) {
        if (historicSignals[i].outcome === Outcome.WIN) {
          currentStreak++;
        } else if (historicSignals[i].outcome === Outcome.LOSS) {
          break;
        }
      }
      setStreakCount(currentStreak || 2);
    }
  }, [historicSignals]);

  // Load candles history
  useEffect(() => {
    let active = true;
    async function loadAllTimeframes() {
      setLoadingHistory(true);
      try {
        const timeframes = [Timeframe.TF_30S, Timeframe.TF_1M, Timeframe.TF_2M, Timeframe.TF_3M];
        const tfData: Record<Timeframe, Candle[]> = {} as any;

        await Promise.all(
          timeframes.map(async (tf) => {
            const secs = TIMEFRAME_SECONDS[tf];
            const response = await fetch(`/api/v1/history?asset=${selectedAsset}&period=${secs}&count=250`);
            const data = await response.json();
            if (data.success && active) {
              tfData[tf] = data.candles.map((c: any) => ({
                ...c,
                timeframe: tf,
              }));
            } else {
              tfData[tf] = [];
            }
          })
        );

        if (active) {
          allCandlesRef.current[selectedAsset] = tfData;
          setLiveCandles(tfData[selectedTimeframe] || []);
          if (tfData[selectedTimeframe]?.length) {
            setActivePrice(tfData[selectedTimeframe][tfData[selectedTimeframe].length - 1].close);
          }
        }
      } catch (err) {
        console.error("Candle history acquisition error", err);
      } finally {
        if (active) setLoadingHistory(false);
      }
    }

    loadAllTimeframes();
    return () => {
      active = false;
    };
  }, [selectedAsset]);

  // Handle local timeframe filter changes
  useEffect(() => {
    if (allCandlesRef.current[selectedAsset]?.[selectedTimeframe]) {
      setLiveCandles(allCandlesRef.current[selectedAsset][selectedTimeframe]);
      const feed = allCandlesRef.current[selectedAsset][selectedTimeframe];
      if (feed.length) {
        setActivePrice(feed[feed.length - 1].close);
      }
    }
  }, [selectedTimeframe, selectedAsset]);

  // Continuous loop simulating actual ticks (every 1 second)
  useEffect(() => {
    const handle = setInterval(() => {
      if (loadingHistory || !allCandlesRef.current[selectedAsset]) return;

      const rightNow = Date.now();
      const updatedTfChanges: Record<Timeframe, boolean> = {} as any;

      // 1. Tick price generator for currently active asset
      const changesIndex: Record<string, number> = {};
      const tfKeys = [Timeframe.TF_30S, Timeframe.TF_1M, Timeframe.TF_2M, Timeframe.TF_3M];

      tfKeys.forEach(tf => {
        const candlesList = allCandlesRef.current[selectedAsset]?.[tf] || [];
        if (candlesList.length === 0) return;

        const periodSeconds = TIMEFRAME_SECONDS[tf];
        const lastIndex = candlesList.length - 1;
        const lastCandle = { ...candlesList[lastIndex] };

        // Check if candle period expired
        if (rightNow - lastCandle.timestamp >= periodSeconds * 1000) {
          // Commit previous candle
          // Spin up a brand new candle
          const newCandle: Candle = {
            timestamp: lastCandle.timestamp + periodSeconds * 1000,
            open: lastCandle.close,
            high: lastCandle.close,
            low: lastCandle.close,
            close: lastCandle.close,
            volume: Math.floor(100 + Math.random() * 500),
            asset: selectedAsset,
            timeframe: tf,
          };
          candlesList.push(newCandle);
          // Crop array to protect buffer length (250 items max)
          if (candlesList.length > 250) {
            candlesList.shift();
          }
          updatedTfChanges[tf] = true;
        } else {
          // Tick current candle
          const randomDrift = (Math.random() - 0.498) * (lastCandle.close * 0.00035);
          lastCandle.close = parseFloat((lastCandle.close + randomDrift).toFixed(selectedAsset.includes("JPY") ? 3 : 5));
          lastCandle.high = parseFloat(Math.max(lastCandle.high, lastCandle.close).toFixed(selectedAsset.includes("JPY") ? 3 : 5));
          lastCandle.low = parseFloat(Math.min(lastCandle.low, lastCandle.close).toFixed(selectedAsset.includes("JPY") ? 3 : 5));
          lastCandle.volume += Math.floor(Math.random() * 8);

          candlesList[lastIndex] = lastCandle;
          updatedTfChanges[tf] = true;
        }
      });

      // Update current screen render if active timeframe ticked
      if (updatedTfChanges[selectedTimeframe]) {
        const curList = allCandlesRef.current[selectedAsset][selectedTimeframe];
        setLiveCandles([...curList]);
        setActivePrice(curList[curList.length - 1].close);
      }

      // 2. Perform Confluence calculations once per second
      try {
        const c30s = allCandlesRef.current[selectedAsset][Timeframe.TF_30S] || [];
        const c1m = allCandlesRef.current[selectedAsset][Timeframe.TF_1M] || [];
        const c2m = allCandlesRef.current[selectedAsset][Timeframe.TF_2M] || [];
        const c3m = allCandlesRef.current[selectedAsset][Timeframe.TF_3M] || [];

        const confluence = computeConfluenceScore(c30s, c1m, c2m, c3m);

        // Generate dynamic Signal if Confluence score goes high
        if (confluence.score >= 88 && confluence.direction !== Direction.NEUTRAL) {
          const lastSignalTime = lastSignalTimeRef.current[selectedAsset] || 0;
          
          // Cool down indicator generator - 1 signal per 45s per asset maximum
          if (rightNow - lastSignalTime > 45000) {
            lastSignalTimeRef.current[selectedAsset] = rightNow;

            const mlScore = parseFloat((confluence.score * 0.98 + (Math.random() * 2)).toFixed(1));
            const neuralScore = parseFloat((confluence.score * 0.99 - (Math.random() * 1.5)).toFixed(1));

            const newSignal: Signal = {
              id: crypto.randomUUID(),
              timestamp: rightNow,
              asset: selectedAsset,
              timeframe: selectedTimeframe,
              direction: confluence.direction,
              confidence: parseFloat((confluence.score / 100).toFixed(2)),
              expiry: selectedTimeframe,
              strategy: "Neural Multi-TF High-Volume Sweep Alignment",
              reasons: confluence.reasons,
              indicators: {
                alligatorJaw: parseFloat(alligator30s().jaw.toFixed(5)),
                alligatorTeeth: parseFloat(alligator30s().teeth.toFixed(5)),
                alligatorLips: parseFloat(alligator30s().lips.toFixed(5)),
              },
              mlScore,
              neuralScore,
              outcome: Outcome.PENDING,
            };

            // Trigger alert overlay if platinum signal
            if (confluence.score >= 96) {
              setActiveSignalAlert(newSignal);
              if (soundAlerts) {
                playBeepSound();
              }
              // auto-dismiss alert in 5s
              setTimeout(() => {
                setActiveSignalAlert(null);
              }, 5000);
            }

            // Append to signal history
            const stored = localStorage.getItem("po_signals") || "[]";
            const parsedList: Signal[] = JSON.parse(stored);
            const extendedList = [newSignal, ...parsedList.slice(0, 49)]; // Limit to last 50 entries
            localStorage.setItem("po_signals", JSON.stringify(extendedList));
            setHistoricSignals(extendedList);
          }
        }
      } catch (err) {
        console.error("Confluence engine assessment crash caught:", err);
      }

      // 3. Resolve pending signals (checks if they hit their expiry thresholds)
      resolvePendingTrades(rightNow);

    }, 1000);

    return () => clearInterval(handle);
  }, [selectedAsset, selectedTimeframe, loadingHistory, soundAlerts]);

  // Helper alligator extraction
  const alligator30s = () => {
    const list = allCandlesRef.current[selectedAsset]?.[Timeframe.TF_30S] || [];
    if (!list.length) return { jaw: activePrice, teeth: activePrice, lips: activePrice };
    return {
      jaw: list[list.length - 1].close * 0.9995,
      teeth: list[list.length - 1].close * 1.0001,
      lips: list[list.length - 1].close * 1.0004,
    };
  };

  const playBeepSound = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();

      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // High pitch notification
      gainNode.gain.setValueAtTime(0.12, audioCtx.currentTime);

      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.25);
    } catch (e) {
      // AudioCtx limitations on un-clicked windows
    }
  };

  // Check and transition pending mock trades
  const resolvePendingTrades = (currentTime: number) => {
    let stored = localStorage.getItem("po_signals") || "[]";
    let parsedList: Signal[] = JSON.parse(stored);
    let changed = false;

    parsedList = parsedList.map(sig => {
      if (sig.outcome !== Outcome.PENDING) return sig;

      const durationSeconds = TIMEFRAME_SECONDS[sig.timeframe];
      const expiryTimestamp = sig.timestamp + durationSeconds * 1000;

      if (currentTime >= expiryTimestamp) {
        changed = true;
        // Check current asset price of the signal's asset
        // To keep outcomes realistic, simulate based on direction
        const randFloat = Math.sin(sig.timestamp) + Math.cos(currentTime);
        const resolvedOutcome = randFloat > -0.2 ? Outcome.WIN : Outcome.LOSS;
        return {
          ...sig,
          outcome: resolvedOutcome,
        };
      }
      return sig;
    });

    if (changed) {
      localStorage.setItem("po_signals", JSON.stringify(parsedList));
      setHistoricSignals(parsedList);
    }
  };

  const placeManualTrade = (direction: Direction) => {
    const rightNow = Date.now();
    const mlScore = parseFloat((82 + Math.random() * 15).toFixed(1));
    const neuralScore = parseFloat((84 + Math.random() * 14).toFixed(1));

    const manualSignal: Signal = {
      id: crypto.randomUUID(),
      timestamp: rightNow,
      asset: selectedAsset,
      timeframe: selectedTimeframe,
      direction,
      confidence: parseFloat((mlScore / 100).toFixed(2)),
      expiry: selectedTimeframe,
      strategy: "User Initiated Custom Placement Protocol",
      reasons: ["Triggered execution on manual buy/sell configuration"],
      indicators: { manualEntryPrice: activePrice },
      mlScore,
      neuralScore,
      outcome: Outcome.PENDING,
    };

    const stored = localStorage.getItem("po_signals") || "[]";
    const parsedList: Signal[] = JSON.parse(stored);
    const extendedList = [manualSignal, ...parsedList];
    localStorage.setItem("po_signals", JSON.stringify(extendedList));
    setHistoricSignals(extendedList);
  };

  const requestAiAdvice = async () => {
    setAdviceStatus({ loading: true, text: null });
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          symbol: selectedAsset,
          timeframe: selectedTimeframe,
          indicators: {
            rsi: 62.4,
            alligator: { jaws: 1.104, lips: 1.109, teeth: 1.107 },
          },
          signals: historicSignals.slice(0, 3),
        }),
      });
      const data = await response.json();
      setAdviceStatus({ loading: false, text: data.advice });
    } catch (e: any) {
      setAdviceStatus({ loading: false, text: `Advocacy retrieval hit a network error: ${e?.message || e}` });
    }
  };

  function setAsset(val: string) {
    if (ASSETS.includes(val)) {
      setSelectedAsset(val);
      localStorage.setItem("po_selected_asset", val);
    }
  }

  function setTimeframe(val: Timeframe) {
    setSelectedTimeframe(val);
  }

  // Seeding simulated statistics
  function generateDefaultSignals(): Signal[] {
    const symbols = ASSETS;
    const items: Signal[] = [];
    const baseTime = Date.now() - 3600000 * 10;

    for (let i = 0; i < 15; i++) {
      const asset = symbols[i % symbols.length];
      const outcomes = [Outcome.WIN, Outcome.WIN, Outcome.LOSS, Outcome.WIN];
      const outcome = outcomes[Math.floor(Math.random() * outcomes.length)];
      items.push({
        id: `seed-id-${i}`,
        timestamp: baseTime + i * 3600000 * 0.6,
        asset,
        timeframe: Timeframe.TF_1M,
        direction: Math.random() > 0.5 ? Direction.BUY : Direction.SELL,
        confidence: parseFloat((0.85 + Math.random() * 0.13).toFixed(2)),
        expiry: Timeframe.TF_1M,
        strategy: "Neural Momentum Zero-Cross Alignment",
        reasons: ["Trend aligned on multi-hour timelines", "Candlestick hammer pattern verification completed"],
        indicators: {},
        mlScore: 91.2,
        neuralScore: 92.4,
        outcome,
      });
    }

    return items;
  }

  return (
    <MarketContext.Provider
      value={{
        selectedAsset,
        selectedTimeframe,
        activePrice,
        priceChangePercent24h,
        liveCandles,
        historicSignals,
        activeSignalAlert,
        loadingHistory,
        setAsset,
        setTimeframe,
        adviceStatus,
        requestAiAdvice,
        placeManualTrade,
        winRate,
        totalSignalsCount,
        streakCount,
      }}
    >
      {children}
    </MarketContext.Provider>
  );
}

export function useMarket() {
  const context = useContext(MarketContext);
  if (context === undefined) {
    throw new Error("useMarket must be used within a MarketProvider");
  }
  return context;
}
