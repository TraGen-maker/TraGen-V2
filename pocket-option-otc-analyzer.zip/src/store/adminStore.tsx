import React, { createContext, useContext, useState, useEffect } from "react";
import { User, DailyCode } from "./authStore";

export interface CodeHistoryEntry {
  code: string;
  createdAt: number;
  expiresAt: number;
  usersUsed: number;
}

interface AdminContextType {
  dailyCode: DailyCode | null;
  codeHistory: CodeHistoryEntry[];
  users: User[];
  maintenanceMode: boolean;
  soundAlerts: boolean;
  signalNotifications: boolean;
  ssidToken: string;
  ssidConnected: boolean;
  welcomeMessage: string;
  generateNewAccessCode: () => void;
  setCustomAccessCode: (code: string) => void;
  fetchUsers: () => void;
  toggleUserStatus: (userId: string) => void;
  deleteUser: (userId: string) => void;
  toggleUserAdmin: (userId: string) => void;
  setMaintenanceMode: (val: boolean) => void;
  setSoundAlerts: (val: boolean) => void;
  setSignalNotifications: (val: boolean) => void;
  setSsidToken: (val: string) => void;
  setWelcomeMessage: (val: string) => void;
}

const AdminContext = createContext<AdminContextType | undefined>(undefined);

export function AdminProvider({ children }: { children: React.ReactNode }) {
  const [dailyCode, setDailyCode] = useState<DailyCode | null>(null);
  const [codeHistory, setCodeHistory] = useState<CodeHistoryEntry[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [maintenanceMode, setMaintenanceModeState] = useState(false);
  const [soundAlerts, setSoundAlertsState] = useState(true);
  const [signalNotifications, setSignalNotificationsState] = useState(true);
  const [ssidToken, setSsidTokenState] = useState("");
  const [ssidConnected, setSsidConnected] = useState(false);
  const [welcomeMessage, setWelcomeMessageState] = useState(
    "Welcome to the TraGen v2.0 High-Confluence Quantum System. The neural predictive indicators are fully aligned. Align your parameters to target 96% confluences."
  );

  useEffect(() => {
    try {
      // 1. Hydrate daily access code
      const currentCodeStr = localStorage.getItem("po_daily_code");
      if (currentCodeStr) {
        setDailyCode(JSON.parse(currentCodeStr));
      } else {
        const midnight = new Date();
        midnight.setHours(23, 59, 59, 999);
        const codeObj: DailyCode = {
          code: "X7K-9P2",
          createdAt: Date.now(),
          expiresAt: midnight.getTime(),
        };
        localStorage.setItem("po_daily_code", JSON.stringify(codeObj));
        setDailyCode(codeObj);
      }

      // 2. Hydrate history codes tracker
      const historyStr = localStorage.getItem("po_code_history");
      if (historyStr) {
        setCodeHistory(JSON.parse(historyStr));
      } else {
        const midnight = new Date();
        midnight.setHours(23, 59, 59, 999);
        const defaultHistory: CodeHistoryEntry[] = [
          { code: "X7K-9P2", createdAt: Date.now() - 3600000, expiresAt: midnight.getTime(), usersUsed: 1 },
          { code: "A1B-2C3", createdAt: Date.now() - 86400000, expiresAt: Date.now() - 3600000, usersUsed: 8 },
          { code: "K9L-5M2", createdAt: Date.now() - 172800000, expiresAt: Date.now() - 86400000, usersUsed: 14 },
          { code: "P3Q-7R9", createdAt: Date.now() - 259200000, expiresAt: Date.now() - 172800000, usersUsed: 12 },
        ];
        localStorage.setItem("po_code_history", JSON.stringify(defaultHistory));
        setCodeHistory(defaultHistory);
      }

      // 3. Hydrate users
      const storedUsers = localStorage.getItem("po_users");
      if (storedUsers) {
        setUsers(JSON.parse(storedUsers));
      }

      // 4. Hydrate app control toggles
      setMaintenanceModeState(localStorage.getItem("po_maintenance_mode") === "true");
      setSoundAlertsState(localStorage.getItem("po_sound_alerts") !== "false"); // default true
      setSignalNotificationsState(localStorage.getItem("po_signal_notifications") !== "false"); // default true
      
      const savedSsid = localStorage.getItem("po_ssid_token") || "";
      setSsidTokenState(savedSsid);
      setSsidConnected(savedSsid.length > 10);

      const savedWelcome = localStorage.getItem("po_welcome_message");
      if (savedWelcome) {
        setWelcomeMessageState(savedWelcome);
      }
    } catch (e) {
      console.error("Hydration of admin settings error:", e);
    }
  }, []);

  const fetchUsers = () => {
    const list = localStorage.getItem("po_users");
    if (list) {
      setUsers(JSON.parse(list));
    }
  };

  // Access Code generation
  const generateNewAccessCode = () => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // readable chars (removed O, 1, I, 0)
    let randomCode = "";
    for (let i = 0; i < 6; i++) {
      if (i === 3) randomCode += "-";
      randomCode += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    const midnight = new Date();
    midnight.setHours(23, 59, 59, 999);

    const newCodeObj: DailyCode = {
      code: randomCode,
      createdAt: Date.now(),
      expiresAt: midnight.getTime(),
    };

    // Save previous active code to history list
    if (dailyCode) {
      const entry: CodeHistoryEntry = {
        code: dailyCode.code,
        createdAt: dailyCode.createdAt,
        expiresAt: dailyCode.expiresAt,
        usersUsed: 0, 
      };
      const updatedHistory = [entry, ...codeHistory.slice(0, 6)]; // limit to last 7 total
      localStorage.setItem("po_code_history", JSON.stringify(updatedHistory));
      setCodeHistory(updatedHistory);
    }

    localStorage.setItem("po_daily_code", JSON.stringify(newCodeObj));
    setDailyCode(newCodeObj);
  };

  const setCustomAccessCode = (customCode: string) => {
    const upperCode = customCode.trim().toUpperCase();
    const midnight = new Date();
    midnight.setHours(23, 59, 59, 999);

    const newCodeObj: DailyCode = {
      code: upperCode,
      createdAt: Date.now(),
      expiresAt: midnight.getTime(),
    };

    if (dailyCode && dailyCode.code !== upperCode) {
      const entry: CodeHistoryEntry = {
        code: dailyCode.code,
        createdAt: dailyCode.createdAt,
        expiresAt: dailyCode.expiresAt,
        usersUsed: 1,
      };
      const updatedHistory = [entry, ...codeHistory.slice(0, 6)];
      localStorage.setItem("po_code_history", JSON.stringify(updatedHistory));
      setCodeHistory(updatedHistory);
    }

    localStorage.setItem("po_daily_code", JSON.stringify(newCodeObj));
    setDailyCode(newCodeObj);
  };

  // User list actions
  const toggleUserStatus = (userId: string) => {
    const list: User[] = JSON.parse(localStorage.getItem("po_users") || "[]");
    const updated = list.map(user => {
      if (user.id === userId) {
        return {
          ...user,
          status: user.status === "active" ? ("suspended" as const) : ("active" as const),
        };
      }
      return user;
    });
    localStorage.setItem("po_users", JSON.stringify(updated));
    setUsers(updated);
  };

  const deleteUser = (userId: string) => {
    const list: User[] = JSON.parse(localStorage.getItem("po_users") || "[]");
    const filtered = list.filter(user => user.id !== userId);
    localStorage.setItem("po_users", JSON.stringify(filtered));
    setUsers(filtered);
  };

  const toggleUserAdmin = (userId: string) => {
    const list: User[] = JSON.parse(localStorage.getItem("po_users") || "[]");
    const updated = list.map(user => {
      if (user.id === userId) {
        return {
          ...user,
          isAdmin: !user.isAdmin,
        };
      }
      return user;
    });
    localStorage.setItem("po_users", JSON.stringify(updated));
    setUsers(updated);
  };

  const setMaintenanceMode = (val: boolean) => {
    localStorage.setItem("po_maintenance_mode", val ? "true" : "false");
    setMaintenanceModeState(val);
  };

  const setSoundAlerts = (val: boolean) => {
    localStorage.setItem("po_sound_alerts", val ? "true" : "false");
    setSoundAlertsState(val);
  };

  const setSignalNotifications = (val: boolean) => {
    localStorage.setItem("po_signal_notifications", val ? "true" : "false");
    setSignalNotificationsState(val);
  };

  const setSsidToken = (val: string) => {
    localStorage.setItem("po_ssid_token", val);
    setSsidTokenState(val);
    setSsidConnected(val.trim().length > 10);
  };

  const setWelcomeMessage = (val: string) => {
    localStorage.setItem("po_welcome_message", val);
    setWelcomeMessageState(val);
  };

  return (
    <AdminContext.Provider
      value={{
        dailyCode,
        codeHistory,
        users,
        maintenanceMode,
        soundAlerts,
        signalNotifications,
        ssidToken,
        ssidConnected,
        welcomeMessage,
        generateNewAccessCode,
        setCustomAccessCode,
        fetchUsers,
        toggleUserStatus,
        deleteUser,
        toggleUserAdmin,
        setMaintenanceMode,
        setSoundAlerts,
        setSignalNotifications,
        setSsidToken,
        setWelcomeMessage,
      }}
    >
      {children}
    </AdminContext.Provider>
  );
}

export function useAdmin() {
  const context = useContext(AdminContext);
  if (context === undefined) {
    throw new Error("useAdmin must be used within an AdminProvider");
  }
  return context;
}
