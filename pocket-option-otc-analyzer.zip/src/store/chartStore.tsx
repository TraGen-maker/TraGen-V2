import React, { createContext, useContext, useState, useEffect } from "react";

export interface IndicatorConfig {
  showAlligator: boolean;
  alligatorJaw: number;
  alligatorTeeth: number;
  alligatorLips: number;

  showKeltner: boolean;
  keltnerEma: number;
  keltnerAtr: number;
  keltnerMultiplier: number;

  showMACD: boolean;
  macdFast: number;
  macdSlow: number;
  macdSignal: number;

  showStochastic: boolean;
  stochK: number;
  stochD: number;
  stochSlowing: number;

  showFVG: boolean;
  showOB: boolean;
  showLiquiditySweep: boolean;
  showAMD: boolean;
}

export interface ChartTemplate {
  name: string;
  config: IndicatorConfig;
  isPreset?: boolean;
}

interface ChartConfigContextType {
  config: IndicatorConfig;
  savedTemplates: ChartTemplate[];
  activeTemplate: string | null;
  updateConfig: (updater: Partial<IndicatorConfig>) => void;
  saveTemplate: (name: string) => void;
  applyTemplate: (name: string) => void;
  deleteTemplate: (name: string) => void;
}

const DEFAULT_CONFIG: IndicatorConfig = {
  showAlligator: true,
  alligatorJaw: 13,
  alligatorTeeth: 8,
  alligatorLips: 5,

  showKeltner: true,
  keltnerEma: 20,
  keltnerAtr: 10,
  keltnerMultiplier: 1.5,

  showMACD: false,
  macdFast: 12,
  macdSlow: 26,
  macdSignal: 9,

  showStochastic: false,
  stochK: 14,
  stochD: 3,
  stochSlowing: 3,

  showFVG: true,
  showOB: true,
  showLiquiditySweep: true,
  showAMD: true,
};

const PRESETS: ChartTemplate[] = [
  {
    name: "Classic Alligator Momentum",
    isPreset: true,
    config: {
      ...DEFAULT_CONFIG,
      showAlligator: true,
      showKeltner: false,
      showMACD: false,
      showStochastic: false,
    },
  },
  {
    name: "Institutional Fair-Value Sweep",
    isPreset: true,
    config: {
      ...DEFAULT_CONFIG,
      showAlligator: false,
      showKeltner: true,
      showFVG: true,
      showOB: true,
      showLiquiditySweep: true,
      showAMD: true,
    },
  },
  {
    name: "Stoch-MACD Cross Sniper",
    isPreset: true,
    config: {
      ...DEFAULT_CONFIG,
      showAlligator: false,
      showKeltner: false,
      showMACD: true,
      showStochastic: true,
    },
  },
  {
    name: "Clean Price Action Only",
    isPreset: true,
    config: {
      ...DEFAULT_CONFIG,
      showAlligator: false,
      showKeltner: false,
      showMACD: false,
      showStochastic: false,
      showFVG: false,
      showOB: false,
      showLiquiditySweep: false,
      showAMD: false,
    },
  }
];

const ChartConfigContext = createContext<ChartConfigContextType | undefined>(undefined);

export function ChartConfigProvider({ children }: { children: React.ReactNode }) {
  const [config, setConfig] = useState<IndicatorConfig>(DEFAULT_CONFIG);
  const [savedTemplates, setSavedTemplates] = useState<ChartTemplate[]>(PRESETS);
  const [activeTemplate, setActiveTemplate] = useState<string | null>("Classic Alligator Momentum");

  // Load custom templates from local storage
  useEffect(() => {
    const customJSON = localStorage.getItem("po_custom_chart_templates");
    const activeSavedName = localStorage.getItem("po_active_chart_template");
    const savedConfig = localStorage.getItem("po_current_chart_config");

    let loadedCustom: ChartTemplate[] = [];
    if (customJSON) {
      try {
        loadedCustom = JSON.parse(customJSON);
      } catch (e) {
        console.error("Failed to parse chart templates", e);
      }
    }

    setSavedTemplates([...PRESETS, ...loadedCustom]);

    if (savedConfig) {
      try {
        setConfig(JSON.parse(savedConfig));
      } catch (err) {}
    }

    if (activeSavedName) {
      setActiveTemplate(activeSavedName);
    }
  }, []);

  const updateConfig = (updater: Partial<IndicatorConfig>) => {
    setConfig(prev => {
      const next = { ...prev, ...updater };
      localStorage.setItem("po_current_chart_config", JSON.stringify(next));
      return next;
    });
    // Break active template connection since settings were modified
    setActiveTemplate(null);
    localStorage.removeItem("po_active_chart_template");
  };

  const saveTemplate = (name: string) => {
    if (!name.trim()) return;
    
    const customJSON = localStorage.getItem("po_custom_chart_templates");
    let loadedCustom: ChartTemplate[] = [];
    if (customJSON) {
      try {
        loadedCustom = JSON.parse(customJSON);
      } catch (e) {}
    }

    // Filter out duplicate name
    loadedCustom = loadedCustom.filter(t => t.name.toLowerCase() !== name.toLowerCase());

    const newTemplate: ChartTemplate = {
      name,
      config,
    };

    const nextCustom = [...loadedCustom, newTemplate];
    localStorage.setItem("po_custom_chart_templates", JSON.stringify(nextCustom));
    localStorage.setItem("po_active_chart_template", name);
    
    setSavedTemplates([...PRESETS, ...nextCustom]);
    setActiveTemplate(name);
  };

  const applyTemplate = (name: string) => {
    const match = savedTemplates.find(t => t.name.toLowerCase() === name.toLowerCase());
    if (match) {
      setConfig(match.config);
      setActiveTemplate(match.name);
      localStorage.setItem("po_current_chart_config", JSON.stringify(match.config));
      localStorage.setItem("po_active_chart_template", match.name);
    }
  };

  const deleteTemplate = (name: string) => {
    const activeCustom = savedTemplates.filter(t => !t.isPreset);
    const filteredCustom = activeCustom.filter(t => t.name.toLowerCase() !== name.toLowerCase());
    localStorage.setItem("po_custom_chart_templates", JSON.stringify(filteredCustom));
    
    setSavedTemplates([...PRESETS, ...filteredCustom]);
    if (activeTemplate?.toLowerCase() === name.toLowerCase()) {
      setActiveTemplate(null);
      localStorage.removeItem("po_active_chart_template");
    }
  };

  return (
    <ChartConfigContext.Provider
      value={{
        config,
        savedTemplates,
        activeTemplate,
        updateConfig,
        saveTemplate,
        applyTemplate,
        deleteTemplate,
      }}
    >
      {children}
    </ChartConfigContext.Provider>
  );
}

export function useChartConfig() {
  const context = useContext(ChartConfigContext);
  if (context === undefined) {
    throw new Error("useChartConfig must be used within a ChartConfigProvider");
  }
  return context;
}
