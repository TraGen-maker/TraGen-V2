import React, { createContext, useContext, useState, useEffect } from "react";

export interface User {
  id: string;
  fullName: string;
  username: string;
  email: string;
  passwordHash: string; // btoa() encoded for simplicity based on specs
  isAdmin: boolean;
  joinedAt: number;
  lastActive: number;
  status: "active" | "suspended";
}

export interface Session {
  userId: string;
  token: string;
  expiresAt: number;
}

export interface DailyCode {
  code: string;
  createdAt: number;
  expiresAt: number;
}

interface AuthContextType {
  currentUser: User | null;
  currentSession: Session | null;
  loading: boolean;
  error: string | null;
  registerUser: (userData: Omit<User, "id" | "isAdmin" | "joinedAt" | "lastActive" | "status">, code: string) => Promise<boolean>;
  loginUser: (username: string, pass: string, code: string) => Promise<boolean>;
  logoutUser: () => void;
  setError: (err: string | null) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentSession, setCurrentSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load and validate session on startup
  useEffect(() => {
    try {
      const storedUsers = localStorage.getItem("po_users");
      // Seed initial admin user if empty, or ensure its password is wsmforex1
      let usersList: User[] = storedUsers ? JSON.parse(storedUsers) : [];
      let defaultAdmin = usersList.find(u => u.id === "admin-default-uuid" || u.username === "wsmforex" || u.username === "admin");
      
      if (!defaultAdmin) {
        const initialAdmin: User = {
          id: "admin-default-uuid",
          fullName: "Admin Owner",
          username: "wsmforex",
          email: "admin@otcpro.org",
          passwordHash: btoa("wsmforex1"), // secure pass representing owner
          isAdmin: true,
          joinedAt: Date.now(),
          lastActive: Date.now(),
          status: "active",
        };
        usersList.push(initialAdmin);
        localStorage.setItem("po_users", JSON.stringify(usersList));
      } else {
        let changed = false;
        if (defaultAdmin.username !== "wsmforex") {
          defaultAdmin.username = "wsmforex";
          changed = true;
        }
        
        // Enforce secure password check if not synced
        const storedAdminPass = localStorage.getItem("po_admin_gateway_password") || "wsmforex1";
        if (defaultAdmin.passwordHash !== btoa(storedAdminPass)) {
          defaultAdmin.passwordHash = btoa(storedAdminPass);
          changed = true;
        }
        
        if (changed) {
          localStorage.setItem("po_users", JSON.stringify(usersList));
        }
      }

      // Seed initial daily code if empty
      const storedCode = localStorage.getItem("po_daily_code");
      if (!storedCode) {
        const midnight = new Date();
        midnight.setHours(23, 59, 59, 999);
        const codeObj: DailyCode = {
          code: "X7K-9P2", // default access code
          createdAt: Date.now(),
          expiresAt: midnight.getTime(),
        };
        localStorage.setItem("po_daily_code", JSON.stringify(codeObj));
      }

      const sessionData = localStorage.getItem("po_session");
      if (sessionData) {
        const parsedSession: Session = JSON.parse(sessionData);
        if (parsedSession.expiresAt > Date.now()) {
          const usersList: User[] = JSON.parse(localStorage.getItem("po_users") || "[]");
          const found = usersList.find(u => u.id === parsedSession.userId);
          if (found) {
            if (found.status === "suspended") {
              setError("Your account has been suspended by an administrator.");
              localStorage.removeItem("po_session");
            } else {
              setCurrentUser(found);
              setCurrentSession(parsedSession);
              // Update last active
              found.lastActive = Date.now();
              const updated = usersList.map(u => u.id === found.id ? found : u);
              localStorage.setItem("po_users", JSON.stringify(updated));
            }
          }
        } else {
          // expired
          localStorage.removeItem("po_session");
        }
      }
    } catch (e) {
      console.error("Session restoration error", e);
    } finally {
      setLoading(false);
    }
  }, []);

  const registerUser = async (
    userData: Omit<User, "id" | "isAdmin" | "joinedAt" | "lastActive" | "status">,
    code: string
  ): Promise<boolean> => {
    setLoading(true);
    setError(null);
    try {
      // 1. Verify Daily Access Code
      const poCode = localStorage.getItem("po_daily_code");
      if (!poCode) {
        setError("System configuration error. No active access codes are configured.");
        return false;
      }
      const parsedCode: DailyCode = JSON.parse(poCode);
      if (parsedCode.code !== code || parsedCode.expiresAt < Date.now()) {
        setError("Invalid or expired daily access code. Contact administrators.");
        return false;
      }

      const usersList: User[] = JSON.parse(localStorage.getItem("po_users") || "[]");

      // 2. Validate uniqueness
      if (usersList.some(u => u.username.toLowerCase() === userData.username.toLowerCase())) {
        setError("Username is already taken.");
        return false;
      }
      if (usersList.some(u => u.email.toLowerCase() === userData.email.toLowerCase())) {
        setError("Email is already registered.");
        return false;
      }

      // First user registered becomes Admin automatically
      const isAdminFlag = usersList.length === 0;

      const newUser: User = {
        id: crypto.randomUUID(),
        fullName: userData.fullName,
        username: userData.username,
        email: userData.email,
        passwordHash: btoa(userData.passwordHash), // btoa encoding per specifications
        isAdmin: isAdminFlag,
        joinedAt: Date.now(),
        lastActive: Date.now(),
        status: "active",
      };

      const updatedList = [...usersList, newUser];
      localStorage.setItem("po_users", JSON.stringify(updatedList));

      // Auto sign-in
      const midnight = Date.now() + 24 * 60 * 60 * 1000; // 24 Hours
      const newSession: Session = {
        userId: newUser.id,
        token: btoa(newUser.id + ":" + Date.now()),
        expiresAt: midnight,
      };

      localStorage.setItem("po_session", JSON.stringify(newSession));
      setCurrentUser(newUser);
      setCurrentSession(newSession);

      // Track active codes usage in history
      const historyStr = localStorage.getItem("po_code_history") || "[]";
      const historyList = JSON.parse(historyStr);
      const activeIdx = historyList.findIndex((h: any) => h.code === code);
      if (activeIdx !== -1) {
        historyList[activeIdx].usersUsed = (historyList[activeIdx].usersUsed || 0) + 1;
        localStorage.setItem("po_code_history", JSON.stringify(historyList));
      }

      return true;
    } catch (e: any) {
      setError(e?.message || "Registration failed");
      return false;
    } finally {
      setLoading(false);
    }
  };

  const loginUser = async (username: string, pass: string, code: string): Promise<boolean> => {
    setLoading(true);
    setError(null);
    try {
      // Validate daily access code
      const poCode = localStorage.getItem("po_daily_code");
      if (!poCode) {
        setError("Access code configuration error.");
        return false;
      }
      const parsedCode: DailyCode = JSON.parse(poCode);
      if (parsedCode.code !== code) {
        setError("Invalid access code.");
        return false;
      }

      const usersList: User[] = JSON.parse(localStorage.getItem("po_users") || "[]");
      const found = usersList.find(
        u => u.username.toLowerCase() === username.toLowerCase() && u.passwordHash === btoa(pass)
      );

      if (!found) {
        setError("Invalid username or password combinations.");
        return false;
      }

      if (found.status === "suspended") {
        setError("Your trading profile is suspended. Consult admin support.");
        return false;
      }

      const midnight = Date.now() + 24 * 60 * 60 * 1000;
      const newSession: Session = {
        userId: found.id,
        token: btoa(found.id + ":" + Date.now()),
        expiresAt: midnight,
      };

      localStorage.setItem("po_session", JSON.stringify(newSession));
      setCurrentUser(found);
      setCurrentSession(newSession);

      // Update last active status
      found.lastActive = Date.now();
      const updatedList = usersList.map(u => u.id === found.id ? found : u);
      localStorage.setItem("po_users", JSON.stringify(updatedList));

      return true;
    } catch (e: any) {
      setError(e?.message || "Login authentication failed");
      return false;
    } finally {
      setLoading(false);
    }
  };

  const logoutUser = () => {
    localStorage.removeItem("po_session");
    setCurrentUser(null);
    setCurrentSession(null);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        currentSession,
        loading,
        error,
        registerUser,
        loginUser,
        logoutUser,
        setError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
